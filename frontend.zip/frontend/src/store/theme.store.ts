import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface ThemeState {
  mode: 'dark' | 'light';
  toggleTheme: () => void;
  setMode: (mode: 'dark' | 'light') => void;
  hydrateTheme: () => Promise<void>;
}

export const useThemeStore = create<ThemeState>((set) => ({
  mode: 'dark', // Default to dark as per current design
  toggleTheme: async () => {
    set((state) => {
      const newMode = state.mode === 'dark' ? 'light' : 'dark';
      AsyncStorage.setItem('theme_mode', newMode);
      return { mode: newMode };
    });
  },
  setMode: async (mode) => {
    await AsyncStorage.setItem('theme_mode', mode);
    set({ mode });
  },
  hydrateTheme: async () => {
    const saved = await AsyncStorage.getItem('theme_mode');
    if (saved === 'light' || saved === 'dark') {
      set({ mode: saved });
    }
  },
}));

export const getColors = (mode: 'dark' | 'light', tenantTheme?: string) => {
  const isDark = mode === 'dark';
  const primary = tenantTheme || '#6366F1';

  return {
    primary,
    background: isDark ? '#0F172A' : '#F8FAFC',
    card: isDark ? '#1E293B' : '#FFFFFF',
    text: isDark ? '#F1F5F9' : '#1E293B',
    textMuted: isDark ? '#94A3B8' : '#64748B',
    border: isDark ? '#334155' : '#E2E8F0',
    input: isDark ? '#1E293B' : '#F1F5F9',
    success: '#10B981',
    error: '#EF4444',
    warning: '#F59E0B',
  };
};
