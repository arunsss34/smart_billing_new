import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, ActivityIndicator, RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { IconButton } from 'react-native-paper';
import { useRouter } from 'expo-router';
import { reportsApi } from '../api/business.api';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors } from '../theme';

const fmt = (n: number) => {
  return n.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
  });
};

export default function DashboardScreen() {
  const { themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const router = useRouter();
  const Colors = getColors(mode, themeColor || undefined);
  const isDark = mode === 'dark';

  const [summary, setSummary] = useState<any>(null);
  const [dailySales, setDailySales] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const [s, d] = await Promise.all([
        reportsApi.salesSummary(),
        reportsApi.dailySales(),
      ]);
      setSummary(s?.[0]);
      setDailySales(d?.slice(0, 7) || []);
    } catch (e) {
      console.error('Dashboard load error:', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const revenue = Number(summary?.total_revenue || 0);
  const tax = Number(summary?.total_tax || 0);
  const discount = Number(summary?.total_discount || 0);

  const quickActions = [
    { label: 'Invoice', icon: 'plus-circle', route: '/(app)/billing/new', color: '#6366F1' },
    { label: 'Inventory', icon: 'package-variant', route: '/(app)/products',    color: '#10B981' },
    { label: 'Clients',   icon: 'account-group',  route: '/(app)/customers',   color: '#F59E0B' },
    { label: 'Insights',  icon: 'chart-box',      route: '/(app)/reports',     color: '#EC4899' },
  ];

  if (loading) {
    return (
      <View style={[s.center, { backgroundColor: Colors.bg.primary }]}>
        <ActivityIndicator size="large" color={Colors.brand.primary} />
      </View>
    );
  }

  const maxRevenue = Math.max(...dailySales.map(d => Number(d.total_revenue || 0)), 1);

  return (
    <ScrollView
      style={[s.container, { backgroundColor: Colors.bg.primary }]}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={() => { setRefreshing(true); loadData(); }}
          tintColor={Colors.brand.primary}
        />
      }
    >
      <View style={{ height: 16 }} />

      {/* ── Compact Modern Revenue Card ── */}
      <LinearGradient 
        colors={isDark ? ['#1E1B4B', '#0F172A'] : ['#6366F1', '#4F46E5']} 
        start={{x:0, y:0}} end={{x:1, y:1}} 
        style={s.mainKpi}
      >
        <View style={s.kpiRowLeft}>
          <View style={s.kpiIconBox}>
            <IconButton icon="bank" size={20} iconColor="#FFF" style={{ margin: 0 }} />
          </View>
          <View>
            <Text style={s.kpiLabel}>Net Revenue</Text>
            <Text style={s.kpiVal}>₹{fmt(revenue)}</Text>
          </View>
        </View>
        <View style={s.kpiRowRight}>
          <View style={s.trendPill}>
            <Text style={s.trendTxt}>+14%</Text>
          </View>
        </View>
      </LinearGradient>

      {/* ── Sub KPIs Row ── */}
      <View style={s.subKpiRow}>
        <View style={[s.subCard, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
          <Text style={[s.subLabel, { color: Colors.text.muted }]}>Taxation</Text>
          <Text style={[s.subVal, { color: Colors.brand.success }]}>₹{fmt(tax)}</Text>
        </View>
        <View style={[s.subCard, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
          <Text style={[s.subLabel, { color: Colors.text.muted }]}>Discounts</Text>
          <Text style={[s.subVal, { color: Colors.brand.danger }]}>₹{fmt(discount)}</Text>
        </View>
      </View>

      {/* ── Quick Actions ── */}
      <View style={s.actionsGrid}>
        {quickActions.map(a => (
          <TouchableOpacity
            key={a.label}
            style={s.actionItem}
            onPress={() => router.push(a.route as any)}
            activeOpacity={0.7}
          >
            <View style={[s.actionIcon, { backgroundColor: isDark ? '#1A1D23' : '#F8FAFC', borderColor: Colors.border.default }]}>
              <IconButton icon={a.icon} size={22} iconColor={a.color} style={{ margin: 0 }} />
            </View>
            <Text style={[s.actionTxt, { color: Colors.text.secondary }]}>{a.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* ── Performance Chart ── */}
      <Text style={[s.secTitle, { color: Colors.text.secondary }]}>Revenue Stream</Text>
      <View style={[s.chartBox, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
        <View style={s.barContainer}>
          {dailySales.map((row, i) => {
            const h = (Number(row.total_revenue) / maxRevenue) * 100;
            const date = String(row.sale_date).split('T')[0].slice(8); // Day only
            return (
              <View key={i} style={s.barCol}>
                <View style={[s.barTrack, { backgroundColor: isDark ? '#0F172A' : '#F1F5F9' }]}>
                  <LinearGradient 
                    colors={['#6366F1', '#4F46E5']} 
                    style={[s.barFill, { height: `${Math.max(h, 5)}%` }]} 
                  />
                </View>
                <Text style={[s.barDate, { color: Colors.text.muted }]}>{date}</Text>
              </View>
            );
          })}
        </View>
      </View>

      {/* ── Recent History ── */}
      <Text style={[s.secTitle, { color: Colors.text.secondary }]}>Recent Activity</Text>
      <View style={[s.historyCard, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
        {dailySales.map((row, i) => (
          <View key={i} style={[s.historyRow, { borderBottomColor: Colors.border.subtle, borderBottomWidth: i === dailySales.length - 1 ? 0 : 1 }]}>
            <View style={{ flex: 1 }}>
              <Text style={[s.histDate, { color: Colors.text.primary }]}>{String(row.sale_date).split('T')[0]}</Text>
              <Text style={[s.histMeta, { color: Colors.text.muted }]}>{row.total_invoices} sales</Text>
            </View>
            <Text style={[s.histAmt, { color: Colors.brand.success }]}>₹{fmt(Number(row.total_revenue))}</Text>
          </View>
        ))}
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  mainKpi: { 
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 20, height: 100, borderRadius: 12, elevation: 4,
    shadowColor: '#6366F1', shadowOpacity: 0.2, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }
  },
  kpiRowLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  kpiIconBox: { width: 40, height: 40, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.15)', justifyContent: 'center', alignItems: 'center' },
  kpiLabel: { color: 'rgba(255,255,255,0.7)', fontSize: 11, fontWeight: '700', textTransform: 'uppercase' },
  kpiVal: { color: '#FFF', fontSize: 28, fontWeight: '900', letterSpacing: -0.5 },
  kpiRowRight: { alignItems: 'flex-end' },
  trendPill: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.2)' },
  trendTxt: { color: '#4ADE80', fontSize: 10, fontWeight: '900' },

  subKpiRow: { flexDirection: 'row', gap: 10, marginTop: 10, marginBottom: 20 },
  subCard: { flex: 1, padding: 16, borderRadius: 12, borderWidth: 1, justifyContent: 'center' },
  subLabel: { fontSize: 10, fontWeight: '700', textTransform: 'uppercase', marginBottom: 4 },
  subVal: { fontSize: 18, fontWeight: '800' },

  actionsGrid: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 24 },
  actionItem: { alignItems: 'center', width: '22%' },
  actionIcon: { width: 50, height: 50, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginBottom: 6, borderWidth: 1 },
  actionTxt: { fontSize: 11, fontWeight: '700' },

  secTitle: { fontSize: 10, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12, opacity: 0.6 },

  chartBox: { borderRadius: 12, padding: 20, borderWidth: 1, marginBottom: 12 },
  barContainer: { flexDirection: 'row', alignItems: 'flex-end', height: 100, gap: 10 },
  barCol: { flex: 1, alignItems: 'center' },
  barTrack: { width: '100%', flex: 1, borderRadius: 4, overflow: 'hidden', justifyContent: 'flex-end' },
  barFill: { width: '100%', borderRadius: 4 },
  barDate: { fontSize: 9, fontWeight: '700', marginTop: 8 },

  historyCard: { borderRadius: 12, overflow: 'hidden', borderWidth: 1 },
  historyRow: { flexDirection: 'row', padding: 16, alignItems: 'center', justifyContent: 'space-between' },
  histDate: { fontSize: 13, fontWeight: '700' },
  histMeta: { fontSize: 11, marginTop: 2 },
  histAmt: { fontSize: 14, fontWeight: '800' },
});
