import React from 'react';
import { View, Text, Modal, StyleSheet, TouchableOpacity, Animated } from 'react-native';
import { IconButton } from 'react-native-paper';
import { Colors } from '../theme';

interface ModernAlertProps {
  visible: boolean;
  title: string;
  message: string;
  onConfirm: () => void;
  onCancel?: () => void;
  confirmText?: string;
  cancelText?: string;
  type?: 'success' | 'danger' | 'warning' | 'info';
}

export default function ModernAlert({
  visible,
  title,
  message,
  onConfirm,
  onCancel,
  confirmText = 'Confirm',
  cancelText = 'Cancel',
  type = 'info'
}: ModernAlertProps) {
  const [scale] = React.useState(new Animated.Value(0.9));
  const [opacity] = React.useState(new Animated.Value(0));

  React.useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.spring(scale, { toValue: 1, useNativeDriver: true, friction: 8 }),
        Animated.timing(opacity, { toValue: 1, duration: 200, useNativeDriver: true }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(scale, { toValue: 0.9, duration: 150, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0, duration: 150, useNativeDriver: true }),
      ]).start();
    }
  }, [visible]);

  const getTypeColor = () => {
    switch (type) {
      case 'danger': return Colors.brand.danger;
      case 'success': return Colors.brand.success;
      case 'warning': return Colors.brand.warning;
      default: return Colors.brand.primary;
    }
  };

  const getIcon = () => {
    switch (type) {
      case 'danger': return 'alert-circle';
      case 'success': return 'check-circle';
      case 'warning': return 'alert';
      default: return 'information';
    }
  };

  if (!visible) return null;

  return (
    <Modal visible={visible} transparent animationType="none">
      <View style={styles.overlay}>
        <Animated.View style={[
          styles.card, 
          { 
            backgroundColor: Colors.bg.card, 
            opacity, 
            transform: [{ scale }],
            borderColor: Colors.mode === 'dark' ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.05)'
          }
        ]}>
          <View style={[styles.header, { borderBottomColor: Colors.border.subtle }]}>
            <View style={[styles.iconBadge, { backgroundColor: getTypeColor() + '15' }]}>
              <IconButton icon={getIcon()} size={24} iconColor={getTypeColor()} style={{ margin: 0 }} />
            </View>
            <Text style={[styles.title, { color: Colors.text.primary }]}>{title}</Text>
          </View>

          <View style={styles.content}>
            <Text style={[styles.message, { color: Colors.text.secondary }]}>{message}</Text>
          </View>

          <View style={styles.footer}>
            {onCancel && (
              <TouchableOpacity style={[styles.btn, styles.cancelBtn]} onPress={onCancel}>
                <Text style={[styles.btnText, { color: Colors.text.muted }]}>{cancelText}</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity 
              style={[styles.btn, { backgroundColor: getTypeColor() }]} 
              onPress={onConfirm}
            >
              <Text style={[styles.btnText, { color: '#fff' }]}>{confirmText}</Text>
            </TouchableOpacity>
          </View>
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  card: {
    width: '100%',
    maxWidth: 340,
    borderRadius: 24,
    borderWidth: 1,
    padding: 20,
    elevation: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.5,
    shadowRadius: 15,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: 16,
    borderBottomWidth: 1,
    gap: 12,
  },
  iconBadge: {
    width: 44, height: 44,
    borderRadius: 14,
    justifyContent: 'center', alignItems: 'center',
  },
  title: { fontSize: 18, fontWeight: '900', flex: 1 },
  content: { paddingVertical: 20 },
  message: { fontSize: 15, fontWeight: '600', lineHeight: 22 },
  footer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
  },
  btn: {
    paddingHorizontal: 20,
    height: 44,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cancelBtn: { backgroundColor: 'transparent' },
  btnText: { fontSize: 14, fontWeight: '800' },
});
