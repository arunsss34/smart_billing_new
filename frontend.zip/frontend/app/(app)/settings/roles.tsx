import RoleManagementScreen from '../../../src/screens/RoleManagementScreen';
export default RoleManagementScreen;
