import React, { useState, useEffect } from 'react';
import { Modal, View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { CameraView, Camera } from 'expo-camera';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors, Radius, FontSize } from '../theme';

interface BarcodeScannerModalProps {
  visible: boolean;
  onScan: (data: string) => void;
  onClose: () => void;
}

export default function BarcodeScannerModal({ visible, onScan, onClose }: BarcodeScannerModalProps) {
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);

  const { themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);

  useEffect(() => {
    if (visible) {
      (async () => {
        const { status } = await Camera.requestCameraPermissionsAsync();
        setHasPermission(status === 'granted');
      })();
    }
  }, [visible]);

  if (!visible) return null;

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={[s.overlay, { backgroundColor: mode === 'light' ? 'rgba(0,0,0,0.5)' : 'rgba(0,0,0,0.8)' }]}>
        <View style={[s.modalBox, { backgroundColor: Colors.bg.primary }]}>
          <View style={[s.header, { borderBottomColor: Colors.border.default, borderBottomWidth: 1 }]}>
            <Text style={[s.title, { color: Colors.text.primary }]}>Scan Barcode</Text>
            <TouchableOpacity onPress={onClose}>
              <Text style={[s.closeBtn, { color: Colors.text.muted }]}>✕</Text>
            </TouchableOpacity>
          </View>
          
          <View style={s.cameraBox}>
            {hasPermission === null ? (
              <Text style={s.msg}>Requesting camera permission...</Text>
            ) : hasPermission === false ? (
              <Text style={s.msg}>No access to camera</Text>
            ) : (
              <CameraView
                style={StyleSheet.absoluteFillObject}
                facing="back"
                onBarcodeScanned={({ data }) => {
                  onScan(data);
                }}
              />
            )}
            {/* Scanner overlay reticle */}
            <View style={[s.reticle, { borderColor: Colors.brand.primary }]} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  overlay: { flex: 1, justifyContent: 'center', padding: 20 },
  modalBox: { borderRadius: Radius.lg, overflow: 'hidden' },
  header: { flexDirection: 'row', justifyContent: 'space-between', padding: 15, alignItems: 'center' },
  title: { fontSize: FontSize.lg, fontWeight: '700' },
  closeBtn: { fontSize: 20, padding: 5 },
  cameraBox: { height: 350, backgroundColor: '#000', justifyContent: 'center', alignItems: 'center', position: 'relative' },
  msg: { color: '#fff' },
  reticle: {
    position: 'absolute',
    width: 250,
    height: 100,
    borderWidth: 2,
    backgroundColor: 'transparent'
  }
});
