import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
  View, Text, FlatList, StyleSheet, ActivityIndicator, TouchableOpacity, Alert, Modal, ScrollView, TextInput
} from 'react-native';
import { IconButton } from 'react-native-paper';
import { billingApi, productsApi, Invoice, Product } from '../api/business.api';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors } from '../theme';

type TimeFilter = 'Today' | 'Week' | 'Month' | 'Year' | 'Custom' | 'All';

const paymentColor: Record<string, string> = {
  cash: '#22C55E', upi: '#3B82F6', card: '#A78BFA',
};

export default function InvoiceListScreen() {
  const { themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);
  
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<TimeFilter>('Today');

  const [fromDate, setFromDate] = useState(new Date().toISOString().split('T')[0]);
  const [toDate, setToDate] = useState(new Date().toISOString().split('T')[0]);
  const [showDatePicker, setShowDatePicker] = useState(false);
  
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [viewModal, setViewModal] = useState(false);

  const formatLocalDate = (date: Date) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  };

  const dateParams = useMemo(() => {
    const end = new Date();
    let start = new Date();
    
    if (filter === 'Today') {
      start.setHours(0,0,0,0);
    } else if (filter === 'Week') {
      start.setDate(end.getDate() - 7);
    } else if (filter === 'Month') {
      start.setMonth(end.getMonth() - 1);
    } else if (filter === 'Year') {
      start.setFullYear(end.getFullYear() - 1);
    } else if (filter === 'Custom') {
      return { start_date: fromDate, end_date: toDate };
    } else if (filter === 'All') {
      return {};
    }

    return {
      start_date: formatLocalDate(start),
      end_date: formatLocalDate(end)
    };
  }, [filter, fromDate, toDate]);

  const fetchInvoices = useCallback(() => {
    setLoading(true);
    billingApi.listInvoices(dateParams).then(invs => {
      setInvoices(invs || []);
    }).finally(() => setLoading(false));
  }, [dateParams]);

  const fetchProducts = useCallback(() => {
    productsApi.list().then(prods => setProducts(prods || []));
  }, []);

  useEffect(() => {
    fetchInvoices();
  }, [fetchInvoices]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const filteredInvoices = invoices.filter(inv => 
    inv.invoice_number.toLowerCase().includes(search.toLowerCase()) ||
    (inv as any).customer_name?.toLowerCase().includes(search.toLowerCase())
  );

  const handlePay = (invoice: Invoice) => {
    Alert.alert(
      'Complete Payment',
      `Mark Invoice ${invoice.invoice_number} as Paid?\nTotal: ₹${invoice.grand_total}`,
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Confirm Pay', 
          onPress: async () => {
            try {
              await billingApi.payInvoice(invoice.id);
              Alert.alert('Success', 'Invoice marked as Paid!');
              fetchInvoices();
            } catch (e: any) {
              Alert.alert('Error', e?.response?.data?.detail || 'Failed to update invoice');
            }
          }
        }
      ]
    );
  };

  const getProductName = (pid: number) => {
    const p = products.find(prod => prod.id === pid);
    return p ? p.name : `Product ID: ${pid}`;
  };

  const openView = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    setViewModal(true);
  };

  const handlePrint = (type: 'Label' | 'Receipt') => {
    Alert.alert(`Print ${type}`, `Sending to ${type} Printer...\n(Printing integration coming soon!)`);
  };

  const renderItem = ({ item }: { item: Invoice }) => (
    <TouchableOpacity 
      style={[s.listItem, { borderBottomColor: Colors.border.subtle }]} 
      onPress={() => openView(item)} 
      activeOpacity={0.7}
    >
      <View style={s.listMain}>
        <View style={[s.listIcon, { backgroundColor: (item.invoice_status === 'Draft' ? '#F59E0B' : Colors.brand.success) + '15' }]}>
          <Text style={[s.listIconText, { color: item.invoice_status === 'Draft' ? '#F59E0B' : Colors.brand.success }]}>
            {item.invoice_status === 'Draft' ? '⏳' : '✅'}
          </Text>
        </View>
        
        <View style={s.listInfo}>
          <View style={s.listTitleRow}>
            <Text style={[s.listName, { color: Colors.text.primary }]}>{item.invoice_number}</Text>
            <View style={[s.statusBadge, { backgroundColor: (item.invoice_status === 'Draft' ? '#F59E0B' : Colors.brand.success) + '15' }]}>
              <Text style={[s.statusText, { color: item.invoice_status === 'Draft' ? '#F59E0B' : Colors.brand.success }]}>
                {item.invoice_status === 'Draft' ? 'Draft' : 'Paid'}
              </Text>
            </View>
          </View>
          
          <View style={s.listMetaRow}>
            <Text style={[s.listMeta, { color: Colors.text.muted }]}>{new Date(item.created_at).toLocaleDateString('en-IN')}</Text>
            <View style={s.listDot} />
            <Text style={[s.listMeta, { color: paymentColor[item.payment_method] || Colors.text.muted, fontWeight: '700' }]}>
              {item.payment_method}
            </Text>
          </View>
        </View>
      </View>

      <View style={s.listRight}>
        <Text style={[s.listAmount, { color: Colors.text.primary }]}>₹{Number(item.grand_total).toLocaleString('en-IN')}</Text>
        {item.invoice_status === 'Draft' && (
          <IconButton 
            icon="wallet-outline" 
            size={18} 
            iconColor={Colors.brand.primary} 
            onPress={() => handlePay(item)}
            style={{ margin: 0, marginLeft: 8 }}
          />
        )}
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[s.container, { backgroundColor: Colors.bg.primary }]}>
      <View style={s.filterHeader}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.timeFilters}>
          {(['Today', 'Week', 'Month', 'Year', 'Custom', 'All'] as TimeFilter[]).map(f => (
            <TouchableOpacity 
              key={f} 
              style={[s.filterChip, { borderColor: Colors.border.default, backgroundColor: Colors.bg.card }, filter === f && { backgroundColor: Colors.brand.primary, borderColor: Colors.brand.primary }]} 
              onPress={() => {
                setFilter(f);
                if (f === 'Custom') setShowDatePicker(true);
              }}
            >
              <Text style={[s.filterChipTxt, { color: filter === f ? '#FFF' : Colors.text.secondary }]}>{f}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        <IconButton icon="refresh" size={20} iconColor={Colors.brand.primary} onPress={fetchInvoices} />
      </View>

      {filter === 'Custom' && (
        <TouchableOpacity style={[s.dateRangeCard, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]} onPress={() => setShowDatePicker(true)}>
          <Text style={[s.dateRangeTxt, { color: Colors.text.primary }]}>{fromDate}  →  {toDate}</Text>
          <Text style={{ fontSize: 10, color: Colors.brand.primary, fontWeight: '700' }}>Edit</Text>
        </TouchableOpacity>
      )}

      <View style={s.searchBarWrapper}>
        <View style={[s.searchBar, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
          <IconButton icon="magnify" size={20} iconColor={Colors.text.muted} style={{ margin: 0 }} />
          <TextInput
            style={[s.searchInput, { color: Colors.text.primary }]}
            value={search}
            onChangeText={setSearch}
            placeholder="Search by invoice # or customer..."
            placeholderTextColor={Colors.text.muted}
          />
        </View>
      </View>

      {loading
        ? <View style={s.center}><ActivityIndicator color={Colors.brand.primary} /></View>
        : <FlatList
            data={filteredInvoices}
            renderItem={renderItem}
            keyExtractor={i => String(i.id)}
            contentContainerStyle={s.list}
            ListEmptyComponent={
              <View style={s.emptyContainer}>
                <Text style={[s.emptyTitle, { color: Colors.text.primary }]}>No Invoices Found</Text>
                <Text style={[s.emptySub, { color: Colors.text.muted }]}>Try changing your filter or search term.</Text>
              </View>
            }
          />
      }

      <Modal visible={viewModal} animationType="slide" transparent>
        <View style={[s.modalRoot, { backgroundColor: Colors.bg.overlay }]}>
          <View style={[s.modalCard, { backgroundColor: Colors.bg.card }]}>
            {selectedInvoice && (
              <>
                <View style={s.modalHeader}>
                  <View>
                    <Text style={[s.modalTitle, { color: Colors.text.primary }]}>Invoice Details</Text>
                    <Text style={[s.modalSub, { color: Colors.text.muted }]}>#{selectedInvoice.invoice_number}</Text>
                  </View>
                  <IconButton icon="close" size={24} iconColor={Colors.text.muted} onPress={() => setViewModal(false)} />
                </View>

                <View style={[s.summaryRow, { borderBottomColor: Colors.border.subtle }]}>
                  <View style={s.sumItem}>
                    <Text style={[s.sumLabel, { color: Colors.text.muted }]}>Date</Text>
                    <Text style={[s.sumVal, { color: Colors.text.primary }]}>{new Date(selectedInvoice.created_at).toLocaleDateString()}</Text>
                  </View>
                  <View style={s.sumItem}>
                    <Text style={[s.sumLabel, { color: Colors.text.muted }]}>Payment</Text>
                    <Text style={[s.sumVal, { color: paymentColor[selectedInvoice.payment_method] || Colors.text.primary }]}>
                      {selectedInvoice.payment_method.toUpperCase()}
                    </Text>
                  </View>
                  <View style={s.sumItem}>
                    <Text style={[s.sumLabel, { color: Colors.text.muted }]}>Total</Text>
                    <Text style={[s.sumVal, { color: Colors.brand.primary, fontWeight: '800' }]}>₹{selectedInvoice.grand_total}</Text>
                  </View>
                </View>
                
                <Text style={[s.sectionLabel, { color: Colors.text.secondary }]}>Billed Items</Text>
                <ScrollView style={s.itemsScroll} showsVerticalScrollIndicator={false}>
                  {selectedInvoice.items.map((it, idx) => (
                    <View key={idx} style={[s.billItem, { borderBottomColor: Colors.border.subtle }]}>
                      <View style={{ flex: 1 }}>
                        <Text style={[s.itemName, { color: Colors.text.primary }]}>{getProductName(it.product_id)}</Text>
                        <Text style={[s.itemMeta, { color: Colors.text.muted }]}>₹{it.unit_price} × {it.quantity}</Text>
                      </View>
                      <Text style={[s.itemTotal, { color: Colors.text.primary }]}>₹{(it.unit_price * it.quantity - (it.discount || 0)).toFixed(2)}</Text>
                    </View>
                  ))}
                </ScrollView>

                <View style={s.modalFooter}>
                  <TouchableOpacity style={[s.btn, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, borderWidth: 1 }]} onPress={() => handlePrint('Label')}>
                    <Text style={[s.btnText, { color: Colors.text.secondary }]}>🏷 Label</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={[s.btn, { backgroundColor: Colors.brand.primary }]} onPress={() => handlePrint('Receipt')}>
                    <Text style={s.btnText}>🖨 Receipt</Text>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </View>
        </View>
      </Modal>

      <Modal visible={showDatePicker} transparent animationType="fade">
        <View style={s.dateModalOverlay}>
          <View style={[s.dateModalContent, { backgroundColor: Colors.bg.card }]}>
            <Text style={[s.dateModalTitle, { color: Colors.text.primary }]}>Custom Date Range</Text>
            <TextInput 
              style={[s.dateInput, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, color: Colors.text.primary }]}
              value={fromDate} onChangeText={setFromDate} placeholder="From: YYYY-MM-DD"
              placeholderTextColor={Colors.text.muted}
            />
            <TextInput 
              style={[s.dateInput, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, color: Colors.text.primary, marginTop: 12 }]}
              value={toDate} onChangeText={setToDate} placeholder="To: YYYY-MM-DD"
              placeholderTextColor={Colors.text.muted}
            />
            <View style={s.modalFooter}>
              <TouchableOpacity style={[s.btn, { backgroundColor: Colors.bg.primary }]} onPress={() => setShowDatePicker(false)}>
                <Text style={[s.btnText, { color: Colors.text.secondary }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.btn, { backgroundColor: Colors.brand.primary }]} onPress={() => { setShowDatePicker(false); setFilter('Custom'); fetchInvoices(); }}>
                <Text style={s.btnText}>Apply Range</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  
  filterHeader: { flexDirection: 'row', alignItems: 'center', marginTop: 12, paddingHorizontal: 12 },
  timeFilters: { flex: 1 },
  filterChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10, marginRight: 8, borderWidth: 1 },
  filterChipTxt: { fontSize: 11, fontWeight: '700' },

  dateRangeCard: { flexDirection: 'row', alignItems: 'center', padding: 10, borderRadius: 10, borderWidth: 1, marginHorizontal: 12, marginTop: 10 },
  dateRangeTxt: { flex: 1, fontSize: 12, fontWeight: '700' },

  searchBarWrapper: { padding: 12, paddingBottom: 6 },
  searchBar: { 
    flexDirection: 'row', alignItems: 'center', 
    borderRadius: 8, paddingHorizontal: 4, height: 36, borderWidth: 1 
  },
  searchInput: { flex: 1, fontSize: 13, fontWeight: '500' },
  list: { paddingBottom: 100 },
  listItem: { 
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingVertical: 12, paddingHorizontal: 16, borderBottomWidth: 1 
  },
  listMain: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  listIcon: { width: 40, height: 40, borderRadius: 8, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  listIconText: { fontSize: 16 },
  listInfo: { flex: 1 },
  listTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 2 },
  listName: { fontSize: 14, fontWeight: '700' },
  statusBadge: { paddingHorizontal: 6, paddingVertical: 1, borderRadius: 4 },
  statusText: { fontSize: 9, fontWeight: '800', textTransform: 'uppercase' },
  listMetaRow: { flexDirection: 'row', alignItems: 'center' },
  listMeta: { fontSize: 11, fontWeight: '500' },
  listDot: { width: 3, height: 3, borderRadius: 1.5, backgroundColor: '#cbd5e1', marginHorizontal: 6 },
  listRight: { flexDirection: 'row', alignItems: 'center' },
  listAmount: { fontSize: 15, fontWeight: '800' },

  modalRoot: { flex: 1, justifyContent: 'flex-end' },
  modalCard: { borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 24, maxHeight: '90%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 18, fontWeight: '800' },
  modalSub: { fontSize: 12, marginTop: 2 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', paddingBottom: 16, borderBottomWidth: 1, marginBottom: 16 },
  sumItem: { flex: 1 },
  sumLabel: { fontSize: 10, fontWeight: '700', marginBottom: 4 },
  sumVal: { fontSize: 13, fontWeight: '700' },
  sectionLabel: { fontSize: 11, fontWeight: '800', textTransform: 'uppercase', marginBottom: 12, opacity: 0.6 },
  itemsScroll: { flex: 1, marginBottom: 16 },
  billItem: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, borderBottomWidth: 1 },
  itemName: { fontSize: 13, fontWeight: '600' },
  itemMeta: { fontSize: 11, marginTop: 2 },
  itemTotal: { fontSize: 13, fontWeight: '700' },
  modalFooter: { flexDirection: 'row', gap: 12, paddingTop: 16 },
  btn: { flex: 1, paddingVertical: 12, borderRadius: 8, alignItems: 'center' },
  btnText: { fontWeight: '700', color: '#fff', fontSize: 14 },
  
  dateModalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 24 },
  dateModalContent: { width: '100%', borderRadius: 10, padding: 24 },
  dateModalTitle: { fontSize: 16, fontWeight: '800', marginBottom: 16 },
  dateInput: { borderRadius: 8, borderWidth: 1, padding: 10, fontSize: 14 },

  emptyContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', marginTop: 100, paddingHorizontal: 40 },
  emptyTitle: { fontSize: 16, fontWeight: '800', marginBottom: 8 },
  emptySub: { fontSize: 14, textAlign: 'center', opacity: 0.6 },
});
