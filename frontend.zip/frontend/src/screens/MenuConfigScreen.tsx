import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  ActivityIndicator, Alert, Switch,
} from 'react-native';
import api from '../api/client';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors, Radius, Spacing, FontSize } from '../theme';

interface RolePerm {
  role_id: number;
  role_name: string;
  role_label: string;
  can_view: boolean;
  can_add: boolean;
  can_edit: boolean;
  can_delete: boolean;
}

interface Menu {
  id: number;
  name: string;
  route: string;
  icon: string;
  parent_id: number | null;
  sort_order: number;
  permissions: RolePerm[];
}

interface Role { id: number; name: string; }

const ROLE_COLORS: Record<number, string> = {
  1: '#6366F1',  // super_admin
  2: '#10B981',  // tenant_admin
  3: '#F59E0B',  // staff
};

const PERM_COLS: { key: keyof RolePerm; label: string }[] = [
  { key: 'can_view',   label: 'View'   },
  { key: 'can_add',    label: 'Add'    },
  { key: 'can_edit',   label: 'Edit'   },
  { key: 'can_delete', label: 'Delete' },
];

export default function MenuConfigScreen() {
  const { themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);

  const [menus, setMenus] = useState<Menu[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [expandedMenus, setExpandedMenus] = useState<Set<number>>(new Set());

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api.get('/menus/all');
      setMenus(r.data.menus);
      setRoles(r.data.roles);
      const parents = new Set(
        r.data.menus.filter((m: Menu) => m.parent_id === null).map((m: Menu) => m.id)
      );
      setExpandedMenus(parents);
    } catch (e: any) {
      Alert.alert('Error', e?.response?.data?.detail || 'Failed to load menu config');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const toggleExpand = (id: number) => {
    setExpandedMenus(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const updatePerm = async (
    menu: Menu,
    roleId: number,
    field: keyof RolePerm,
    value: boolean
  ) => {
    const key = `${menu.id}-${roleId}`;
    setSaving(key);

    setMenus(prev => prev.map(m => {
      if (m.id !== menu.id) return m;
      return {
        ...m,
        permissions: m.permissions.map(p => {
          if (p.role_id !== roleId) return p;
          const updated = { ...p, [field]: value };
          if (['can_add', 'can_edit', 'can_delete'].includes(field as string) && value) {
            updated.can_view = true;
          }
          if (field === 'can_view' && !value) {
            updated.can_add = false;
            updated.can_edit = false;
            updated.can_delete = false;
          }
          return updated;
        }),
      };
    }));

    try {
      const menuPerm = menus.find(m => m.id === menu.id)!
        .permissions.find(p => p.role_id === roleId)!;

      const updated = { ...menuPerm, [field]: value };
      if (['can_add', 'can_edit', 'can_delete'].includes(field as string) && value) {
        updated.can_view = true;
      }
      if (field === 'can_view' && !value) {
        updated.can_add = false; updated.can_edit = false; updated.can_delete = false;
      }

      await api.put('/menus/permissions', {
        role_id:    roleId,
        menu_id:    menu.id,
        can_view:   updated.can_view,
        can_add:    updated.can_add,
        can_edit:   updated.can_edit,
        can_delete: updated.can_delete,
      });
    } catch (e: any) {
      Alert.alert('Error', 'Failed to update permission');
      load();
    } finally {
      setSaving(null);
    }
  };

  const parents = menus.filter(m => m.parent_id === null);
  const childrenOf = (id: number) => menus.filter(m => m.parent_id === id);

  if (loading) {
    return (
      <View style={[s.center, { backgroundColor: Colors.bg.primary }]}>
        <ActivityIndicator size="large" color={Colors.brand.primary} />
        <Text style={[s.loadingText, { color: Colors.text.muted }]}>Loading configuration...</Text>
      </View>
    );
  }

  const renderPermRow = (menu: Menu, perm: RolePerm) => {
    const roleColor = ROLE_COLORS[perm.role_id] || Colors.text.muted;
    const isSaving = saving === `${menu.id}-${perm.role_id}`;

    return (
      <View key={perm.role_id} style={[s.permRow, { borderBottomColor: Colors.border.default + '40' }]}>
        <View style={[s.roleBadge, { backgroundColor: roleColor + '22', borderColor: roleColor + '55' }]}>
          <Text style={[s.roleBadgeText, { color: roleColor }]}>{perm.role_label}</Text>
        </View>

        <View style={s.permCols}>
          {PERM_COLS.map(col => {
            const val = perm[col.key] as boolean;
            return (
              <View key={col.key} style={s.permCell}>
                {isSaving
                  ? <ActivityIndicator size="small" color={Colors.brand.primary} style={{ height: 24 }} />
                  : <Switch
                      value={val}
                      onValueChange={v => updatePerm(menu, perm.role_id, col.key, v)}
                      trackColor={{ false: Colors.bg.primary, true: roleColor + '88' }}
                      thumbColor={val ? roleColor : '#94A3B8'}
                      style={{ transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }] }}
                    />
                }
              </View>
            );
          })}
        </View>
      </View>
    );
  };

  const renderMenu = (menu: Menu, isChild = false) => {
    const expanded = expandedMenus.has(menu.id);
    const children = childrenOf(menu.id);
    const isParent = children.length > 0;

    return (
      <View key={menu.id} style={[s.menuBlock, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }, isChild && { backgroundColor: Colors.bg.primary, borderColor: Colors.border.subtle }]}>
        <TouchableOpacity
          style={[s.menuHeader, { backgroundColor: Colors.bg.elevated }, isChild && { backgroundColor: Colors.bg.card }]}
          onPress={() => isParent && toggleExpand(menu.id)}
          activeOpacity={isParent ? 0.7 : 1}
        >
          <View style={s.menuHeaderLeft}>
            {isChild && <View style={[s.childIndicator, { backgroundColor: Colors.brand.primary + '66' }]} />}
            <Text style={s.menuIcon}>{menu.icon ? '📋' : '📄'}</Text>
            <View>
              <Text style={[s.menuName, { color: Colors.text.primary }]}>{menu.name}</Text>
              <Text style={[s.menuRoute, { color: Colors.text.muted }]}>/{menu.route}</Text>
            </View>
          </View>
          {isParent && (
            <Text style={[s.chevron, { color: Colors.text.muted }]}>{expanded ? '▴' : '▾'}</Text>
          )}
        </TouchableOpacity>

        {(!isParent || expanded) && (
          <View style={s.permBlock}>
            <View style={[s.permHeaderRow, { borderBottomColor: Colors.border.default }]}>
              <View style={s.roleBadge} />
              <View style={s.permCols}>
                {PERM_COLS.map(col => (
                  <View key={col.key} style={s.permCell}>
                    <Text style={[s.permHeader, { color: Colors.text.disabled }]}>{col.label}</Text>
                  </View>
                ))}
              </View>
            </View>
            {menu.permissions.map(perm => renderPermRow(menu, perm))}
          </View>
        )}

        {isParent && expanded && (
          <View style={s.childrenBlock}>
            {children.map(child => renderMenu(child, true))}
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={[s.container, { backgroundColor: Colors.bg.primary }]}>
      <View style={s.header}>
        <Text style={[s.title, { color: Colors.text.primary }]}>Menu Configuration</Text>
        <Text style={[s.subtitle, { color: Colors.text.muted }]}>Set global system permissions</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {parents.map(m => renderMenu(m))}
        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 16, paddingTop: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { fontSize: 14 },
  header: { marginBottom: 16 },
  title: { fontSize: 20, fontWeight: '800' },
  subtitle: { fontSize: 12, marginTop: 2 },
  menuBlock: { borderRadius: Radius.lg, marginBottom: 16, borderWidth: 1, overflow: 'hidden' },
  menuHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 12 },
  menuHeaderLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  childIndicator: { width: 3, height: 24, borderRadius: 2 },
  menuIcon: { fontSize: 16 },
  menuName: { fontSize: 16, fontWeight: '700' },
  menuRoute: { fontSize: 11, fontFamily: 'monospace', marginTop: 1 },
  chevron: { fontSize: 12 },
  permBlock: { paddingHorizontal: 12, paddingVertical: 8 },
  permHeaderRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 6, paddingBottom: 6, borderBottomWidth: 1 },
  permRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 5, borderBottomWidth: 1 },
  roleBadge: { width: 100, paddingHorizontal: 6, paddingVertical: 3, borderRadius: Radius.sm, borderWidth: 1, borderColor: 'transparent' },
  roleBadgeText: { fontSize: 10, fontWeight: '700' },
  permCols: { flex: 1, flexDirection: 'row' },
  permCell: { flex: 1, alignItems: 'center' },
  permHeader: { fontSize: 9, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5 },
  childrenBlock: { padding: 8, paddingTop: 0, gap: 4 },
});
