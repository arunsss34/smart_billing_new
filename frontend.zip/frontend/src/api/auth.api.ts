import AsyncStorage from '@react-native-async-storage/async-storage';
import api from './client';

export interface LoginResponse {
  access_token: string;
  token_type: string;
  role: string;
  tenant_id: number | null;
  business_type: string | null;
  business_type_id: number | null;
}

export const authApi = {
  login: async (username: string, password: string): Promise<LoginResponse> => {
    const form = new FormData();
    form.append('username', username);
    form.append('password', password);
    const { data } = await api.post<LoginResponse>('/auth/login', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    // Persist all user context to AsyncStorage
    await AsyncStorage.setItem('access_token', data.access_token);
    await AsyncStorage.setItem('user_role', data.role);
    await AsyncStorage.setItem('tenant_id', String(data.tenant_id ?? ''));
    await AsyncStorage.setItem('business_type', data.business_type ?? '');
    await AsyncStorage.setItem('business_type_id', String(data.business_type_id ?? ''));
    return data;
  },

  logout: async () => {
    await AsyncStorage.multiRemove([
      'access_token', 'user_role', 'tenant_id',
      'business_type', 'business_type_id',
      'menus_cache', 'features_cache',
    ]);
  },
};
