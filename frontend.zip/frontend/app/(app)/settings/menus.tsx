import MenuConfigScreen from '../../../src/screens/MenuConfigScreen';
export default MenuConfigScreen;
