import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  FlatList, Alert, Modal, TextInput, ActivityIndicator,
} from 'react-native';
import { billingApi, productsApi, customersApi, Product, Customer, InvoiceItem, Table } from '../api/business.api';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors, Colors, Radius } from '../theme';
import { IconButton } from 'react-native-paper';
import ModernToast from '../components/ModernToast';
import { LinearGradient } from 'expo-linear-gradient';

export default function BillingNewScreen() {
  const { features, themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [tables, setTables] = useState<Table[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [cartItems, setCartItems] = useState<(InvoiceItem & { name: string })[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'upi' | 'card'>('cash');
  const [tableId, setTableId] = useState('');
  const [saving, setSaving] = useState(false);
  const [customerModal, setCustomerModal] = useState(false);
  const [productModal, setProductModal] = useState(false);
  const [tableModal, setTableModal] = useState(false);
  const [searchProduct, setSearchProduct] = useState('');

  // Quick Customer Creation State
  const [isAddingCustomer, setIsAddingCustomer] = useState(false);
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('');
  const [savingCustomer, setSavingCustomer] = useState(false);
    const [customerSearch, setCustomerSearch] = useState('');
   const [globalDiscount, setGlobalDiscount] = useState<string>('0');
 
   const [toast, setToast] = useState<{ visible: boolean; msg: string; type: 'success' | 'error' }>({ 
     visible: false, msg: '', type: 'success' 
   });

   const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
     setToast({ visible: true, msg, type });
   };

  const handleCreateCustomer = async () => {
    if (!newCustomerName || !newCustomerPhone) {
      showToast('Missing details. Please provide both name and phone number.', 'error');
      return;
    }
    setSavingCustomer(true);
    try {
      const res = await customersApi.create({ name: newCustomerName, phone: newCustomerPhone });
      setCustomers([res, ...customers]);
      setSelectedCustomer(res);
      setIsAddingCustomer(false);
      setNewCustomerName('');
      setNewCustomerPhone('');
      showToast(`Success! ${res.name} has been registered.`, 'success');
      setCustomerModal(false);
    } catch (e: any) {
      showToast('Could not save customer. Please check the network connection.', 'error');
    } finally {
      setSavingCustomer(false);
    }
  };

  useEffect(() => {
    productsApi.list().then(setProducts);
    customersApi.list().then(setCustomers);
    if (features['table_mgmt']) {
      billingApi.listTables().then(setTables).catch(() => {});
    }
  }, [features]);

  const addToCart = (p: Product) => {
    const exists = cartItems.find(c => c.product_id === p.id);
    if (exists) {
      setCartItems(cartItems.map(c =>
        c.product_id === p.id ? { ...c, quantity: c.quantity + 1 } : c
      ));
    } else {
      setCartItems([...cartItems, {
        product_id: p.id, name: p.name,
        quantity: 1, unit_price: p.price, discount: 0, tax_percent: 0,
      }]);
    }
    // setProductModal(false); // DO NOT CLOSE - allow multiple selection for speed
  };

  const removeFromCart = (pid: number) => setCartItems(cartItems.filter(c => c.product_id !== pid));
  const updateQty = (pid: number, qty: number) => {
    if (qty <= 0) { removeFromCart(pid); return; }
    setCartItems(cartItems.map(c => c.product_id === pid ? { ...c, quantity: qty } : c));
  };

  const updateDiscount = (pid: number, discount: number) => {
    setCartItems(cartItems.map(c => c.product_id === pid ? { ...c, discount: discount } : c));
  };

  const itemsSubtotal = cartItems.reduce((sum, c) => sum + (c.unit_price * c.quantity - (c.discount || 0)), 0);
  const totalDiscountValue = parseFloat(globalDiscount) || 0;
  const grandTotal = Math.max(0, itemsSubtotal - totalDiscountValue);

  const handleCheckout = async (isKOT: boolean = false) => {
    if (!selectedCustomer && !isKOT) { showToast('Customer Required: Please select or add a client to proceed.', 'error'); return; }
    if (cartItems.length === 0) { showToast('Empty Cart: Add at least one item to generate an invoice.', 'error'); return; }
    setSaving(true);
    try {
      const invoice = await billingApi.createInvoice({
        customer_id: selectedCustomer ? selectedCustomer.id : undefined,
        items: cartItems.map(({ name, ...rest }) => rest),
        payment_method: paymentMethod,
        table_id: tableId ? parseInt(tableId) : undefined,
        invoice_status: isKOT ? 'Draft' : 'Paid',
        metadata_fields: {
          bill_discount: parseFloat(globalDiscount) || 0
        },
      });
       if (isKOT) {
        showToast('KOT Confirmed: Order has been transmitted to the kitchen.', 'success');
      } else {
        showToast(`Invoice Finalized: #${invoice.invoice_number} is ready for printing.`, 'success');
      }
      setCartItems([]); 
      if (!isKOT) setSelectedCustomer(null);
    } catch (e: any) {
      showToast('Transaction Failed: An error occurred while processing the invoice.', 'error');
    } finally { setSaving(false); }
  };

  return (
    <View style={[styles.container, { backgroundColor: Colors.bg.primary }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 100, paddingTop: 12 }}>
        {/* Compact Quick-Select Bar */}
        <View style={styles.compactHeaderRow}>
          <TouchableOpacity 
            style={[styles.clientCard, { backgroundColor: Colors.bg.card, borderColor: Colors.border.subtle, borderWidth: 1 }]}
            onPress={() => setCustomerModal(true)}
          >
            <IconButton icon="account-circle-outline" size={20} iconColor={Colors.brand.primary} style={{ margin: 0 }} />
            <Text style={[styles.clientName, { color: Colors.text.primary }]} numberOfLines={1}>
              {selectedCustomer ? selectedCustomer.name : 'Select Customer'}
            </Text>
            <IconButton icon="chevron-down" size={16} iconColor={Colors.text.disabled} style={{ margin: 0 }} />
          </TouchableOpacity>

          {features['table_mgmt'] && (
            <TouchableOpacity 
              style={[styles.tableChip, { backgroundColor: Colors.bg.card, borderColor: Colors.border.subtle, borderWidth: 1 }]}
              onPress={() => setTableModal(true)}
            >
              <IconButton icon="table-chair" size={18} iconColor="#10B981" style={{ margin: 0 }} />
              <Text style={[styles.tableTextCompact, { color: tableId ? Colors.text.primary : Colors.text.disabled }]}>
                {tableId ? tables.find(t => String(t.id) === tableId)?.table_number || tableId : 'Table'}
              </Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Quick Item Entry */}
        <View style={styles.actionRow}>
          <Text style={[styles.sectionHeading, { color: Colors.text.muted }]}>Order Details</Text>
          <TouchableOpacity 
            style={[styles.quickAddBtn, { backgroundColor: Colors.brand.primary }]}
            onPress={() => setProductModal(true)}
          >
            <IconButton icon="plus" size={16} iconColor="#fff" style={{ margin: 0 }} />
            <Text style={styles.quickAddText}>Add Item</Text>
          </TouchableOpacity>
        </View>

        {/* Modern List */}
        {cartItems.length === 0 ? (
          <View style={styles.emptyOrder}>
            <IconButton icon="cart-plus" size={48} iconColor={Colors.text.disabled} />
            <Text style={{ color: Colors.text.muted, fontWeight: '600' }}>No items in current order</Text>
          </View>
        ) : (
          cartItems.map((item) => (
            <View key={item.product_id} style={[styles.itemRow, { backgroundColor: Colors.bg.card, borderColor: Colors.border.subtle }]}>
              <View style={styles.itemMain}>
                <Text style={[styles.itemName, { color: Colors.text.primary }]}>{item.name}</Text>
                <Text style={[styles.itemPrice, { color: Colors.text.muted }]}>₹{item.unit_price}</Text>
              </View>
              <View style={styles.itemRight}>
                <Text style={[styles.itemTotal, { color: Colors.brand.primary }]}>₹{((item.unit_price * item.quantity) - item.discount).toFixed(2)}</Text>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <TouchableOpacity 
                    onPress={() => {
                      const d = prompt('Enter discount amount for this item:');
                      if (d) updateDiscount(item.product_id, parseFloat(d));
                    }}
                    style={[styles.miniBtn, { backgroundColor: Colors.bg.primary }]}
                  >
                    <Text style={{ fontSize: 10, color: Colors.brand.primary, fontWeight: '700' }}>{item.discount > 0 ? `-₹${item.discount}` : 'Disc'}</Text>
                  </TouchableOpacity>
                  <View style={[styles.modernQty, { backgroundColor: Colors.bg.primary }]}>
                    <TouchableOpacity onPress={() => updateQty(item.product_id, item.quantity - 1)} style={styles.qtyAction}>
                      <Text style={{ color: Colors.text.primary, fontWeight: '800' }}>−</Text>
                    </TouchableOpacity>
                    <Text style={[styles.qtyNum, { color: Colors.text.primary }]}>{item.quantity}</Text>
                    <TouchableOpacity onPress={() => updateQty(item.product_id, item.quantity + 1)} style={styles.qtyAction}>
                      <Text style={{ color: Colors.text.primary, fontWeight: '800' }}>+</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </View>
          ))
        )}

        {/* Pricing Summary */}
        <View style={[styles.summaryBox, { backgroundColor: Colors.bg.card }]}>
          <View style={styles.sumRow}>
            <Text style={{ color: Colors.text.muted }}>Items Total</Text>
            <Text style={{ color: Colors.text.primary, fontWeight: '700' }}>₹{cartItems.reduce((s,i) => s + i.unit_price * i.quantity, 0).toFixed(2)}</Text>
          </View>
          <View style={[styles.sumRow, { marginTop: 8 }]}>
            <Text style={{ color: Colors.text.muted }}>Bill Discount</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
               <Text style={{ color: Colors.brand.danger, fontWeight: '700' }}>-₹</Text>
               <TextInput 
                 value={globalDiscount}
                 onChangeText={setGlobalDiscount}
                 keyboardType="numeric"
                 style={{ color: Colors.brand.danger, fontWeight: '700', padding: 0, minWidth: 40, textAlign: 'right' }}
               />
            </View>
          </View>
          <View style={[styles.sumDivider, { backgroundColor: Colors.bg.primary }]} />
          
          <View style={styles.sumRow}>
            <Text style={{ color: Colors.text.primary, fontWeight: '800', fontSize: 15 }}>Total Payable</Text>
            <View>
              <LinearGradient
                colors={[Colors.brand.primary, Colors.brand.primary + 'CC']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.totalGradientBadge}
              >
                <Text style={styles.totalGradientText}>₹{grandTotal.toFixed(2)}</Text>
              </LinearGradient>
            </View>
          </View>
        </View>
      </ScrollView>

      <ModernToast 
        visible={toast.visible} 
        message={toast.msg} 
        type={toast.type} 
        onHide={() => setToast({ ...toast, visible: false })} 
        colors={Colors}
      />

      {/* Floating Action Bar */}
      <View style={[styles.floatingFooter, { backgroundColor: Colors.bg.card, borderTopColor: Colors.border.subtle }]}>
        <View style={styles.paymentMethods}>
          {(['cash', 'upi', 'card'] as const).map(m => (
            <TouchableOpacity 
              key={m} 
              onPress={() => setPaymentMethod(m)}
              style={[styles.payChip, { borderColor: Colors.border.subtle }, paymentMethod === m && { backgroundColor: Colors.brand.primary, borderColor: Colors.brand.primary }]}
            >
              <Text style={[styles.payChipText, { color: paymentMethod === m ? '#fff' : Colors.text.muted }]}>
                {m.charAt(0).toUpperCase() + m.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
        
        <TouchableOpacity 
          onPress={() => handleCheckout(false)} 
          disabled={saving}
          activeOpacity={0.8}
        >
          <LinearGradient
            colors={[Colors.brand.primary, Colors.brand.primary + 'EE']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.mainActionBtn}
          >
            {saving ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <>
                <Text style={styles.mainActionText}>Generate Invoice</Text>
                <View style={styles.actionArrowCircle}>
                  <IconButton icon="arrow-right" size={18} iconColor={Colors.brand.primary} style={{ margin: 0 }} />
                </View>
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>

      {/* Customer Modal */}
      <Modal visible={customerModal} animationType="slide" transparent>
        <View style={[styles.modalOverlay, { backgroundColor: Colors.bg.overlay }]}>
          <View style={[styles.modalCard, { backgroundColor: Colors.bg.card }]}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <Text style={[styles.modalTitle, { color: Colors.text.primary }]}>{isAddingCustomer ? 'New Customer' : 'Select Customer'}</Text>
              {!isAddingCustomer && (
                <TouchableOpacity onPress={() => setIsAddingCustomer(true)}>
                  <Text style={{ color: Colors.brand.primary, fontWeight: '700' }}>+ Add New</Text>
                </TouchableOpacity>
              )}
            </View>

            {isAddingCustomer ? (
              <View>
                <TextInput
                  style={[styles.input, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, color: Colors.text.primary, marginBottom: 10 }]}
                  value={newCustomerName}
                  onChangeText={setNewCustomerName}
                  placeholder="Customer Name *"
                  placeholderTextColor={Colors.text.muted}
                />
                <TextInput
                  style={[styles.input, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, color: Colors.text.primary, marginBottom: 16 }]}
                  value={newCustomerPhone}
                  onChangeText={setNewCustomerPhone}
                  placeholder="Phone Number *"
                  placeholderTextColor={Colors.text.muted}
                  keyboardType="phone-pad"
                />
                <TouchableOpacity
                  style={[styles.checkoutBtn, { backgroundColor: Colors.brand.primary, marginBottom: 10, paddingVertical: 12 }]}
                  onPress={handleCreateCustomer}
                  disabled={savingCustomer}
                >
                  {savingCustomer ? <ActivityIndicator color="#fff" /> : <Text style={styles.checkoutText}>Save & Select</Text>}
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setIsAddingCustomer(false)} style={[styles.closeBtn, { backgroundColor: Colors.bg.primary, marginTop: 0 }]}>
                  <Text style={[styles.closeText, { color: Colors.text.secondary }]}>Cancel</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <>
                <View style={[styles.modernSearchContainer, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.subtle }]}>
                  <IconButton icon="account-search" size={20} iconColor={Colors.brand.primary} />
                  <TextInput
                    style={[styles.modernSearchInput, { color: Colors.text.primary }]}
                    value={customerSearch}
                    onChangeText={setCustomerSearch}
                    placeholder="Search name or phone..."
                    placeholderTextColor={Colors.text.muted}
                  />
                  {customerSearch.length > 0 && (
                    <IconButton icon="close-circle" size={18} iconColor={Colors.text.disabled} onPress={() => setCustomerSearch('')} />
                  )}
                </View>

                <FlatList
                  data={customers.filter(c => c.name.toLowerCase().includes(customerSearch.toLowerCase()) || c.phone.includes(customerSearch))}
                  keyExtractor={c => String(c.id)}
                  contentContainerStyle={{ paddingBottom: 20 }}
                  renderItem={({ item }) => {
                    const initials = item.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
                    return (
                      <TouchableOpacity
                        style={[styles.modernCustomerItem, { backgroundColor: Colors.bg.card }]}
                        onPress={() => { setSelectedCustomer(item); setCustomerModal(false); }}
                      >
                        <View style={[styles.customerAvatar, { backgroundColor: Colors.brand.primary + '15' }]}>
                          <Text style={[styles.avatarTextSmall, { color: Colors.brand.primary }]}>{initials}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={[styles.customerItemName, { color: Colors.text.primary }]}>{item.name}</Text>
                          <Text style={[styles.customerItemPhone, { color: Colors.text.muted }]}>{item.phone}</Text>
                        </View>
                        <IconButton icon="chevron-right" size={18} iconColor={Colors.text.disabled} />
                      </TouchableOpacity>
                    );
                  }}
                  ListEmptyComponent={
                    <View style={styles.emptySearchBox}>
                      <IconButton icon="account-question-outline" size={40} iconColor={Colors.text.disabled} />
                      <Text style={{ color: Colors.text.muted, fontSize: 13, fontWeight: '600' }}>No matching customers</Text>
                    </View>
                  }
                />
                <TouchableOpacity onPress={() => setCustomerModal(false)} style={[styles.closeBtn, { backgroundColor: Colors.bg.primary }]}>
                  <Text style={[styles.closeText, { color: Colors.text.secondary }]}>Close</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>

      {/* Product Modal */}
      <Modal visible={productModal} animationType="slide" transparent>
        <View style={[styles.modalOverlay, { backgroundColor: Colors.bg.overlay }]}>
          <View style={[styles.modalCard, { backgroundColor: Colors.bg.card }]}>
            <View style={[styles.modernSearchContainer, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.subtle }]}>
              <IconButton icon="package-variant" size={20} iconColor={Colors.brand.primary} />
              <TextInput
                style={[styles.modernSearchInput, { color: Colors.text.primary }]}
                value={searchProduct}
                onChangeText={setSearchProduct}
                placeholder="Search product name..."
                placeholderTextColor={Colors.text.muted}
              />
              {searchProduct.length > 0 && (
                <IconButton icon="close-circle" size={18} iconColor={Colors.text.disabled} onPress={() => setSearchProduct('')} />
              )}
            </View>

            <FlatList
              data={products.filter(p => p.name.toLowerCase().includes(searchProduct.toLowerCase()))}
              keyExtractor={p => String(p.id)}
              contentContainerStyle={{ paddingBottom: 20 }}
              renderItem={({ item }) => (
                <TouchableOpacity 
                  style={[styles.modernProductItem, { backgroundColor: Colors.bg.primary + '33' }]} 
                  onPress={() => addToCart(item)}
                >
                  <View style={[styles.productBadge, { backgroundColor: Colors.brand.primary + '15' }]}>
                    <IconButton icon="package-variant-closed" size={20} iconColor={Colors.brand.primary} style={{ margin: 0 }} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.productItemName, { color: Colors.text.primary }]}>{item.name}</Text>
                    <Text style={[styles.productItemSub, { color: Colors.text.muted }]}>
                      Stock: <Text style={{ color: item.stock_qty < 10 ? Colors.brand.danger : Colors.brand.success }}>{item.stock_qty}</Text>
                    </Text>
                  </View>
                  <View style={{ alignItems: 'flex-end' }}>
                    <Text style={[styles.productItemPrice, { color: Colors.brand.primary }]}>₹{item.price}</Text>
                    <IconButton icon="plus-circle" size={20} iconColor={Colors.brand.primary} style={{ margin: 0, marginTop: 4 }} />
                  </View>
                </TouchableOpacity>
              )}
              ListEmptyComponent={
                <View style={styles.emptySearchBox}>
                  <IconButton icon="package-variant-remove" size={40} iconColor={Colors.text.disabled} />
                  <Text style={{ color: Colors.text.muted, fontSize: 13, fontWeight: '600' }}>No products found</Text>
                </View>
              }
            />
            <TouchableOpacity onPress={() => setProductModal(false)} style={[styles.closeBtn, { backgroundColor: Colors.bg.primary }]}>
              <Text style={[styles.closeText, { color: Colors.text.secondary }]}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Table Map Modal */}
      <Modal visible={tableModal} animationType="slide" transparent>
        <View style={[styles.modalOverlay, { backgroundColor: Colors.bg.overlay }]}>
          <View style={[styles.modalCard, { backgroundColor: Colors.bg.card }]}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <Text style={[styles.modalTitle, { color: Colors.text.primary }]}>Restaurant Seat Map</Text>
              {tableId ? (
                <TouchableOpacity onPress={() => { setTableId(''); setTableModal(false); }}>
                  <Text style={{ color: Colors.brand.danger, fontWeight: '700' }}>Clear Table</Text>
                </TouchableOpacity>
              ) : null}
            </View>
            <Text style={{ color: Colors.text.muted, marginBottom: 16, fontSize: 13 }}>
              Select a table to allocate to this customer order:
            </Text>
            <ScrollView showsVerticalScrollIndicator={false}>
              {tables.length === 0 ? (
                <Text style={{ color: Colors.text.muted, textAlign: 'center', marginTop: 20 }}>No tables available. Please configure tables in settings.</Text>
              ) : (
                <View style={styles.tableGrid}>
                  {tables.map((t) => (
                    <TouchableOpacity
                      key={t.id}
                      style={[
                        styles.tableCard,
                        { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default },
                        tableId === String(t.id) && [styles.tableCardActive, { borderColor: Colors.brand.primary, backgroundColor: Colors.brand.primary + '22' }]
                      ]}
                      onPress={() => {
                        setTableId(String(t.id));
                        setTableModal(false);
                      }}
                    >
                      <Text style={[styles.tableIcon, tableId === String(t.id) && { color: Colors.brand.primary }]}>🪑</Text>
                      <Text style={[styles.tableNum, { color: Colors.text.secondary }, tableId === String(t.id) && { color: Colors.brand.primary, fontWeight: '800' }]}>
                        {t.table_number}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              )}
            </ScrollView>
            <TouchableOpacity onPress={() => setTableModal(false)} style={[styles.closeBtn, { backgroundColor: Colors.bg.primary, marginTop: 16 }]}>
              <Text style={[styles.closeText, { color: Colors.text.secondary }]}>Close Map</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0F172A' },
  compactHeaderRow: { flexDirection: 'row', paddingHorizontal: 16, paddingBottom: 12, gap: 10, alignItems: 'center' },
  clientCard: { flex: 1, height: 44, borderRadius: 12, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, borderWidth: 1 },
  clientName: { flex: 1, fontSize: 13, fontWeight: '700', marginLeft: 4 },
  tableChip: { width: 90, height: 44, borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', borderWidth: 1, paddingRight: 8 },
  tableTextCompact: { fontSize: 13, fontWeight: '800' },
  
  actionRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, marginBottom: 12, marginTop: 4 },
  sectionHeading: { fontSize: 15, fontWeight: '800', letterSpacing: 0.5 },
  quickAddBtn: { flexDirection: 'row', alignItems: 'center', paddingRight: 12, borderRadius: 10, height: 32 },
  quickAddText: { color: '#fff', fontSize: 10, fontWeight: '900' },
  
  emptyOrder: { padding: 60, alignItems: 'center', justifyContent: 'center', opacity: 0.3 },
  itemRow: { marginHorizontal: 16, marginBottom: 8, borderRadius: 12, padding: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderWidth: 1 },
  itemName: { fontSize: 13, fontWeight: '700', marginBottom: 2 },
  itemPrice: { fontSize: 11, fontWeight: '600' },
  itemRight: { alignItems: 'flex-end', gap: 4 },
  itemTotal: { fontSize: 14, fontWeight: '800' },
  modernQty: { flexDirection: 'row', alignItems: 'center', borderRadius: 6, padding: 1 },
  qtyAction: { width: 24, height: 24, justifyContent: 'center', alignItems: 'center' },
  qtyNum: { fontSize: 12, fontWeight: '800', paddingHorizontal: 6 },
  miniBtn: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, justifyContent: 'center', alignItems: 'center' },
  
  summaryBox: { margin: 16, padding: 14, borderRadius: 16 },
  sumRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  sumDivider: { height: 1, marginVertical: 10, opacity: 0.2 },
  
  totalGradientBadge: { paddingHorizontal: 16, paddingVertical: 6, borderRadius: 100 },
  totalGradientText: { color: '#fff', fontSize: 18, fontWeight: '900' },
  
  floatingFooter: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 16, paddingBottom: 24, borderTopWidth: 1 },
  paymentMethods: { flexDirection: 'row', gap: 6, marginBottom: 12 },
  payChip: { flex: 1, height: 32, borderRadius: 8, justifyContent: 'center', alignItems: 'center', backgroundColor: '#88888810', borderWidth: 1 },
  payChipText: { fontSize: 10, fontWeight: '800' },
  mainActionBtn: { height: 54, borderRadius: 18, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', elevation: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 10 },
  mainActionText: { color: '#fff', fontSize: 15, fontWeight: '900', letterSpacing: 0.5, flex: 1, textAlign: 'center', marginLeft: 44 },
  actionArrowCircle: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#fff', justifyContent: 'center', alignItems: 'center', marginRight: 8 },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  totalLabel: { color: '#94A3B8', fontSize: 14 },
  totalVal: { color: '#F1F5F9', fontSize: 14 },
  grandTotal: { fontSize: 20, fontWeight: '800' },
  paymentRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  payBtn: { flex: 1, paddingVertical: 12, borderRadius: 10, backgroundColor: '#1E293B', alignItems: 'center', borderWidth: 1, borderColor: '#334155' },
  payBtnActive: { backgroundColor: '#1E3A5F', borderColor: '#6366F1' },
  payBtnText: { color: '#94A3B8', fontWeight: '600' },
  payBtnTextActive: { color: '#60A5FA' },
  checkoutBtn: { backgroundColor: '#6366F1', borderRadius: 12, paddingVertical: 16, alignItems: 'center', marginBottom: 32 },
  checkoutText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  modalOverlay: { flex: 1, backgroundColor: '#00000090', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: '#1E293B', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '85%' },
  modalTitle: { fontSize: 18, fontWeight: '900', color: '#F1F5F9' },
  
  modernSearchContainer: { flexDirection: 'row', alignItems: 'center', borderRadius: 16, borderWidth: 1, paddingHorizontal: 8, height: 48, marginBottom: 16 },
  modernSearchInput: { flex: 1, fontSize: 14, fontWeight: '600' },
  
  modernCustomerItem: { flexDirection: 'row', alignItems: 'center', padding: 12, borderRadius: 16, marginBottom: 8, gap: 12 },
  customerAvatar: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  avatarTextSmall: { fontSize: 13, fontWeight: '800' },
  headerGreeting: { fontSize: 10, fontWeight: '700', letterSpacing: 1 },
  headerTitle: { fontSize: 20, fontWeight: '900', marginTop: 2 },
  
  modernProductItem: { flexDirection: 'row', alignItems: 'center', padding: 12, borderRadius: 16, marginBottom: 10, gap: 12 },
  productBadge: { width: 42, height: 42, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  productItemName: { fontSize: 14, fontWeight: '700' },
  productItemSub: { fontSize: 11, fontWeight: '600', marginTop: 2 },
  productItemPrice: { fontSize: 15, fontWeight: '900' },
  
  emptySearchBox: { padding: 40, alignItems: 'center', justifyContent: 'center' },
  
  closeBtn: { marginTop: 12, paddingVertical: 13, borderRadius: 16, backgroundColor: '#334155', alignItems: 'center' },
  closeText: { color: '#CBD5E1', fontWeight: '600' },
  tableGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, justifyContent: 'center', paddingTop: 8 },
  tableCard: { width: '30%', backgroundColor: '#0F172A', borderRadius: 12, padding: 16, alignItems: 'center', borderWidth: 2, borderColor: '#334155' },
  tableCardActive: { borderColor: '#6366F1', backgroundColor: '#6366F122' },
  tableIcon: { fontSize: 24, marginBottom: 8, opacity: 0.8 },
  tableNum: { color: '#94A3B8', fontWeight: '600', fontSize: 13 },
});
