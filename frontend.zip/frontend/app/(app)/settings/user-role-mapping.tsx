import UserRoleMappingScreen from '../../../src/screens/UserRoleMappingScreen';
export default UserRoleMappingScreen;
