import DevSettingsScreen from '../src/screens/DevSettingsScreen';
export default DevSettingsScreen;
