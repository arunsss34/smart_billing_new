import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  ActivityIndicator, Alert, TextInput,
} from 'react-native';
import { IconButton } from 'react-native-paper';
import api from '../api/client';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors, Radius } from '../theme';

interface User {
  id: number;
  username: string;
  full_name: string;
  tenant_role_id: number | null;
  tenant_role_name: string | null;
}

interface TenantRole { id: number; name: string; }

export default function UserRoleMappingScreen() {
  const { themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);

  const [users, setUsers] = useState<User[]>([]);
  const [roles, setRoles] = useState<TenantRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [saving, setSaving] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [uRes, rRes] = await Promise.all([
        api.get('/users/'),
        api.get('/roles/'),
      ]);
      setUsers(uRes.data);
      setRoles(rRes.data.filter((r: any) => r.tenant_id !== null));
    } catch (e: any) {
      Alert.alert('Error', 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const updateRole = async (userId: number, roleId: number) => {
    setSaving(userId);
    try {
      await api.put(`/users/${userId}`, { tenant_role_id: roleId });
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, tenant_role_id: roleId, tenant_role_name: roles.find(r => r.id === roleId)?.name || null } : u));
    } catch (e: any) {
      Alert.alert('Error', 'Failed to update role');
    } finally {
      setSaving(null);
    }
  };

  const filteredUsers = users.filter(u => 
    u.full_name.toLowerCase().includes(search.toLowerCase()) || 
    u.username.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) return (
    <View style={[s.center, { backgroundColor: Colors.bg.primary }]}>
      <ActivityIndicator color={Colors.brand.primary} />
    </View>
  );

  return (
    <View style={[s.container, { backgroundColor: Colors.bg.primary }]}>
      <View style={s.actionHeader}>
        <View style={[s.searchBar, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
          <IconButton icon="magnify" size={18} iconColor={Colors.text.muted} style={{ margin: 0 }} />
          <TextInput 
            style={[s.searchInput, { color: Colors.text.primary }]} 
            value={search} 
            onChangeText={setSearch} 
            placeholder="Search users to map..." 
            placeholderTextColor={Colors.text.muted} 
          />
        </View>
      </View>

      <FlatList
        data={filteredUsers}
        keyExtractor={u => String(u.id)}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 40 }}
        renderItem={({ item: u }) => (
          <View style={[s.listItem, { borderBottomColor: Colors.border.subtle }]}>
            <View style={s.userRowTop}>
              <View style={[s.avatar, { backgroundColor: Colors.brand.primary + '15' }]}>
                <Text style={[s.avatarTxt, { color: Colors.brand.primary }]}>{u.full_name[0].toUpperCase()}</Text>
              </View>
              <View style={s.userInfo}>
                <Text style={[s.uName, { color: Colors.text.primary }]}>{u.full_name}</Text>
                <Text style={[s.uMeta, { color: Colors.text.secondary }]}>@{u.username}</Text>
              </View>
              <View style={s.activeRoleBadge}>
                <IconButton icon="shield-check" size={16} iconColor={Colors.brand.success} style={{ margin: 0 }} />
                <Text style={[s.activeRoleTxt, { color: Colors.brand.success }]}>{u.tenant_role_name || 'No Role'}</Text>
              </View>
            </View>

            <View style={s.roleSelector}>
              <IconButton icon="account-cog" size={18} iconColor={Colors.text.muted} style={{ marginRight: 4, marginLeft: -4 }} />
              <FlatList
                horizontal
                showsHorizontalScrollIndicator={false}
                data={roles}
                keyExtractor={r => String(r.id)}
                renderItem={({ item: r }) => {
                  const active = u.tenant_role_id === r.id;
                  return (
                    <TouchableOpacity
                      style={[
                        s.roleChip, 
                        { borderColor: Colors.border.default },
                        active && { borderColor: Colors.brand.primary, backgroundColor: Colors.brand.primary + '15' }
                      ]}
                      onPress={() => !active && updateRole(u.id, r.id)}
                      disabled={saving === u.id}
                    >
                      {saving === u.id && active ? (
                        <ActivityIndicator size="small" color={Colors.brand.primary} />
                      ) : (
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                          {active && <IconButton icon="check-circle" size={12} iconColor={Colors.brand.primary} style={{ margin: 0, padding: 0, width: 14, height: 14 }} />}
                          <Text style={[s.roleChipTxt, { color: Colors.text.muted }, active && { color: Colors.brand.primary, fontWeight: '700' }]}>
                            {r.name}
                          </Text>
                        </View>
                      )}
                    </TouchableOpacity>
                  );
                }}
              />
            </View>
          </View>
        )}
      />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 12, paddingTop: 8 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  actionHeader: { marginVertical: 12 },
  searchBar: { flexDirection: 'row', alignItems: 'center', height: 40, borderRadius: 10, borderWidth: 1, paddingHorizontal: 4 },
  searchInput: { flex: 1, fontSize: 13, fontWeight: '500' },
  listItem: { paddingVertical: 14, borderBottomWidth: 1 },
  userRowTop: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  avatar: { width: 40, height: 40, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  avatarTxt: { fontSize: 16, fontWeight: '800' },
  userInfo: { flex: 1, marginLeft: 12 },
  uName: { fontSize: 15, fontWeight: '700' },
  uMeta: { fontSize: 12, marginTop: 1 },
  activeRoleBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#ecfdf5', paddingRight: 8, borderRadius: 6 },
  activeRoleTxt: { fontSize: 10, fontWeight: '800' },
  roleSelector: { flexDirection: 'row', alignItems: 'center' },
  roleChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, borderWidth: 1, marginRight: 8, justifyContent: 'center', alignItems: 'center', minWidth: 70 },
  roleChipTxt: { fontSize: 11, fontWeight: '600' },
});
