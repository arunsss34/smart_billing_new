import api from './client';

export interface BusinessType {
  id: number;
  name: string;
  label: string;
  icon: string;
  description: string;
  default_features: string[];
  is_active: boolean;
  created_at: string;
}

export interface BusinessTypeCreate {
  name: string;
  label: string;
  icon: string;
  description?: string;
  default_features: string[];
}

// All available feature flags in the system
export const ALL_FEATURES = [
  { key: 'kot',               label: 'Kitchen Order Ticket (KOT)', icon: '🍳' },
  { key: 'table_mgmt',        label: 'Table Management',           icon: '🪑' },
  { key: 'barcode',           label: 'Barcode Scanning',           icon: '📷' },
  { key: 'expiry_tracking',   label: 'Expiry Date Tracking',       icon: '📅' },
  { key: 'size_color_variants', label: 'Size & Color Variants',    icon: '👗' },
  { key: 'imei_tracking',     label: 'IMEI Tracking',              icon: '📱' },
  { key: 'loyalty_points',    label: 'Loyalty Points',             icon: '⭐' },
  { key: 'home_delivery',     label: 'Home Delivery',              icon: '🚚' },
  { key: 'gst_billing',       label: 'GST Billing',                icon: '📃' },
];

export const EMOJI_PICKER = [
  '🏪','🍽️','🥐','🛒','👗','📱','💊','💈','🏥','🎮',
  '📚','🖥️','🚗','🏠','⚙️','🧴','🥩','🍕','☕','🎂',
  '🏋️','🌿','💍','👟','🧸','🐾','🔧','🏗️','🎵','🏦',
];

export const businessTypeApi = {
  list: async (): Promise<BusinessType[]> => {
    const res = await api.get('/business-types/');
    return res.data;
  },

  create: async (data: BusinessTypeCreate): Promise<BusinessType> => {
    const res = await api.post('/business-types/', data);
    return res.data;
  },

  update: async (id: number, data: Partial<BusinessTypeCreate> & { is_active?: boolean }): Promise<BusinessType> => {
    const res = await api.put(`/business-types/${id}`, data);
    return res.data;
  },

  deactivate: async (id: number): Promise<void> => {
    await api.delete(`/business-types/${id}`);
  },
};
