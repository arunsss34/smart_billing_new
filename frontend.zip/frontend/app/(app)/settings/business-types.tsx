import BusinessTypesScreen from '../../../src/screens/BusinessTypesScreen';
export default BusinessTypesScreen;
