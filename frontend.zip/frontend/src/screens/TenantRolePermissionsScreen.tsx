import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  ActivityIndicator, Alert, TextInput,
} from 'react-native';
import { IconButton } from 'react-native-paper';
import api from '../api/client';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors, Radius, Spacing, FontSize } from '../theme';

interface TenantRole { id: number; name: string; description: string | null; }
interface MenuPerm {
  menu_id: number;
  menu_name: string;
  route: string;
  icon: string;
  parent_id: number | null;
  sort_order: number;
  can_view: boolean;
  can_add: boolean;
  can_edit: boolean;
  can_delete: boolean;
}

const PERM_COLS = [
  { key: 'can_view',   label: 'View',   color: '#10B981' },
  { key: 'can_add',    label: 'Add',    color: '#6366F1' },
  { key: 'can_edit',   label: 'Edit',   color: '#F59E0B' },
  { key: 'can_delete', label: 'Del',    color: '#EF4444' },
] as const;

const ROLE_COLORS = ['#6366F1','#10B981','#F59E0B','#EF4444','#8B5CF6','#06B6D4'];

export default function TenantRolePermissionsScreen() {
  const { themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);

  const [roles, setRoles] = useState<TenantRole[]>([]);
  const [selectedRole, setSelectedRole] = useState<TenantRole | null>(null);
  const [menus, setMenus] = useState<MenuPerm[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMenus, setLoadingMenus] = useState(false);
  const [saving, setSaving] = useState<number | null>(null);
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get('/roles/');
        setRoles(data.filter((r: any) => r.tenant_id !== null && r.tenant_id !== undefined));
      } catch (e: any) {
        Alert.alert('Error', e?.response?.data?.detail || 'Failed to load roles');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const loadMenus = useCallback(async (role: TenantRole) => {
    setLoadingMenus(true);
    setSelectedRole(role);
    try {
      const { data } = await api.get(`/menus/tenant-role-permissions/${role.id}`);
      setMenus(data);
    } catch (e: any) {
      Alert.alert('Error', e?.response?.data?.detail || 'Failed to load permissions');
    } finally {
      setLoadingMenus(false);
    }
  }, []);

  const togglePerm = async (menu: MenuPerm, permKey: typeof PERM_COLS[number]['key']) => {
    if (!selectedRole) return;
    const updated = { ...menu, [permKey]: !menu[permKey] };

    if (permKey === 'can_view' && menu.can_view) {
      updated.can_add = false;
      updated.can_edit = false;
      updated.can_delete = false;
    }
    if (permKey !== 'can_view' && !menu.can_view && updated[permKey]) {
      updated.can_view = true;
    }

    setMenus(prev => prev.map(m => m.menu_id === menu.menu_id ? updated : m));
    setSaving(menu.menu_id);

    try {
      await api.put(`/menus/tenant-role-permissions/${selectedRole.id}`, {
        menu_id:    menu.menu_id,
        can_view:   updated.can_view,
        can_add:    updated.can_add,
        can_edit:   updated.can_edit,
        can_delete: updated.can_delete,
      });
    } catch (e: any) {
      setMenus(prev => prev.map(m => m.menu_id === menu.menu_id ? menu : m));
      Alert.alert('Error', e?.response?.data?.detail || 'Failed to update');
    } finally {
      setSaving(null);
    }
  };

  const filteredMenus = menus.filter(m => 
    m.menu_name.toLowerCase().includes(search.toLowerCase())
  );

  const parents = filteredMenus.filter(m => !m.parent_id);
  const children = filteredMenus.filter(m => m.parent_id);
  const getChildren = (pid: number) => children.filter(c => c.parent_id === pid);

  const renderPermRow = (menu: MenuPerm, isChild = false) => (
    <View key={menu.menu_id} style={[s.menuRow, { borderBottomColor: Colors.border.subtle }, isChild && { marginLeft: 20 }]}>
      <View style={s.menuNameBox}>
        {isChild && <Text style={[s.childArrow, { color: Colors.text.disabled }]}>↳</Text>}
        <Text style={[s.menuName, { color: isChild ? Colors.text.secondary : Colors.text.primary }]}>
          {menu.menu_name}
        </Text>
        {saving === menu.menu_id && (
          <ActivityIndicator size="small" color={Colors.brand.primary} style={{ marginLeft: 6 }} />
        )}
      </View>
      <View style={s.permCols}>
        {PERM_COLS.map(col => (
          <TouchableOpacity
            key={col.key}
            style={[s.permBtn, { borderColor: Colors.border.default }, menu[col.key] && { backgroundColor: col.color + '22', borderColor: col.color }]}
            onPress={() => togglePerm(menu, col.key)}
            disabled={saving === menu.menu_id}
          >
            <Text style={[s.permBtnTxt, { color: Colors.text.muted }, menu[col.key] && { color: col.color, fontWeight: '700' }]}>
              {col.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  return (
    <View style={[s.container, { backgroundColor: Colors.bg.primary }]}>
      <View style={s.actionHeader}>
        <View style={[s.searchBar, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default, marginBottom: 12 }]}>
          <IconButton icon="magnify" size={18} iconColor={Colors.text.muted} style={{ margin: 0 }} />
          <TextInput 
            style={[s.searchInput, { color: Colors.text.primary }]} 
            value={search} 
            onChangeText={setSearch} 
            placeholder="Search permissions..." 
            placeholderTextColor={Colors.text.muted} 
          />
        </View>

        <Text style={[s.sectionLabel, { color: Colors.text.secondary }]}>Select a Role</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.roleScroll}>
          {roles.map((r, i) => {
            const color = ROLE_COLORS[i % ROLE_COLORS.length];
            const active = selectedRole?.id === r.id;
            return (
              <TouchableOpacity
                key={r.id}
                style={[s.roleChip, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }, active && { borderColor: color, backgroundColor: color + '15' }]}
                onPress={() => loadMenus(r)}
                activeOpacity={0.8}
              >
                <Text style={[s.roleChipTxt, { color: Colors.text.secondary }, active && { color, fontWeight: '700' }]}>{r.name}</Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>

      {loading
        ? <ActivityIndicator color={Colors.brand.primary} style={{ marginTop: 20 }} />
        : roles.length === 0
          ? <View style={s.emptyBox}>
              <Text style={s.emptyIcon}>🛡</Text>
              <Text style={[s.emptyTitle, { color: Colors.text.primary }]}>No Roles Created Yet</Text>
              <Text style={[s.emptyDesc, { color: Colors.text.muted }]}>Create roles in Settings first.</Text>
            </View>
          : <>


              {selectedRole && (
                loadingMenus
                  ? <ActivityIndicator color={Colors.brand.primary} style={{ marginTop: 30 }} />
                  : <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }}>
                      <View style={[s.tableHeader, { backgroundColor: Colors.bg.surface, borderColor: Colors.border.default }]}>
                        <Text style={[s.tableHeaderMenu, { color: Colors.text.muted }]}>Menu</Text>
                        {PERM_COLS.map(col => (
                          <Text key={col.key} style={[s.tableHeaderPerm, { color: col.color }]}>{col.label}</Text>
                        ))}
                      </View>

                      {parents.map(parent => (
                        <View key={parent.menu_id} style={s.menuGroup}>
                          {renderPermRow(parent)}
                          {getChildren(parent.menu_id).map(child => renderPermRow(child, true))}
                        </View>
                      ))}
                      <View style={{ height: 60 }} />
                    </ScrollView>
              )}

              {!selectedRole && (
                <View style={s.hintBox}>
                  <Text style={[s.hintTxt, { color: Colors.text.muted }]}>👆 Select a role above to configure its permissions</Text>
                </View>
              )}
            </>
      }
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 12, paddingTop: 8 },
  actionHeader: { marginVertical: 12 },
  searchBar: { flexDirection: 'row', alignItems: 'center', height: 40, borderRadius: 10, borderWidth: 1, paddingHorizontal: 4 },
  searchInput: { flex: 1, fontSize: 13, fontWeight: '500' },
  sectionLabel: { fontSize: 10, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 8 },
  roleScroll: { flexGrow: 0 },
  roleChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 10, borderWidth: 1, marginRight: 8 },
  roleChipTxt: { fontSize: 13, fontWeight: '600' },
  tableHeader: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, paddingHorizontal: 12, borderBottomWidth: 1 },
  tableHeaderMenu: { flex: 1, fontSize: 11, fontWeight: '800', textTransform: 'uppercase' },
  tableHeaderPerm: { width: 44, textAlign: 'center', fontSize: 11, fontWeight: '800', textTransform: 'uppercase' },
  menuGroup: { },
  menuRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 4, borderBottomWidth: 1 },
  menuNameBox: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 6 },
  childArrow: { fontSize: 14, marginTop: -2 },
  menuName: { fontSize: 14, fontWeight: '600' },
  permCols: { flexDirection: 'row', gap: 6 },
  permBtn: { width: 38, height: 28, borderRadius: 6, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  permBtnTxt: { fontSize: 9, fontWeight: '700' },
  emptyBox: { alignItems: 'center', paddingTop: 60, paddingHorizontal: 30 },
  emptyIcon: { fontSize: 48, marginBottom: 10 },
  emptyTitle: { fontSize: 18, fontWeight: '700', marginBottom: 6 },
  emptyDesc: { fontSize: 14, textAlign: 'center', lineHeight: 20 },
  hintBox: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  hintTxt: { fontSize: 14, textAlign: 'center' },
});
