import React from 'react';
import { Modal, View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors, Radius, FontSize, Spacing } from '../theme';

interface ConfirmModalProps {
  visible: boolean;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  onConfirm: () => void;
  onCancel: () => void;
  type?: 'danger' | 'info' | 'warning';
}

export default function ConfirmModal({
  visible,
  title,
  message,
  confirmText = 'Confirm',
  cancelText = 'Cancel',
  onConfirm,
  onCancel,
  type = 'info'
}: ConfirmModalProps) {
  const { themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);

  const typeColor = type === 'danger' ? Colors.brand.danger : 
                    type === 'warning' ? Colors.brand.warning : 
                    Colors.brand.primary;

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={s.overlay}>
        <View style={[s.modalCard, { backgroundColor: Colors.bg.card }]}>
          <View style={s.content}>
            <View style={[s.iconCircle, { backgroundColor: typeColor + '15' }]}>
              <Text style={[s.iconText, { color: typeColor }]}>
                {type === 'danger' ? '⚠️' : type === 'warning' ? '🔔' : '❓'}
              </Text>
            </View>
            <Text style={[s.title, { color: Colors.text.primary }]}>{title}</Text>
            <Text style={[s.message, { color: Colors.text.secondary }]}>{message}</Text>
          </View>
          
          <View style={[s.footer, { borderTopColor: Colors.border.subtle }]}>
            <TouchableOpacity 
              style={[s.btn, { backgroundColor: Colors.bg.surface }]} 
              onPress={onCancel}
              activeOpacity={0.7}
            >
              <Text style={[s.btnText, { color: Colors.text.secondary }]}>{cancelText}</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[s.btn, { backgroundColor: typeColor }]} 
              onPress={onConfirm}
              activeOpacity={0.8}
            >
              <Text style={[s.btnText, { color: '#fff' }]}>{confirmText}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center', padding: 30 },
  modalCard: { width: '100%', maxWidth: 340, borderRadius: 24, overflow: 'hidden', elevation: 20 },
  content: { padding: 30, alignItems: 'center' },
  iconCircle: { width: 64, height: 64, borderRadius: 32, justifyContent: 'center', alignItems: 'center', marginBottom: 20 },
  iconText: { fontSize: 28 },
  title: { fontSize: 20, fontWeight: '800', marginBottom: 12, textAlign: 'center' },
  message: { fontSize: 15, textAlign: 'center', lineHeight: 22 },
  footer: { flexDirection: 'row', gap: 12, padding: 20, borderTopWidth: 1 },
  btn: { flex: 1, paddingVertical: 14, borderRadius: 16, alignItems: 'center' },
  btnText: { fontWeight: '700', fontSize: 15 },
});
