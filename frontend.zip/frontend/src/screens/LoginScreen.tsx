import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ActivityIndicator, KeyboardAvoidingView,
  Platform, Alert, StatusBar, Dimensions, Image
} from 'react-native';
import { useRouter } from 'expo-router';
import { IconButton } from 'react-native-paper';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors } from '../theme';

const { width } = Dimensions.get('window');

export default function LoginScreen() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const { login, isLoading } = useAuthStore();
  const { mode } = useThemeStore();
  const router = useRouter();

  const isDark = mode === 'dark';
  const Colors = getColors(mode);

  const handleLogin = async () => {
    const trimmedUser = username.trim();
    const trimmedPass = password.trim();

    if (!trimmedUser || !trimmedPass) {
      Alert.alert('Validation Error', 'Please enter your username and password.');
      return;
    }

    // Static Developer Login
    if (trimmedUser === 'nura' && trimmedPass === 'nura@123') {
      router.push('/dev-settings');
      return;
    }

    try {
      await login(trimmedUser, trimmedPass);
      router.replace('/(app)/dashboard');
    } catch (err: any) {
      Alert.alert('Login Failed', err?.response?.data?.detail || 'Invalid username or password.');
    }
  };

  return (
    <View style={[s.container, { backgroundColor: Colors.bg.primary }]}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} />
      
      <KeyboardAvoidingView 
        style={s.keyboardView} 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <View style={s.inner}>
          
          {/* Brand Header */}
          <View style={s.header}>
            <Image 
              source={require('../../assets/logo.png')} 
              style={s.logoImg} 
              resizeMode="contain"
            />
            <Text style={[s.welcomeTitle, { color: Colors.text.primary }]}>Welcome Back</Text>
            <Text style={[s.welcomeSub, { color: Colors.text.muted }]}>Please sign in to your dashboard</Text>
          </View>

          {/* Login Form */}
          <View style={s.form}>
            <View style={s.inputGroup}>
              <View style={s.labelRow}>
                <Text style={[s.label, { color: Colors.text.secondary }]}>Username</Text>
              </View>
              <View style={[s.inputWrapper, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
                <IconButton icon="account-outline" size={20} iconColor={Colors.text.muted} style={s.inputIcon} />
                <TextInput
                  style={[s.input, { color: Colors.text.primary }]}
                  value={username}
                  onChangeText={setUsername}
                  placeholder="Enter your username"
                  placeholderTextColor={Colors.text.muted}
                  autoCapitalize="none"
                />
              </View>
            </View>

            <View style={s.inputGroup}>
              <View style={s.labelRow}>
                <Text style={[s.label, { color: Colors.text.secondary }]}>Password</Text>
                <TouchableOpacity><Text style={[s.forgotLink, { color: Colors.brand.primary }]}>Forgot password?</Text></TouchableOpacity>
              </View>
              <View style={[s.inputWrapper, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
                <IconButton icon="lock-outline" size={20} iconColor={Colors.text.muted} style={s.inputIcon} />
                <TextInput
                  style={[s.input, { flex: 1, color: Colors.text.primary }]}
                  value={password}
                  onChangeText={setPassword}
                  placeholder="Enter your password"
                  placeholderTextColor={Colors.text.muted}
                  secureTextEntry={!showPass}
                />
                <TouchableOpacity onPress={() => setShowPass(!showPass)} style={s.eyeBtn}>
                  <IconButton icon={showPass ? "eye-off-outline" : "eye-outline"} size={20} iconColor={Colors.text.muted} style={{ margin: 0 }} />
                </TouchableOpacity>
              </View>
            </View>

            <TouchableOpacity 
              style={[s.loginBtn, { backgroundColor: Colors.brand.primary }]}
              onPress={handleLogin}
              disabled={isLoading}
              activeOpacity={0.8}
            >
              {isLoading ? (
                <ActivityIndicator color="#FFF" />
              ) : (
                <View style={s.btnContent}>
                  <IconButton icon="login-variant" size={22} iconColor="#FFF" style={{ margin: 0, marginRight: -4 }} />
                  <Text style={s.loginBtnText}>Secure Login</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>

          {/* Support Section */}
          <View style={s.footer}>
            <Text style={[s.footerText, { color: Colors.text.muted }]}>Technical issues?</Text>
            <TouchableOpacity>
              <Text style={[s.supportLink, { color: Colors.brand.primary }]}> Contact Support</Text>
            </TouchableOpacity>
          </View>

        </View>

        <Text style={[s.copyright, { color: Colors.text.disabled }]}>© 2024 Smart Billing Solutions</Text>
      </KeyboardAvoidingView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1 },
  keyboardView: { flex: 1 },
  inner: { flex: 1, justifyContent: 'center', paddingHorizontal: 32 },
  
  header: { alignItems: 'center', marginBottom: 32 },
  logoImg: { width: 110, height: 110 },
  welcomeTitle: { fontSize: 24, fontWeight: '800', marginTop: 16, letterSpacing: -0.5 },
  welcomeSub: { fontSize: 14, fontWeight: '500', marginTop: 4, opacity: 0.8 },

  form: { width: '100%' },
  inputGroup: { marginBottom: 16 },
  labelRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  label: { fontSize: 12, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.8 },
  forgotLink: { fontSize: 12, fontWeight: '700' },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 1,
    paddingRight: 4,
  },
  inputIcon: { margin: 0, marginLeft: 4 },
  input: {
    height: 52,
    flex: 1,
    fontSize: 15,
    fontWeight: '500',
  },
  eyeBtn: { paddingHorizontal: 4 },

  loginBtn: {
    height: 54,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 12,
    elevation: 4,
    shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }
  },
  btnContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  loginBtnText: { color: '#FFF', fontSize: 16, fontWeight: '800', letterSpacing: 0.5 },

  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: 32 },
  footerText: { fontSize: 14, fontWeight: '500' },
  supportLink: { fontSize: 14, fontWeight: '700' },
  
  copyright: { textAlign: 'center', marginBottom: 24, fontSize: 12, fontWeight: '500' },
});
