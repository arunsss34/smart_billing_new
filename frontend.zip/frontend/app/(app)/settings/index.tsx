import { Redirect } from 'expo-router';
// "settings" parent route redirects to settings/tenants
export default function SettingsIndex() {
  return <Redirect href="/(app)/settings/tenants" />;
}
