import api from './client';

export interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  stock_qty: number;
  unit: string;
  barcode?: string;
  sku?: string;
  size?: string;
  color?: string;
  imei?: string;
  expiry_date?: string;
}

export const productsApi = {
  list: () => api.get<Product[]>('/products/').then(r => r.data),
  create: (data: Partial<Product>) => api.post<Product>('/products/', data).then(r => r.data),
  update: (id: number, data: Partial<Product>) => api.put<Product>(`/products/${id}`, data).then(r => r.data),
  delete: (id: number) => api.delete(`/products/${id}`),
};

export interface Customer {
  id: number;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  gstin?: string;
}

export const customersApi = {
  list: () => api.get<Customer[]>('/customers/').then(r => r.data),
  create: (data: Partial<Customer>) => api.post<Customer>('/customers/', data).then(r => r.data),
  update: (id: number, data: Partial<Customer>) => api.put<Customer>(`/customers/${id}`, data).then(r => r.data),
};

export interface InvoiceItem {
  product_id: number;
  quantity: number;
  unit_price: number;
  discount?: number;
  tax_percent?: number;
}

export interface Invoice {
  id: number;
  invoice_number: string;
  customer_id: number;
  items: InvoiceItem[];
  subtotal: number;
  discount_total: number;
  tax_total: number;
  grand_total: number;
  payment_method: string;
  invoice_status: string;
  created_at: string;
}

export interface Table {
  id: number;
  table_number: string;
  capacity: number;
  is_occupied: boolean;
}

export const billingApi = {
  listInvoices: (params?: { start_date?: string; end_date?: string }) => api.get<Invoice[]>('/billing/invoices', { params }).then(r => r.data),
  listTables: () => api.get<Table[]>('/billing/tables').then(r => r.data),
  getInvoice: (id: number) => api.get<Invoice>(`/billing/invoices/${id}`).then(r => r.data),
  createInvoice: (data: {
    customer_id?: number;
    items: InvoiceItem[];
    payment_method: string;
    metadata_fields?: Record<string, any>;
    table_id?: number;
    kot_id?: number;
  }) => api.post<Invoice>('/billing/invoices', data).then(r => r.data),
  payInvoice: (id: number) => api.put(`/billing/invoices/${id}/pay`).then(r => r.data),
};

export const reportsApi = {
  salesSummary: (params?: { start_date?: string; end_date?: string; customer_id?: number }) => 
    api.get('/reports/sales-summary', { params }).then(r => r.data),
  dailySales: (params?: { start_date?: string; end_date?: string; customer_id?: number }) => 
    api.get('/reports/daily-sales', { params }).then(r => r.data),
  topProducts: (params?: { start_date?: string; end_date?: string; customer_id?: number }) => 
    api.get('/reports/top-products', { params }).then(r => r.data),
  paymentMethods: (params?: { start_date?: string; end_date?: string; customer_id?: number }) => 
    api.get('/reports/payment-methods', { params }).then(r => r.data),
};
