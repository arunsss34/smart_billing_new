import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, TextInput, Alert, Modal, ScrollView,
} from 'react-native';
import { IconButton } from 'react-native-paper';
import { customersApi, Customer } from '../api/business.api';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors, Radius, Spacing, FontSize } from '../theme';

export default function CustomersScreen() {
  const { themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState<Partial<Customer>>({});
  const [editId, setEditId] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try { setCustomers(await customersApi.list()); }
    catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.phone?.includes(search)
  );

  const openEdit = (c: Customer) => { 
    setForm({
      name: c.name,
      phone: c.phone,
      email: c.email,
      address: c.address,
      gstin: c.gstin
    }); 
    setEditId(c.id); 
    setModal(true); 
  };
  const openAdd = () => { setForm({}); setEditId(null); setModal(true); };

  const save = async () => {
    if (!form.name?.trim() || !form.phone?.trim()) {
      Alert.alert('Error', 'Name and Phone are required'); return;
    }
    try {
      if (editId) await customersApi.update(editId, form);
      else await customersApi.create(form);
      setModal(false); load();
    } catch (e: any) {
      Alert.alert('Error', e?.response?.data?.detail || 'Failed to save');
    }
  };

  const deleteCustomer = async (id: number) => {
    Alert.alert('Delete Customer', 'Are you sure?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        try { await customersApi.delete(id); load(); }
        catch (e) { Alert.alert('Error', 'Failed to delete'); }
      }}
    ]);
  };

  const renderItem = ({ item }: { item: Customer }) => (
    <TouchableOpacity 
      style={[s.listItem, { borderBottomColor: Colors.border.subtle }]} 
      onPress={() => openEdit(item)} 
      activeOpacity={0.7}
    >
      <View style={s.listMain}>
        <View style={[s.listIcon, { backgroundColor: Colors.brand.primary + '15' }]}>
          <Text style={[s.listIconText, { color: Colors.brand.primary }]}>{item.name[0].toUpperCase()}</Text>
        </View>
        <View style={s.listInfo}>
          <Text style={[s.listName, { color: Colors.text.primary }]}>{item.name}</Text>
          <View style={s.listMetaRow}>
            <Text style={[s.listMeta, { color: Colors.text.muted }]}>{item.phone}</Text>
            {item.email && (
              <>
                <View style={s.listDot} />
                <Text style={[s.listMeta, { color: Colors.text.muted }]} numberOfLines={1}>{item.email}</Text>
              </>
            )}
          </View>
        </View>
      </View>
      <View style={s.listRight}>
        <IconButton 
          icon="trash-can-outline" 
          size={20} 
          iconColor={Colors.brand.danger} 
          onPress={() => deleteCustomer(item.id)}
          style={{ margin: 0 }}
        />
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[s.container, { backgroundColor: Colors.bg.primary }]}>
      <View style={s.searchBarWrapper}>
        <View style={[s.searchBar, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
          <IconButton icon="magnify" size={20} iconColor={Colors.text.muted} style={{ margin: 0 }} />
          <TextInput
            style={[s.searchInput, { color: Colors.text.primary }]}
            value={search}
            onChangeText={setSearch}
            placeholder="Search customers..."
            placeholderTextColor={Colors.text.muted}
          />
        </View>
      </View>

      {loading
        ? <View style={s.center}><ActivityIndicator color={Colors.brand.primary} /></View>
        : <FlatList
            data={filtered}
            renderItem={renderItem}
            keyExtractor={i => String(i.id)}
            contentContainerStyle={s.list}
            ListEmptyComponent={
              <View style={s.emptyContainer}>
                <Text style={[s.emptyTitle, { color: Colors.text.primary }]}>No Customers Found</Text>
                <Text style={[s.emptySub, { color: Colors.text.muted }]}>Try searching for a different name or phone number.</Text>
              </View>
            }
          />
      }

      <TouchableOpacity style={[s.fab, { backgroundColor: Colors.brand.primary, shadowColor: Colors.brand.primary }]} onPress={openAdd}>
        <Text style={s.fabText}>+</Text>
      </TouchableOpacity>

      <Modal visible={modal} animationType="slide" transparent>
        <View style={[s.modalRoot, { backgroundColor: Colors.bg.overlay }]}>
          <View style={[s.modalCard, { backgroundColor: Colors.bg.card }]}>
            <Text style={[s.modalTitle, { color: Colors.text.primary }]}>{editId ? 'Edit' : 'Add'} Customer</Text>
            <ScrollView showsVerticalScrollIndicator={false} style={s.form}>
              {[
                ['Full Name', 'name', 'account'], 
                ['Phone Number', 'phone', 'phone'], 
                ['Email Address', 'email', 'email'], 
                ['Residential Address', 'address', 'map-marker'], 
                ['GST Number', 'gstin', 'card-account-details']
              ].map(([label, key, icon]) => (
                <View key={key} style={s.field}>
                  <Text style={[s.label, { color: Colors.text.secondary }]}>{label}</Text>
                  <View style={[s.inputWrapper, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default }]}>
                    <IconButton icon={icon as string} size={18} iconColor={Colors.text.muted} style={{ margin: 0 }} />
                    <TextInput
                      style={[s.input, { color: Colors.text.primary }]}
                      value={String(form[key as keyof Customer] ?? '')}
                      onChangeText={v => setForm({ ...form, [key]: v })}
                      placeholderTextColor={Colors.text.muted}
                    />
                  </View>
                </View>
              ))}
            </ScrollView>
            <View style={s.modalFooter}>
              <TouchableOpacity style={[s.btn, s.btnCancel, { backgroundColor: Colors.bg.primary }]} onPress={() => setModal(false)}>
                <Text style={[s.btnText, { color: Colors.text.secondary }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.btn, s.btnSave, { backgroundColor: Colors.brand.primary }]} onPress={save}>
                <Text style={s.btnText}>Save Customer</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  searchBarWrapper: { padding: 12, paddingBottom: 6 },
  searchBar: { 
    flexDirection: 'row', alignItems: 'center', 
    borderRadius: 8, paddingHorizontal: 4, height: 36, borderWidth: 1 
  },
  searchInput: { flex: 1, fontSize: 13, fontWeight: '500' },
  list: { paddingBottom: 100 },
  listItem: { 
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingVertical: 12, paddingHorizontal: 16, borderBottomWidth: 1 
  },
  listMain: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  listIcon: { width: 44, height: 44, borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginRight: 16 },
  listIconText: { fontSize: 18, fontWeight: '800' },
  listInfo: { flex: 1 },
  listName: { fontSize: 15, fontWeight: '700', marginBottom: 2 },
  listMetaRow: { flexDirection: 'row', alignItems: 'center' },
  listMeta: { fontSize: 12, fontWeight: '500' },
  listDot: { width: 3, height: 3, borderRadius: 1.5, backgroundColor: '#cbd5e1', marginHorizontal: 8 },
  listRight: { flexDirection: 'row', alignItems: 'center' },
  fab: { 
    position: 'absolute', bottom: 24, right: 24, width: 56, height: 56, 
    borderRadius: 28, justifyContent: 'center', alignItems: 'center', elevation: 8 
  },
  fabText: { color: '#fff', fontSize: 28, fontWeight: '300' },
  modalRoot: { flex: 1, justifyContent: 'flex-end' },
  modalCard: { borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 24, maxHeight: '90%' },
  modalTitle: { fontSize: 18, fontWeight: '800', marginBottom: 20 },
  form: { flex: 1 },
  field: { marginBottom: 16 },
  label: { fontSize: 11, fontWeight: '700', marginBottom: 6 },
  inputWrapper: { flexDirection: 'row', alignItems: 'center', borderRadius: 8, borderWidth: 1, paddingHorizontal: 4 },
  input: { flex: 1, paddingVertical: 10, fontSize: 14 },
  modalFooter: { flexDirection: 'row', gap: 12, paddingTop: 16 },
  btn: { flex: 1, paddingVertical: 14, borderRadius: 10, alignItems: 'center' },
  btnCancel: { borderWidth: 1, borderColor: '#ccc' },
  btnSave: { elevation: 2 },
  btnText: { fontWeight: '700', color: '#fff' },
  emptyContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', marginTop: 100, paddingHorizontal: 40 },
  emptyTitle: { fontSize: 16, fontWeight: '800', marginBottom: 8 },
  emptySub: { fontSize: 14, textAlign: 'center', opacity: 0.6 },
});
