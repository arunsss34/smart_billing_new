import AsyncStorage from '@react-native-async-storage/async-storage';
import api from './client';

export interface MenuItem {
  id: number;
  name: string;
  route: string;
  icon: string;
  parent_id: number | null;
  sort_order: number;
  can_view: boolean;
  can_add: boolean;
  can_edit: boolean;
  can_delete: boolean;
}

export interface MenuResponse {
  menus: MenuItem[];
  features: Record<string, boolean>;
  theme_color: string;
  tenant_name: string;
}

export const menuApi = {
  getMenus: async (): Promise<MenuResponse> => {
    try {
      const { data } = await api.get<MenuResponse>('/menus/get-menus');
      // Cache menus for offline use
      await AsyncStorage.setItem('menus_cache', JSON.stringify(data.menus));
      await AsyncStorage.setItem('features_cache', JSON.stringify(data.features));
      return data;
    } catch (error) {
      // Offline fallback: load from cache
      const cachedMenus = await AsyncStorage.getItem('menus_cache');
      const cachedFeatures = await AsyncStorage.getItem('features_cache');
      if (cachedMenus) {
        return {
          menus: JSON.parse(cachedMenus),
          features: cachedFeatures ? JSON.parse(cachedFeatures) : {},
        };
      }
      throw error;
    }
  },
};
