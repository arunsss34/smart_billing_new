import api from './client';

export interface UOM { id: number; name: string; abbreviation: string; is_active: boolean; }
export interface Category { id: number; name: string; parent_id: number | null; is_active: boolean; }
export interface HSN {
  id: number; hsn_code: string; description: string;
  cgst_rate: number; sgst_rate: number; igst_rate: number; cess_rate: number; is_active: boolean;
}

export const mastersApi = {
  // UOM
  listUOM: (): Promise<UOM[]> => api.get('/masters/uom').then(r => r.data),
  saveUOM: (data: { name: string; abbreviation: string }, id?: number) =>
    id ? api.put(`/masters/uom/${id}`, data).then(r => r.data)
       : api.post('/masters/uom', data).then(r => r.data),
  deleteUOM: (id: number) => api.delete(`/masters/uom/${id}`),

  // Category
  listCategories: (): Promise<Category[]> => api.get('/masters/categories').then(r => r.data),
  saveCategory: (data: { name: string; parent_id?: number | null }, id?: number) =>
    id ? api.put(`/masters/categories/${id}`, data).then(r => r.data)
       : api.post('/masters/categories', data).then(r => r.data),
  deleteCategory: (id: number) => api.delete(`/masters/categories/${id}`),

  // HSN
  listHSN: (): Promise<HSN[]> => api.get('/masters/hsn').then(r => r.data),
  saveHSN: (data: Omit<HSN, 'id' | 'is_active'>, id?: number) =>
    id ? api.put(`/masters/hsn/${id}`, data).then(r => r.data)
       : api.post('/masters/hsn', data).then(r => r.data),
  deleteHSN: (id: number) => api.delete(`/masters/hsn/${id}`),
};
