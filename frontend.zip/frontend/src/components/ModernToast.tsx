import React, { useEffect, useRef } from 'react';
import { View, Text, Animated, StyleSheet, TouchableOpacity } from 'react-native';
import { IconButton } from 'react-native-paper';
import { Colors } from '../theme';

interface ToastProps {
  visible: boolean;
  message: string;
  type?: 'success' | 'error' | 'info';
  onHide: () => void;
  colors: any; // Add colors prop
}

export default function ModernToast({ visible, message, type = 'success', onHide, colors }: ToastProps) {
  const translateY = useRef(new Animated.Value(-100)).current;
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.spring(translateY, { toValue: 10, useNativeDriver: true, tension: 80, friction: 10 }),
        Animated.timing(opacity, { toValue: 1, duration: 300, useNativeDriver: true }),
      ]).start();

      const timer = setTimeout(() => {
        hide();
      }, 4000);
      return () => clearTimeout(timer);
    } else {
      hide();
    }
  }, [visible]);

  const hide = () => {
    Animated.parallel([
      Animated.timing(translateY, { toValue: -100, duration: 300, useNativeDriver: true }),
      Animated.timing(opacity, { toValue: 0, duration: 300, useNativeDriver: true }),
    ]).start(() => onHide());
  };

  const getIcon = () => {
    switch (type) {
      case 'error': return 'alert-circle-outline';
      case 'info': return 'information-outline';
      default: return 'check-circle-outline';
    }
  };

  const getColor = () => {
    switch (type) {
      case 'error': return colors.brand.danger;
      case 'info': return colors.brand.secondary;
      default: return colors.brand.success;
    }
  };

  if (!visible && opacity._value === 0) return null;

  return (
    <Animated.View style={[
      styles.container, 
      { 
        transform: [{ translateY }], 
        opacity, 
        backgroundColor: colors.bg.elevated, 
        borderColor: colors.mode === 'dark' ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.05)',
        shadowColor: colors.mode === 'dark' ? '#000' : 'rgba(0,0,0,0.1)'
      }
    ]}>
      <View style={[styles.iconBox, { backgroundColor: getColor() + '15' }]}>
        <IconButton icon={getIcon()} size={20} iconColor={getColor()} style={{ margin: 0 }} />
      </View>
      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text.muted }]}>{type.toUpperCase()}</Text>
        <Text style={[styles.message, { color: colors.text.primary }]}>{message}</Text>
      </View>
      <TouchableOpacity onPress={hide}>
        <IconButton icon="close" size={16} iconColor={colors.text.disabled} />
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0, left: 16, right: 16,
    zIndex: 9999,
    borderRadius: 20,
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  iconBox: {
    width: 40, height: 40,
    borderRadius: 14,
    justifyContent: 'center', alignItems: 'center',
  },
  content: { flex: 1, marginLeft: 14, paddingRight: 4 },
  title: { fontSize: 9, fontWeight: '900', letterSpacing: 1.2, marginBottom: 2, textTransform: 'uppercase' },
  message: { fontSize: 13, fontWeight: '700', lineHeight: 18 },
});
