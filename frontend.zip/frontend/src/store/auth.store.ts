import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { authApi } from '../api/auth.api';
import { menuApi, MenuItem } from '../api/menu.api';

interface AuthState {
  token: string | null;
  role: string | null;
  tenantId: number | null;
  tenantName: string | null;
  businessType: string | null;
  businessTypeId: number | null;
  menus: MenuItem[];
  features: Record<string, boolean>;
  themeColor: string;
  isLoading: boolean;
  isAuthenticated: boolean;
  isHydrated: boolean;
  menuError: string | null;

  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  loadMenus: () => Promise<void>;
  hydrateFromStorage: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  token: null,
  role: null,
  tenantId: null,
  tenantName: 'Smart Billing',
  businessType: null,
  businessTypeId: null,
  menus: [],
  features: {},
  themeColor: '#6366F1',
  isLoading: false,
  isAuthenticated: false,
  isHydrated: false,
  menuError: null,

  hydrateFromStorage: async () => {
    try {
      const token = await AsyncStorage.getItem('access_token');
      const role = await AsyncStorage.getItem('user_role');
      const tenantId = await AsyncStorage.getItem('tenant_id');
      const tenantName = await AsyncStorage.getItem('tenant_name');
      const menusCache = await AsyncStorage.getItem('menus_cache');
      const featuresCache = await AsyncStorage.getItem('features_cache');
      const themeCache = await AsyncStorage.getItem('theme_cache');

      if (token) {
        const cachedMenus = menusCache ? JSON.parse(menusCache) : [];
        const bizType = await AsyncStorage.getItem('business_type');
        const bizTypeId = await AsyncStorage.getItem('business_type_id');
        set({
          token,
          role,
          tenantId: tenantId ? parseInt(tenantId) : null,
          tenantName: tenantName || 'Smart Billing',
          businessType: bizType || null,
          businessTypeId: bizTypeId ? parseInt(bizTypeId) : null,
          menus: cachedMenus,
          features: featuresCache ? JSON.parse(featuresCache) : {},
          themeColor: themeCache || '#6366F1',
          isAuthenticated: true,
          isHydrated: true,
        });

        await get().loadMenus();
      } else {
        set({ isHydrated: true });
      }
    } catch {
      set({ isHydrated: true });
    }
  },

  login: async (username, password) => {
    set({ isLoading: true, menuError: null });
    try {
      const response = await authApi.login(username, password);

      await AsyncStorage.setItem('access_token', response.access_token);
      await AsyncStorage.setItem('user_role', response.role ?? '');
      await AsyncStorage.setItem('tenant_id', String(response.tenant_id ?? ''));
      await AsyncStorage.setItem('business_type', response.business_type ?? '');
      await AsyncStorage.setItem('business_type_id', String(response.business_type_id ?? ''));

      set({
        token: response.access_token,
        role: response.role,
        tenantId: response.tenant_id,
        businessType: response.business_type ?? null,
        businessTypeId: response.business_type_id ?? null,
        isAuthenticated: true,
        isLoading: false,
      });

      await get().loadMenus();
    } catch (err) {
      set({ isLoading: false });
      throw err;
    }
  },

  logout: async () => {
    try { await authApi.logout(); } catch {}
    await AsyncStorage.multiRemove([
      'access_token', 'user_role', 'tenant_id', 'tenant_name',
      'business_type', 'business_type_id',
      'menus_cache', 'features_cache', 'theme_cache',
    ]);
    set({
      token: null, role: null, tenantId: null, tenantName: 'Smart Billing',
      businessType: null, businessTypeId: null,
      menus: [], features: {}, themeColor: '#6366F1', isAuthenticated: false,
      menuError: null,
    });
  },

  loadMenus: async () => {
    try {
      const data = await menuApi.getMenus();
      await AsyncStorage.setItem('menus_cache', JSON.stringify(data.menus));
      await AsyncStorage.setItem('features_cache', JSON.stringify(data.features));
      await AsyncStorage.setItem('theme_cache', data.theme_color);
      await AsyncStorage.setItem('tenant_name', data.tenant_name);
      
      set({ 
        menus: data.menus, 
        features: data.features, 
        themeColor: data.theme_color, 
        tenantName: data.tenant_name,
        menuError: null 
      });
    } catch (err: any) {
      const msg = err?.response?.data?.detail || err?.message || 'Failed to load menus';
      set({ menuError: msg });
    }
  },
}));
