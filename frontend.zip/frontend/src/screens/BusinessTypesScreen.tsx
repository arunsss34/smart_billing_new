import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Modal, ActivityIndicator, Alert, Switch,
} from 'react-native';
import {
  businessTypeApi, BusinessType, BusinessTypeCreate,
  ALL_FEATURES, EMOJI_PICKER,
} from '../api/businessType.api';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors, Radius, Spacing, FontSize } from '../theme';

const EMPTY_FORM: BusinessTypeCreate = {
  name: '',
  label: '',
  icon: '🏪',
  description: '',
  default_features: [],
};

export default function BusinessTypesScreen() {
  const { themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);

  const [types, setTypes] = useState<BusinessType[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<BusinessTypeCreate>(EMPTY_FORM);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      setTypes(await businessTypeApi.list());
    } catch (e: any) {
      Alert.alert('Error', e?.response?.data?.detail || 'Failed to load');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setModalVisible(true);
  };

  const openEdit = (t: BusinessType) => {
    setEditingId(t.id);
    setForm({
      name: t.name,
      label: t.label,
      icon: t.icon,
      description: t.description || '',
      default_features: [...t.default_features],
    });
    setModalVisible(true);
  };

  const toggleFeature = (key: string) => {
    setForm(f => ({
      ...f,
      default_features: f.default_features.includes(key)
        ? f.default_features.filter(k => k !== key)
        : [...f.default_features, key],
    }));
  };

  const handleSave = async () => {
    if (!form.label.trim()) return Alert.alert('Validation', 'Display name is required');
    if (!form.name.trim()) return Alert.alert('Validation', 'Slug key is required');

    setSaving(true);
    try {
      if (editingId) {
        await businessTypeApi.update(editingId, { ...form, is_active: true });
      } else {
        await businessTypeApi.create(form);
      }
      setModalVisible(false);
      await load();
    } catch (e: any) {
      Alert.alert('Error', e?.response?.data?.detail || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDeactivate = (t: BusinessType) => {
    Alert.alert(
      'Deactivate Type',
      `Deactivate "${t.label}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Deactivate', style: 'destructive',
          onPress: async () => {
            try { await businessTypeApi.deactivate(t.id); await load(); }
            catch (e: any) { Alert.alert('Error', e?.response?.data?.detail || 'Failed'); }
          },
        },
      ]
    );
  };

  if (loading) return (
    <View style={[s.center, { backgroundColor: Colors.bg.primary }]}>
      <ActivityIndicator size="large" color={Colors.brand.primary} />
    </View>
  );

  return (
    <View style={[s.container, { backgroundColor: Colors.bg.primary }]}>
      <View style={s.headerRow}>
        <View>
          <Text style={[s.title, { color: Colors.text.primary }]}>Business Types</Text>
          <Text style={[s.subtitle, { color: Colors.text.muted }]}>{types.length} types configured</Text>
        </View>
        <TouchableOpacity style={[s.addBtn, { backgroundColor: Colors.brand.primary }]} onPress={openCreate} activeOpacity={0.8}>
          <Text style={s.addBtnText}>+ New Type</Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {types.length === 0 && (
          <View style={s.emptyBox}>
            <Text style={s.emptyIcon}>🏪</Text>
            <Text style={[s.emptyTitle, { color: Colors.text.primary }]}>No Business Types</Text>
            <Text style={[s.emptySubtitle, { color: Colors.text.muted }]}>Create your first business type</Text>
          </View>
        )}

        {types.map(t => (
          <View key={t.id} style={[s.card, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
            <View style={s.cardTop}>
              <View style={[s.iconCircle, { backgroundColor: Colors.bg.surface }]}>
                <Text style={s.cardIcon}>{t.icon}</Text>
              </View>
              <View style={s.cardInfo}>
                <Text style={[s.cardLabel, { color: Colors.text.primary }]}>{t.label}</Text>
                <Text style={[s.cardSlug, { color: Colors.brand.primary }]}>/{t.name}</Text>
                {t.description ? <Text style={[s.cardDesc, { color: Colors.text.muted }]} numberOfLines={2}>{t.description}</Text> : null}
              </View>
            </View>

            {t.default_features.length > 0 && (
              <View style={s.featureRow}>
                <Text style={[s.featureTitle, { color: Colors.text.muted }]}>Default Features:</Text>
                <View style={s.featureTags}>
                  {t.default_features.map(f => {
                    const feat = ALL_FEATURES.find(af => af.key === f);
                    return (
                      <View key={f} style={[s.featureTag, { backgroundColor: Colors.bg.surface, borderColor: Colors.border.default }]}>
                        <Text style={[s.featureTagText, { color: Colors.text.secondary }]}>{feat?.icon} {feat?.label || f}</Text>
                      </View>
                    );
                  })}
                </View>
              </View>
            )}

            <View style={s.actions}>
              <TouchableOpacity style={[s.editBtn, { backgroundColor: mode === 'dark' ? '#1E3A5F' : '#E0F2FE' }]} onPress={() => openEdit(t)}>
                <Text style={[s.editBtnText, { color: mode === 'dark' ? '#60A5FA' : '#0284C7' }]}>✏️ Edit</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.deactBtn, { backgroundColor: mode === 'dark' ? '#3B0F0F' : '#FEE2E2' }]} onPress={() => handleDeactivate(t)}>
                <Text style={[s.deactBtnText, { color: Colors.brand.danger }]}>🚫 Remove</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
        <View style={{ height: 40 }} />
      </ScrollView>

      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={[s.overlay, { backgroundColor: Colors.bg.overlay }]}>
          <View style={[s.modalBox, { backgroundColor: Colors.bg.primary }]}>
            <View style={s.modalHeader}>
              <Text style={[s.modalTitle, { color: Colors.text.primary }]}>{editingId ? 'Edit Business Type' : 'New Business Type'}</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                <Text style={[s.closeBtn, { color: Colors.text.muted }]}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              <Text style={[s.label, { color: Colors.text.secondary }]}>Icon *</Text>
              <TouchableOpacity style={[s.iconPickerBtn, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]} onPress={() => setShowEmojiPicker(!showEmojiPicker)}>
                <Text style={s.iconPickerEmoji}>{form.icon}</Text>
                <Text style={[s.iconPickerHint, { color: Colors.text.muted }]}>Tap to change icon</Text>
              </TouchableOpacity>
              {showEmojiPicker && (
                <View style={[s.emojiGrid, { backgroundColor: Colors.bg.card }]}>
                  {EMOJI_PICKER.map(em => (
                    <TouchableOpacity
                      key={em}
                      style={[s.emojiBtn, { backgroundColor: Colors.bg.surface }, form.icon === em && { borderWidth: 2, borderColor: Colors.brand.primary }]}
                      onPress={() => { setForm(f => ({ ...f, icon: em })); setShowEmojiPicker(false); }}
                    >
                      <Text style={s.emojiText}>{em}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              )}

              <Text style={[s.label, { color: Colors.text.secondary }]}>Display Name *</Text>
              <TextInput
                style={[s.input, { backgroundColor: Colors.bg.card, color: Colors.text.primary, borderColor: Colors.border.default }]}
                value={form.label}
                onChangeText={v => setForm(f => ({ ...f, label: v, name: f.name || v.toLowerCase().replace(/\s+/g, '_') }))}
                placeholder="e.g. Pharmacy"
                placeholderTextColor={Colors.text.muted}
              />

              <Text style={[s.label, { color: Colors.text.secondary }]}>Slug Key *</Text>
              <TextInput
                style={[s.input, { backgroundColor: Colors.bg.card, color: Colors.text.primary, borderColor: Colors.border.default }]}
                value={form.name}
                onChangeText={v => setForm(f => ({ ...f, name: v.toLowerCase().replace(/\s+/g, '_') }))}
                placeholder="e.g. pharmacy"
                placeholderTextColor={Colors.text.muted}
                autoCapitalize="none"
              />

              <Text style={[s.label, { color: Colors.text.secondary }]}>Description</Text>
              <TextInput
                style={[s.input, { height: 72, textAlignVertical: 'top', backgroundColor: Colors.bg.card, color: Colors.text.primary, borderColor: Colors.border.default }]}
                value={form.description}
                onChangeText={v => setForm(f => ({ ...f, description: v }))}
                placeholder="Briefly describe..."
                placeholderTextColor={Colors.text.muted}
                multiline
              />

              <Text style={[s.label, { color: Colors.text.secondary }]}>Default Features</Text>
              {ALL_FEATURES.map(feat => {
                const on = form.default_features.includes(feat.key);
                return (
                  <TouchableOpacity
                    key={feat.key}
                    style={[s.featureRow2, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }, on && { borderColor: Colors.brand.primary + '55', backgroundColor: mode === 'dark' ? '#1a1b3a' : '#EEF2FF' }]}
                    onPress={() => toggleFeature(feat.key)}
                  >
                    <Text style={s.featIcon}>{feat.icon}</Text>
                    <Text style={[s.featLabel, { color: Colors.text.secondary }, on && { color: Colors.text.primary, fontWeight: '600' }]}>{feat.label}</Text>
                    <Switch
                      value={on}
                      onValueChange={() => toggleFeature(feat.key)}
                      trackColor={{ false: Colors.bg.primary, true: Colors.brand.primary + '88' }}
                      thumbColor={on ? Colors.brand.primary : '#94A3B8'}
                    />
                  </TouchableOpacity>
                );
              })}

              <TouchableOpacity
                style={[s.saveBtn, { backgroundColor: Colors.brand.primary }, saving && { opacity: 0.6 }]}
                onPress={handleSave}
                disabled={saving}
              >
                {saving ? <ActivityIndicator color="#fff" /> : <Text style={s.saveBtnText}>{editingId ? 'Update' : 'Create'}</Text>}
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 16, paddingTop: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  title: { fontSize: 20, fontWeight: '800' },
  subtitle: { fontSize: 12, marginTop: 2 },
  addBtn: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: Radius.md },
  addBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  emptyBox: { alignItems: 'center', paddingTop: 60, gap: 10 },
  emptyIcon: { fontSize: 52 },
  emptyTitle: { fontSize: 18, fontWeight: '700' },
  emptySubtitle: { fontSize: 14 },
  card: { borderRadius: Radius.lg, padding: 16, marginBottom: 16, borderWidth: 1 },
  cardTop: { flexDirection: 'row', gap: 16, marginBottom: 16 },
  iconCircle: { width: 52, height: 52, borderRadius: Radius.md, justifyContent: 'center', alignItems: 'center' },
  cardIcon: { fontSize: 26 },
  cardInfo: { flex: 1 },
  cardLabel: { fontSize: 16, fontWeight: '700' },
  cardSlug: { fontSize: 12, fontFamily: 'monospace', marginTop: 2 },
  cardDesc: { fontSize: 12, marginTop: 4, lineHeight: 16 },
  featureRow: { marginBottom: 16 },
  featureTitle: { fontSize: 11, fontWeight: '600', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  featureTags: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  featureTag: { borderRadius: Radius.sm, paddingHorizontal: 8, paddingVertical: 3, borderWidth: 1 },
  featureTagText: { fontSize: 11, fontWeight: '600' },
  actions: { flexDirection: 'row', gap: 8 },
  editBtn: { flex: 1, paddingVertical: 9, borderRadius: Radius.sm, alignItems: 'center' },
  editBtnText: { fontWeight: '600', fontSize: 14 },
  deactBtn: { flex: 1, paddingVertical: 9, borderRadius: Radius.sm, alignItems: 'center' },
  deactBtnText: { fontWeight: '600', fontSize: 14 },
  overlay: { flex: 1, justifyContent: 'flex-end' },
  modalBox: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: '94%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 18, fontWeight: '800' },
  closeBtn: { fontSize: 18 },
  label: { fontSize: 11, fontWeight: '600', marginBottom: 6, marginTop: 16, textTransform: 'uppercase', letterSpacing: 0.5 },
  input: { borderRadius: Radius.md, paddingHorizontal: 14, paddingVertical: 11, fontSize: 15, borderWidth: 1 },
  iconPickerBtn: { flexDirection: 'row', alignItems: 'center', gap: 14, borderRadius: Radius.md, padding: 14, borderWidth: 1 },
  iconPickerEmoji: { fontSize: 32 },
  iconPickerHint: { fontSize: 14 },
  emojiGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8, padding: 8, borderRadius: Radius.md },
  emojiBtn: { width: 44, height: 44, borderRadius: Radius.sm, justifyContent: 'center', alignItems: 'center' },
  emojiText: { fontSize: 22 },
  featureRow2: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 11, paddingHorizontal: 12, borderRadius: Radius.md, marginVertical: 2, borderWidth: 1 },
  featIcon: { fontSize: 18, width: 26, textAlign: 'center' },
  featLabel: { flex: 1, fontSize: 15 },
  saveBtn: { borderRadius: Radius.md, paddingVertical: 14, alignItems: 'center', marginTop: 24, marginBottom: 20 },
  saveBtnText: { color: '#fff', fontWeight: '800', fontSize: 16 },
});
