import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Modal, ActivityIndicator, Alert, Switch, FlatList,
} from 'react-native';
import { IconButton } from 'react-native-paper';
import { useRouter } from 'expo-router';
import api from '../api/client';
import { tenantApi, Tenant } from '../api/tenant.api';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors, Radius, Spacing, FontSize } from '../theme';

interface User {
  id: number;
  username: string;
  full_name: string;
  email: string;
  role_id: number;
  role_name: string;
  tenant_id: number | null;
  tenant_role_id: number | null;
  tenant_role_name: string | null;
  tenant_name?: string;
  business_type?: string;
  is_active: boolean;
  created_at: string;
}

interface TenantRole { id: number; name: string; description: string | null; }

const EMPTY_FORM = {
  username: '',
  password: '',
  full_name: '',
  email: '',
  tenant_id: null as number | null,
  tenant_role_id: null as number | null,
  is_active: true,
};

export default function UsersScreen() {
  const { role, themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);
  const isSuperAdmin = role === 'super_admin';
  const router = useRouter();

  const [users, setUsers] = useState<User[]>([]);
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [roles, setRoles] = useState<TenantRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [uRes, tRes] = await Promise.all([
        api.get('/users/'),
        isSuperAdmin ? tenantApi.list() : Promise.resolve([]),
      ]);
      setUsers(uRes.data);
      setTenants(tRes);
    } catch (e: any) {
      Alert.alert('Error', e?.response?.data?.detail || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }, [isSuperAdmin]);

  const loadRoles = async (tenantId: number) => {
    try {
      const res = await api.get(`/tenants/${tenantId}/roles/`);
      setRoles(res.data);
    } catch { setRoles([]); }
  };

  useEffect(() => { load(); }, [load]);

  const handleEdit = async (u: User) => {
    setForm({
      username: u.username,
      password: '',
      full_name: u.full_name,
      email: u.email,
      tenant_id: u.tenant_id,
      tenant_role_id: u.tenant_role_id,
      is_active: u.is_active,
    });
    if (u.tenant_id) await loadRoles(u.tenant_id);
    setEditingId(u.id);
    setModalVisible(true);
  };

  const handleSave = async () => {
    if (!form.username || (!editingId && !form.password)) {
      Alert.alert('Validation', 'Username and Password are required.');
      return;
    }
    setSaving(true);
    try {
      if (editingId) {
        await api.put(`/users/${editingId}`, form);
      } else {
        await api.post('/users/', form);
      }
      load();
      setModalVisible(false);
    } catch (e: any) {
      Alert.alert('Error', e?.response?.data?.detail || 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const filteredUsers = users.filter(u => 
    u.full_name.toLowerCase().includes(search.toLowerCase()) || 
    u.username.toLowerCase().includes(search.toLowerCase()) ||
    (u.tenant_name && u.tenant_name.toLowerCase().includes(search.toLowerCase()))
  );

  const handleDelete = (u: User) => {
    Alert.alert('Remove User', `Are you sure you want to remove ${u.full_name}?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: async () => {
        try {
          await api.delete(`/users/${u.id}`);
          load();
        } catch (e: any) {
          Alert.alert('Error', e?.response?.data?.detail || 'Failed to delete');
        }
      }}
    ]);
  };

  if (loading) return (
    <View style={[s.center, { backgroundColor: Colors.bg.primary }]}>
      <ActivityIndicator color={Colors.brand.primary} />
    </View>
  );

  return (
    <View style={[s.container, { backgroundColor: Colors.bg.primary }]}>
      <View style={s.actionHeader}>
        <View style={[s.searchBar, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
          <IconButton icon="magnify" size={18} iconColor={Colors.text.muted} style={{ margin: 0 }} />
          <TextInput 
            style={[s.searchInput, { color: Colors.text.primary }]} 
            value={search} 
            onChangeText={setSearch} 
            placeholder="Search users..." 
            placeholderTextColor={Colors.text.muted} 
          />
        </View>
        <IconButton 
          icon="account-switch-outline" 
          size={24} 
          iconColor={Colors.brand.primary} 
          onPress={() => router.push('/(app)/settings/user-role-mapping')}
          style={[s.mapBtn, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}
        />
      </View>

      <FlatList
        data={filteredUsers}
        keyExtractor={u => String(u.id)}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 100 }}
        ListEmptyComponent={
          <View style={s.emptyContainer}>
            <View style={[s.emptyIconCircle, { backgroundColor: Colors.brand.primary + '15' }]}>
              <Text style={s.emptyIconText}>👥</Text>
            </View>
            <Text style={[s.emptyTitle, { color: Colors.text.primary }]}>No Users Found</Text>
            <Text style={[s.emptySub, { color: Colors.text.muted }]}>
              {search ? 'Try a different search term.' : 'Start by adding users to your organization.'}
            </Text>
          </View>
        }
        renderItem={({ item: u }) => (
          <View style={[s.listItem, { borderBottomColor: Colors.border.subtle }]}>
            <View style={[s.userAvatar, { backgroundColor: Colors.brand.primary + '15' }]}>
              <Text style={[s.avatarTxt, { color: Colors.brand.primary }]}>{u.full_name.substring(0,1).toUpperCase()}</Text>
            </View>
            <TouchableOpacity style={s.userInfo} onPress={() => handleEdit(u)} activeOpacity={0.7}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Text style={[s.uName, { color: Colors.text.primary }]}>{u.full_name}</Text>
                {!u.is_active && <View style={[s.inactiveBadge, { backgroundColor: Colors.status.inactiveBg }]}><Text style={s.inactiveBadgeText}>OFF</Text></View>}
              </View>
              <Text style={[s.uMeta, { color: Colors.text.secondary }]}>@{u.username} · {u.tenant_role_name || u.role_name.replace('_', ' ')}</Text>
              {u.tenant_name && <Text style={[s.uTenant, { color: Colors.text.muted }]}>🏢 {u.tenant_name}</Text>}
            </TouchableOpacity>
            <View style={s.listActions}>
              <IconButton icon="pencil-outline" size={20} iconColor={Colors.text.muted} onPress={() => handleEdit(u)} />
              <IconButton icon="delete-outline" size={20} iconColor={Colors.brand.danger} onPress={() => handleDelete(u)} />
            </View>
          </View>
        )}
      />

      {/* Floating Action Button */}
      <TouchableOpacity 
        style={[s.fab, { backgroundColor: Colors.brand.primary, shadowColor: Colors.brand.primary }]} 
        onPress={() => { setForm(EMPTY_FORM); setEditingId(null); setModalVisible(true); }}
        activeOpacity={0.8}
      >
        <Text style={s.fabText}>+</Text>
      </TouchableOpacity>

      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={[s.modalOverlay, { backgroundColor: Colors.bg.overlay }]}>
          <View style={[s.modalCard, { backgroundColor: Colors.bg.card }]}>
            <View style={s.sheetHeader}>
              <Text style={[s.modalTitle, { color: Colors.text.primary }]}>{editingId ? 'Edit User' : 'New User'}</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Text style={[s.closeBtn, { color: Colors.text.muted }]}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }}>
              <Text style={[s.label, { color: Colors.text.secondary }]}>Full Name</Text>
              <TextInput
                style={[s.input, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, color: Colors.text.primary }]}
                value={form.full_name}
                onChangeText={v => setForm({ ...form, full_name: v })}
                placeholder="e.g. John Doe"
                placeholderTextColor={Colors.text.muted}
              />

              <Text style={[s.label, { color: Colors.text.secondary }]}>Username *</Text>
              <TextInput
                style={[s.input, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, color: Colors.text.primary }]}
                value={form.username}
                onChangeText={v => setForm({ ...form, username: v })}
                autoCapitalize="none"
              />

              {!editingId && (
                <>
                  <Text style={[s.label, { color: Colors.text.secondary }]}>Password *</Text>
                  <TextInput
                    style={[s.input, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, color: Colors.text.primary }]}
                    value={form.password}
                    onChangeText={v => setForm({ ...form, password: v })}
                    secureTextEntry
                  />
                </>
              )}

              {isSuperAdmin && (
                <>
                  <Text style={[s.label, { color: Colors.text.secondary }]}>Assign Tenant</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.pickerRow}>
                    <TouchableOpacity
                      style={[s.pickerChip, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default }, form.tenant_id === null && { borderColor: Colors.brand.primary, backgroundColor: Colors.brand.primary + '15' }]}
                      onPress={() => { setForm({ ...form, tenant_id: null, tenant_role_id: null }); setRoles([]); }}
                    >
                      <Text style={[s.pickerChipTxt, { color: Colors.text.secondary }, form.tenant_id === null && { color: Colors.brand.primary, fontWeight: '700' }]}>System Only</Text>
                    </TouchableOpacity>
                    {tenants.map(t => (
                      <TouchableOpacity
                        key={t.id}
                        style={[s.pickerChip, { marginLeft: 8, backgroundColor: Colors.bg.primary, borderColor: Colors.border.default }, form.tenant_id === t.id && { borderColor: Colors.brand.primary, backgroundColor: Colors.brand.primary + '15' }]}
                        onPress={() => { setForm({ ...form, tenant_id: t.id, tenant_role_id: null }); loadRoles(t.id); }}
                      >
                        <Text style={[s.pickerChipTxt, { color: Colors.text.secondary }, form.tenant_id === t.id && { color: Colors.brand.primary, fontWeight: '700' }]}>{t.name}</Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                </>
              )}

              {(form.tenant_id || !isSuperAdmin) && (
                <>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 16, marginBottom: 8 }}>
                    <Text style={[s.label, { marginTop: 0, color: Colors.text.secondary }]}>Security Mapping</Text>
                    <TouchableOpacity onPress={() => { setModalVisible(false); router.push('/(app)/settings/role-permissions'); }}>
                      <Text style={{ fontSize: 11, color: Colors.brand.primary, fontWeight: '700' }}>View Permissions ›</Text>
                    </TouchableOpacity>
                  </View>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.pickerRow}>
                    {roles.map(r => (
                      <TouchableOpacity
                        key={r.id}
                        style={[s.pickerChip, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default }, form.tenant_role_id === r.id && { borderColor: Colors.brand.primary, backgroundColor: Colors.brand.primary + '15' }]}
                        onPress={() => setForm({ ...form, tenant_role_id: r.id })}
                      >
                        <Text style={[s.pickerChipTxt, { color: Colors.text.secondary }, form.tenant_role_id === r.id && { color: Colors.brand.primary, fontWeight: '700' }]}>{r.name}</Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                </>
              )}

              <View style={s.switchRow}>
                <View>
                  <Text style={[s.switchLabel, { color: Colors.text.primary }]}>Active Status</Text>
                  <Text style={[s.switchSub, { color: Colors.text.muted }]}>Allow user to login</Text>
                </View>
                <Switch
                  value={form.is_active}
                  onValueChange={v => setForm({ ...form, is_active: v })}
                  trackColor={{ false: '#334155', true: Colors.brand.primary }}
                  thumbColor="#FFF"
                />
              </View>
            </ScrollView>

            <View style={s.modalFooter}>
              <TouchableOpacity style={[s.btn, s.btnCancel, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default }]} onPress={() => setModalVisible(false)}>
                <Text style={[s.btnText, { color: Colors.text.secondary }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.btn, s.btnSave, { backgroundColor: Colors.brand.primary }]} onPress={handleSave} disabled={saving}>
                {saving ? <ActivityIndicator color="#fff" /> : <Text style={[s.btnText, { color: '#FFF' }]}>Save User</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 12, paddingTop: 8 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  actionHeader: { flexDirection: 'row', alignItems: 'center', marginVertical: 10, gap: 10 },
  searchBar: { flex: 1, flexDirection: 'row', alignItems: 'center', height: 40, borderRadius: 10, borderWidth: 1, paddingHorizontal: 4 },
  searchInput: { flex: 1, fontSize: 13, fontWeight: '500' },
  mapBtn: { borderRadius: 10, borderWidth: 1, margin: 0 },
  
  listItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1 },
  userAvatar: { width: 44, height: 44, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  avatarTxt: { fontSize: 16, fontWeight: '800' },
  userInfo: { flex: 1, marginLeft: 14 },
  uName: { fontSize: 15, fontWeight: '700' },
  uMeta: { fontSize: 12, marginTop: 1 },
  uTenant: { fontSize: 11, marginTop: 2 },
  inactiveBadge: { paddingHorizontal: 6, paddingVertical: 1, borderRadius: 4 },
  inactiveBadgeText: { fontSize: 8, fontWeight: '900', color: '#FFF' },
  listActions: { flexDirection: 'row', alignItems: 'center' },

  emptyContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', marginTop: 100, paddingHorizontal: 40 },
  emptyIconCircle: { width: 80, height: 80, borderRadius: 40, justifyContent: 'center', alignItems: 'center', marginBottom: 20 },
  emptyIconText: { fontSize: 32 },
  emptyTitle: { fontSize: 18, fontWeight: '800', marginBottom: 8 },
  emptySub: { fontSize: 14, textAlign: 'center', lineHeight: 20 },

  fab: { position: 'absolute', right: 24, bottom: 24, width: 60, height: 60, borderRadius: 30, justifyContent: 'center', alignItems: 'center', elevation: 8, shadowOpacity: 0.3, shadowRadius: 10, shadowOffset: { width: 0, height: 5 } },
  fabText: { color: '#FFF', fontSize: 32, fontWeight: '300', marginTop: -4 },
  modalOverlay: { flex: 1, justifyContent: 'flex-end' },
  modalCard: { borderTopLeftRadius: 32, borderTopRightRadius: 32, padding: 24, height: '90%' },
  sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 22, fontWeight: '900' },
  closeBtn: { fontSize: 20, padding: 4 },
  label: { fontSize: 10, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 1, marginTop: 16, marginBottom: 8 },
  input: { borderRadius: 14, borderWidth: 1, paddingHorizontal: 16, paddingVertical: 12, fontSize: 15 },
  pickerRow: { flexGrow: 0, marginBottom: 8 },
  pickerChip: { paddingHorizontal: 16, paddingVertical: 9, borderRadius: 12, borderWidth: 1 },
  pickerChipTxt: { fontSize: 13, fontWeight: '600' },
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 24, paddingVertical: 12, borderTopWidth: 1, borderTopColor: '#f1f5f9' },
  switchLabel: { fontSize: 15, fontWeight: '700' },
  switchSub: { fontSize: 12, marginTop: 2 },
  modalFooter: { flexDirection: 'row', gap: 12, marginTop: 10, paddingBottom: 20 },
  btn: { flex: 1, height: 54, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  btnCancel: { borderWidth: 1 },
  btnSave: { elevation: 4 },
  btnText: { fontWeight: '800', fontSize: 16 },
});
