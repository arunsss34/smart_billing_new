import api from './client';

export interface Tenant {
  id: number;
  name: string;
  business_type: string;
  email: string;
  phone: string;
  subscription_expiry: string;
  is_active: boolean;
  theme_color: string;
  created_at: string;
}

export interface TenantCreate {
  name: string;
  business_type: string;
  email: string;
  phone: string;
  subscription_expiry: string;
  is_active: boolean;
  theme_color: string;
}

export const BUSINESS_TYPES = [
  { value: 'restaurant',   label: 'Restaurant',   icon: '🍽️', features: 'KOT, Table Management' },
  { value: 'bakery',       label: 'Bakery',        icon: '🥐', features: 'Expiry Tracking' },
  { value: 'supermarket',  label: 'Supermarket',   icon: '🛒', features: 'Barcode Scanning' },
  { value: 'dress_shop',   label: 'Dress Shop',    icon: '👗', features: 'Size & Color Variants' },
  { value: 'mobile_shop',  label: 'Mobile Shop',   icon: '📱', features: 'IMEI Tracking, Barcode' },
];

export const tenantApi = {
  list: async (): Promise<Tenant[]> => {
    const res = await api.get('/tenants/');
    return res.data;
  },

  create: async (data: TenantCreate): Promise<Tenant> => {
    const res = await api.post('/tenants/', data);
    return res.data;
  },

  update: async (id: number, data: Partial<TenantCreate>): Promise<Tenant> => {
    const res = await api.put(`/tenants/${id}`, data);
    return res.data;
  },

  deactivate: async (id: number): Promise<void> => {
    await api.delete(`/tenants/${id}`);
  },
};
