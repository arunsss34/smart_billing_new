import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const DEFAULT_BASE_URL = 'http://192.168.1.34:8000';

const api = axios.create({
  baseURL: DEFAULT_BASE_URL,
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' },
});

// Initialize baseURL from AsyncStorage
AsyncStorage.getItem('api_base_url').then(url => {
  if (url) {
    api.defaults.baseURL = url;
  }
});

// Helper to update API URL dynamically
export const setApiBaseUrl = async (url: string) => {
  await AsyncStorage.setItem('api_base_url', url);
  api.defaults.baseURL = url;
};

// Helper to get current API URL
export const getApiBaseUrl = async () => {
  return await AsyncStorage.getItem('api_base_url') || DEFAULT_BASE_URL;
};

// Attach token to every request
api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('access_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle 401 globally
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      await AsyncStorage.removeItem('access_token');
      // Navigation handled by auth store
    }
    return Promise.reject(error);
  }
);

export default api;

