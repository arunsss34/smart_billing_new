import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, Modal, Alert, ActivityIndicator,
} from 'react-native';
import { IconButton } from 'react-native-paper';
import api from '../api/client';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors, Spacing, Radius, FontSize } from '../theme';

interface TenantRole {
  id: number;
  tenant_id: number;
  name: string;
  description: string | null;
  is_active: boolean;
}

const ROLE_COLORS = ['#6366F1', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4', '#EC4899'];

export default function RoleManagementScreen() {
  const { themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);

  const [roles, setRoles] = useState<TenantRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [editItem, setEditItem] = useState<TenantRole | null>(null);
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/roles/');
      const tenantOnly = data.filter((r: TenantRole) => r.tenant_id !== undefined && r.tenant_id !== null);
      setRoles(tenantOnly);
    } catch (e: any) {
      Alert.alert('Error', e?.response?.data?.detail || 'Failed to load roles');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openAdd = () => {
    setEditItem(null); setName(''); setDesc(''); setModal(true);
  };

  const openEdit = (r: TenantRole) => {
    setEditItem(r); setName(r.name); setDesc(r.description || ''); setModal(true);
  };

  const handleSave = async () => {
    if (!name.trim()) return Alert.alert('Validation', 'Role name is required');
    setSaving(true);
    try {
      if (editItem) {
        await api.put(`/roles/${editItem.id}`, { name: name.trim(), description: desc.trim() || null });
      } else {
        await api.post('/roles/', { name: name.trim(), description: desc.trim() || null });
      }
      setModal(false);
      load();
    } catch (e: any) {
      Alert.alert('Error', e?.response?.data?.detail || 'Failed to save role');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = (r: TenantRole) => {
    Alert.alert(
      'Delete Role',
      `Delete "${r.name}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete', style: 'destructive',
          onPress: async () => {
            try {
              await api.delete(`/roles/${r.id}`);
              load();
            } catch (e: any) {
              Alert.alert('Cannot Delete', e?.response?.data?.detail || 'Failed to delete');
            }
          }
        }
      ]
    );
  };

  const getColor = (index: number) => ROLE_COLORS[index % ROLE_COLORS.length];

  const renderItem = ({ item, index }: { item: TenantRole; index: number }) => {
    const color = getColor(index);
    const initials = item.name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
    return (
      <View style={[s.listItem, { borderBottomColor: Colors.border.subtle }]}>
        <View style={[s.roleAvatar, { backgroundColor: color + '15', borderColor: color + '44' }]}>
          <Text style={[s.roleInitials, { color }]}>{initials}</Text>
        </View>
        <TouchableOpacity style={s.roleInfo} onPress={() => openEdit(item)} activeOpacity={0.7}>
          <Text style={[s.roleName, { color: Colors.text.primary }]}>{item.name}</Text>
          {item.description
            ? <Text style={[s.roleDesc, { color: Colors.text.secondary }]} numberOfLines={1}>{item.description}</Text>
            : <Text style={[s.roleDescEmpty, { color: Colors.text.disabled }]}>No description</Text>
          }
        </TouchableOpacity>
        <View style={s.listActions}>
          <IconButton icon="pencil-outline" size={20} iconColor={Colors.text.muted} onPress={() => openEdit(item)} />
          <IconButton icon="delete-outline" size={20} iconColor={Colors.brand.danger} onPress={() => handleDelete(item)} />
        </View>
      </View>
    );
  };

  const filteredRoles = roles.filter(r => 
    r.name.toLowerCase().includes(search.toLowerCase()) || 
    (r.description && r.description.toLowerCase().includes(search.toLowerCase()))
  );

  if (loading) return (
    <View style={[s.center, { backgroundColor: Colors.bg.primary }]}>
      <ActivityIndicator color={Colors.brand.primary} />
    </View>
  );

  return (
    <View style={[s.container, { backgroundColor: Colors.bg.primary }]}>
      <View style={s.actionHeader}>
        <View style={[s.searchBar, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
          <IconButton icon="magnify" size={18} iconColor={Colors.text.muted} style={{ margin: 0 }} />
          <TextInput 
            style={[s.searchInput, { color: Colors.text.primary }]} 
            value={search} 
            onChangeText={setSearch} 
            placeholder="Search roles..." 
            placeholderTextColor={Colors.text.muted} 
          />
        </View>
      </View>

      <FlatList
        data={filteredRoles}
        renderItem={renderItem}
        keyExtractor={r => String(r.id)}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 100 }}
        ListEmptyComponent={
          <View style={s.emptyBox}>
            <Text style={s.emptyIcon}>🛡</Text>
            <Text style={[s.emptyTitle, { color: Colors.text.primary }]}>No Roles Found</Text>
            <Text style={[s.emptyDesc, { color: Colors.text.muted }]}>
              {search ? 'Try a different search term.' : 'Create roles like Cashier, Manager to assign to your team.'}
            </Text>
          </View>
        }
      />

      <Modal visible={modal} transparent animationType="slide">
        <View style={[s.overlay, { backgroundColor: Colors.bg.overlay }]}>
          <View style={[s.sheet, { backgroundColor: Colors.bg.primary }]}>
            <View style={s.sheetHeader}>
              <Text style={[s.sheetTitle, { color: Colors.text.primary }]}>{editItem ? 'Edit Role' : 'New Role'}</Text>
              <TouchableOpacity onPress={() => setModal(false)}>
                <Text style={[s.closeBtn, { color: Colors.text.muted }]}>✕</Text>
              </TouchableOpacity>
            </View>

            <Text style={[s.fieldLabel, { color: Colors.text.secondary }]}>Role Name *</Text>
            <TextInput
              style={[s.input, { backgroundColor: Colors.bg.card, color: Colors.text.primary, borderColor: Colors.border.default }]}
              value={name}
              onChangeText={setName}
              placeholder="e.g. Cashier"
              placeholderTextColor={Colors.text.muted}
            />

            <Text style={[s.fieldLabel, { color: Colors.text.secondary }]}>Description</Text>
            <TextInput
              style={[s.input, { height: 80, textAlignVertical: 'top', paddingTop: 10, backgroundColor: Colors.bg.card, color: Colors.text.primary, borderColor: Colors.border.default }]}
              value={desc}
              onChangeText={setDesc}
              placeholder="What does this role do?"
              placeholderTextColor={Colors.text.muted}
              multiline
            />

            <View style={s.sheetActions}>
              <TouchableOpacity style={[s.cancelBtn, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]} onPress={() => setModal(false)}>
                <Text style={[s.cancelTxt, { color: Colors.text.secondary }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[s.saveBtn, { backgroundColor: Colors.brand.primary }, saving && { opacity: 0.6 }]}
                onPress={handleSave}
                disabled={saving}
              >
                {saving ? <ActivityIndicator color="#fff" /> : <Text style={s.saveTxt}>Save Role</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <TouchableOpacity 
        style={[s.fab, { backgroundColor: Colors.brand.primary, shadowColor: Colors.brand.primary }]} 
        onPress={openAdd}
        activeOpacity={0.8}
      >
        <Text style={s.fabText}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 12 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  actionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 10, gap: 10 },
  searchBar: { flex: 1, flexDirection: 'row', alignItems: 'center', height: 40, borderRadius: 10, borderWidth: 1, paddingHorizontal: 4 },
  searchInput: { flex: 1, fontSize: 13, fontWeight: '500' },
  
  fab: { 
    position: 'absolute', 
    right: 24, 
    bottom: 24, 
    width: 60, 
    height: 60, 
    borderRadius: 30, 
    justifyContent: 'center', 
    alignItems: 'center', 
    elevation: 8, 
    shadowOpacity: 0.3, 
    shadowRadius: 10, 
    shadowOffset: { width: 0, height: 5 } 
  },
  fabText: { color: '#FFF', fontSize: 32, fontWeight: '300', marginTop: -4 },
  
  listItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1 },
  roleAvatar: { width: 42, height: 42, borderRadius: 12, justifyContent: 'center', alignItems: 'center', borderWidth: 1.5 },
  roleInitials: { fontSize: 14, fontWeight: '800' },
  roleInfo: { flex: 1, marginLeft: 14 },
  roleName: { fontSize: 15, fontWeight: '700' },
  roleDesc: { fontSize: 11, marginTop: 2 },
  roleDescEmpty: { fontSize: 11, marginTop: 2, fontStyle: 'italic' },
  listActions: { flexDirection: 'row', alignItems: 'center' },
  emptyBox: { alignItems: 'center', paddingTop: 60, paddingHorizontal: 30 },
  emptyIcon: { fontSize: 48, marginBottom: 12 },
  emptyTitle: { fontSize: 18, fontWeight: '700', marginBottom: 8 },
  emptyDesc: { fontSize: 14, textAlign: 'center', lineHeight: 20 },
  overlay: { flex: 1, justifyContent: 'flex-end' },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24 },
  sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  sheetTitle: { fontSize: 18, fontWeight: '800' },
  closeBtn: { fontSize: 18, padding: 4 },
  fieldLabel: { fontSize: 12, fontWeight: '700', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  input: { borderRadius: Radius.md, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, borderWidth: 1, marginBottom: 16 },
  sheetActions: { flexDirection: 'row', gap: 10 },
  cancelBtn: { flex: 1, paddingVertical: 13, borderRadius: Radius.md, alignItems: 'center', borderWidth: 1 },
  cancelTxt: { fontWeight: '600' },
  saveBtn: { flex: 2, paddingVertical: 13, borderRadius: Radius.md, alignItems: 'center' },
  saveTxt: { color: '#fff', fontWeight: '800', fontSize: 15 },
});
