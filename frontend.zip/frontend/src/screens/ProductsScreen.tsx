import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  ActivityIndicator, TextInput, Alert, Modal, ScrollView,
} from 'react-native';
import { IconButton } from 'react-native-paper';
import ModernAlert from '../components/ModernAlert';
import ModernToast from '../components/ModernToast';
import { productsApi, Product } from '../api/business.api';
import { mastersApi, UOM, Category, HSN } from '../api/masters.api';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import MasterDropdown from '../components/MasterDropdown';
import BarcodeScannerModal from '../components/BarcodeScannerModal';
import { getColors, Spacing, Radius, FontSize } from '../theme';

type FormData = Partial<Product> & { hsn_id?: number; uom_id?: number; category_id?: number };

const EMPTY: FormData = {
  name: '', price: 0, stock_qty: 0,
  category: '', category_id: undefined,
  unit: '', uom_id: undefined,
  barcode: '', sku: '',
  hsn_id: undefined,
};

export default function ProductsScreen() {
  const { menus, features, themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);
  const perm = menus?.find(m => m.route === 'products');

  const [products, setProducts] = useState<Product[]>([]);
  const [uoms, setUoms] = useState<UOM[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [hsnList, setHsnList] = useState<HSN[]>([]);

  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [form, setForm] = useState<FormData>({ ...EMPTY });
  const [editId, setEditId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [scannerVisible, setScannerVisible] = useState(false);
  const [scannerTarget, setScannerTarget] = useState<'search'|'barcode'|'sku'|null>(null);
  const [itemToDelete, setItemToDelete] = useState<Product | null>(null);
  const [toast, setToast] = useState<{ visible: boolean; msg: string; type: 'success' | 'error' }>({ visible: false, msg: '', type: 'success' });
  const [alert, setAlert] = useState<{ visible: boolean; title: string; msg: string; type: any; onConfirm: () => void }>({ 
    visible: false, title: '', msg: '', type: 'info', onConfirm: () => {} 
  });

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => setToast({ visible: true, msg, type });
  const showAlert = (title: string, msg: string, type: any = 'info', onConfirm: () => void = () => setAlert(prev => ({...prev, visible: false}))) => 
    setAlert({ visible: true, title, msg, type, onConfirm });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [prods, uomData, catData, hsnData] = await Promise.all([
        productsApi.list(),
        mastersApi.listUOM(),
        mastersApi.listCategories(),
        mastersApi.listHSN(),
      ]);
      setProducts(prods || []);
      setUoms(uomData || []);
      setCategories(catData || []);
      setHsnList(hsnData || []);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'System Error: Failed to load inventory data.', 'error');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.category?.toLowerCase().includes(search.toLowerCase())
  );

  const handleEdit = (item: Product) => {
    setForm({
      ...item,
      category_id: categories.find(c => c.name === item.category)?.id,
      uom_id: uoms.find(u => u.name === item.unit)?.id,
      hsn_id: hsnList.find(h => h.hsn_code === (item as any).hsn_code)?.id,
    });
    setEditId(item.id);
    setModalVisible(true);
  };

  const handleDelete = (item: Product) => {
    setItemToDelete(item);
    showAlert(
      'Delete Product?',
      `Are you sure you want to permanently remove "${item.name}" from your inventory? This action cannot be undone.`,
      'danger',
      confirmDelete
    );
  };

  const confirmDelete = async () => {
    if (!itemToDelete) return;
    setAlert(prev => ({ ...prev, visible: false }));
    try {
      await productsApi.delete(itemToDelete.id);
      setProducts(products.filter(p => p.id !== itemToDelete.id));
      showToast(`Success! ${itemToDelete.name} has been removed.`, 'success');
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Deletion Failed: Could not remove product.', 'error');
    } finally {
      setItemToDelete(null);
    }
  };

  const handleSave = async () => {
    if (!form.name || !form.price || !form.category_id || !form.uom_id) {
      showToast('Validation Error: Name, Price, Category and UOM are required.', 'error');
      return;
    }
    setSaving(true);
    try {
      if (editId) {
        await productsApi.update(editId, form);
      } else {
        await productsApi.create(form);
      }
      load();
      setModalVisible(false);
      showToast(`Product ${editId ? 'updated' : 'created'} successfully!`, 'success');
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Save Failed: An error occurred while saving the product.', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return (
    <View style={[s.center, { backgroundColor: Colors.bg.primary }]}>
      <ActivityIndicator color={Colors.brand.primary} />
    </View>
  );

  return (
    <View style={[s.container, { backgroundColor: Colors.bg.primary }]}>
      <View style={s.searchBarWrapper}>
        <View style={[s.searchBar, { backgroundColor: Colors.bg.card }]}>
          <IconButton
            icon="magnify"
            size={22}
            iconColor={Colors.text.muted}
            style={{ margin: 0 }}
          />
          <TextInput
            style={[s.searchInput, { color: Colors.text.primary }]}
            placeholder="Search products..."
            placeholderTextColor={Colors.text.muted}
            value={search}
            onChangeText={setSearch}
          />
          <IconButton
            icon="barcode-scan"
            size={22}
            iconColor={Colors.brand.primary}
            onPress={() => { setScannerTarget('search'); setScannerVisible(true); }}
            style={{ margin: 0 }}
          />
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={i => String(i.id)}
        renderItem={({ item }) => (
          <TouchableOpacity 
            style={[s.listItem, { borderBottomColor: Colors.border.subtle }]}
            onPress={() => handleEdit(item)}
            activeOpacity={0.7}
          >
            <View style={s.listMain}>
              <View style={[s.listIcon, { backgroundColor: Colors.brand.primary + '10' }]}>
                <Text style={s.listIconText}>📦</Text>
              </View>
              
              <View style={s.listInfo}>
                <Text style={[s.listName, { color: Colors.text.primary }]} numberOfLines={1}>{item.name}</Text>
                <View style={s.listMetaRow}>
                  <Text style={[s.listMeta, { color: Colors.text.muted }]}>{item.category || 'General'}</Text>
                  <View style={s.listDot} />
                  <Text style={[s.listMeta, { color: Colors.text.muted }]}>HSN: {item.hsn_code || 'NA'}</Text>
                </View>
              </View>
            </View>

            <View style={s.listRight}>
              <View style={s.listPriceBox}>
                <Text style={[s.listPrice, { color: Colors.text.primary }]}>₹{item.price}</Text>
                <Text style={[s.listStock, { color: Number(item.stock_qty) > 5 ? Colors.brand.success : Colors.brand.danger }]}>
                  {item.stock_qty} {item.unit}
                </Text>
              </View>
              <IconButton 
                icon="trash-can-outline"
                size={20}
                iconColor={Colors.brand.danger}
                onPress={() => handleDelete(item.id)}
                style={{ margin: 0 }}
              />
            </View>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <View style={s.emptyContainer}>
            <View style={[s.emptyIconCircle, { backgroundColor: Colors.brand.primary + '15' }]}>
              <Text style={s.emptyIconText}>📦</Text>
            </View>
            <Text style={[s.emptyTitle, { color: Colors.text.primary }]}>No Products Found</Text>
            <Text style={[s.emptySub, { color: Colors.text.muted }]}>
              Your inventory is empty. Start adding products to manage your billing.
            </Text>
          </View>
        }
        contentContainerStyle={s.list}
      />

      {/* Floating Action Button - Fixed Position */}
      <TouchableOpacity 
        style={[s.fab, { backgroundColor: Colors.brand.primary, shadowColor: Colors.brand.primary }]} 
        onPress={() => { setForm({ ...EMPTY }); setEditId(null); setModalVisible(true); }}
        activeOpacity={0.8}
      >
        <Text style={s.fabText}>+</Text>
      </TouchableOpacity>

      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={[s.modalRoot, { backgroundColor: Colors.bg.overlay }]}>
          <View style={[s.modalCard, { backgroundColor: Colors.bg.card }]}>
            <Text style={[s.modalTitle, { color: Colors.text.primary }]}>{editId ? 'Edit Product' : 'Add New Product'}</Text>
            <ScrollView style={s.form} showsVerticalScrollIndicator={false}>
              <Text style={[s.label, { color: Colors.text.secondary }]}>Product Name *</Text>
              <TextInput
                style={[s.input, { backgroundColor: '#FFFFFF', borderColor: Colors.border.default, color: Colors.text.primary }]}
                value={form.name}
                onChangeText={v => setForm({ ...form, name: v })}
                placeholder=""
                placeholderTextColor={Colors.text.muted}
              />

              <View style={s.formRow}>
                <View style={{ flex: 1 }}>
                  <Text style={[s.label, { color: Colors.text.secondary }]}>Price *</Text>
                  <TextInput
                    style={[s.input, { backgroundColor: '#FFFFFF', borderColor: Colors.border.default, color: Colors.text.primary }]}
                    value={String(form.price)}
                    onChangeText={v => setForm({ ...form, price: Number(v) || 0 })}
                    keyboardType="numeric"
                  />
                </View>
                <View style={{ width: 12 }} />
                <View style={{ flex: 1 }}>
                  <Text style={[s.label, { color: Colors.text.secondary }]}>Initial Stock</Text>
                  <TextInput
                    style={[s.input, { backgroundColor: '#FFFFFF', borderColor: Colors.border.default, color: Colors.text.primary }]}
                    value={String(form.stock_qty)}
                    onChangeText={v => setForm({ ...form, stock_qty: Number(v) || 0 })}
                    keyboardType="numeric"
                  />
                </View>
              </View>

              <MasterDropdown
                label="Category *"
                items={categories.map(c => ({ id: c.id, label: c.name }))}
                value={form.category_id}
                onSelect={item => setForm({ ...form, category_id: item.id as number, category: item.label })}
                placeholder="Select Category"
                searchable
                style={{ backgroundColor: '#FFFFFF' }}
              />

              <MasterDropdown
                label="UOM (Unit) *"
                items={uoms.map(u => ({ id: u.id, label: u.name }))}
                value={form.uom_id}
                onSelect={item => setForm({ ...form, uom_id: item.id as number, unit: item.label })}
                placeholder="Select Unit (e.g. Kg, Pcs)"
                searchable
                style={{ backgroundColor: '#FFFFFF' }}
              />

              <Text style={[s.label, { color: Colors.text.secondary }]}>Barcode</Text>
              <View style={s.barcodeRow}>
                <TextInput
                  style={[s.input, { flex: 1, backgroundColor: '#FFFFFF', borderColor: Colors.border.default, color: Colors.text.primary }]}
                  value={form.barcode}
                  onChangeText={v => setForm({ ...form, barcode: v })}
                  placeholder=""
                  placeholderTextColor={Colors.text.muted}
                />
                <IconButton
                  icon="barcode-scan"
                  size={24}
                  iconColor={Colors.brand.primary}
                  onPress={() => { setScannerTarget('barcode'); setScannerVisible(true); }}
                  style={{ margin: 0 }}
                />
              </View>

              <Text style={[s.label, { color: Colors.text.secondary }]}>SKU / Code</Text>
              <View style={s.barcodeRow}>
                <TextInput
                  style={[s.input, { flex: 1, backgroundColor: '#FFFFFF', borderColor: Colors.border.default, color: Colors.text.primary }]}
                  value={form.sku}
                  onChangeText={v => setForm({ ...form, sku: v })}
                  placeholder=""
                  placeholderTextColor={Colors.text.muted}
                />
                <IconButton
                  icon="barcode-scan"
                  size={24}
                  iconColor={Colors.brand.primary}
                  onPress={() => { setScannerTarget('sku'); setScannerVisible(true); }}>
                </IconButton>
              </View>

              <MasterDropdown
                label="HSN Code"
                items={hsnList.map(h => ({ id: h.id, label: h.hsn_code, sublabel: `${h.igst_rate}% GST` }))}
                value={form.hsn_id}
                onSelect={item => setForm({ ...form, hsn_id: item.id as number, hsn_code: item.label })}
                placeholder="Select HSN (for GST)"
                searchable
                style={{ backgroundColor: '#FFFFFF' }}
              />

              <View style={{ height: 20 }} />
            </ScrollView>

            <View style={s.modalFooter}>
              <TouchableOpacity style={[s.btn, s.btnCancel, { backgroundColor: Colors.bg.primary }]} onPress={() => setModalVisible(false)}>
                <Text style={[s.btnText, { color: Colors.text.secondary }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.btn, s.btnSave, { backgroundColor: Colors.brand.primary }]} onPress={handleSave} disabled={saving}>
                {saving ? <ActivityIndicator color="#fff" /> : <Text style={s.btnText}>Save Product</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <BarcodeScannerModal
        visible={scannerVisible}
        onClose={() => setScannerVisible(false)}
        onScan={data => {
          setScannerVisible(false);
          if (scannerTarget === 'search') setSearch(data);
          else if (scannerTarget === 'barcode') setForm({ ...form, barcode: data });
          else if (scannerTarget === 'sku') setForm({ ...form, sku: data });
        }}
      />


      <ModernAlert 
        visible={alert.visible}
        title={alert.title}
        message={alert.msg}
        type={alert.type}
        onConfirm={alert.onConfirm}
        onCancel={() => setAlert(prev => ({...prev, visible: false}))}
      />

      <ModernToast 
        visible={toast.visible}
        message={toast.msg}
        type={toast.type}
        onHide={() => setToast(prev => ({...prev, visible: false}))}
      />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  searchBarWrapper: { padding: 12, paddingBottom: 8 },
  searchBar: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    borderRadius: 12, 
    paddingHorizontal: 4,
    height: 40,
    borderWidth: 1,
    borderColor: '#e2e8f0'
  },
  searchInput: { flex: 1, fontSize: 14, fontWeight: '500' },
  addBtn: { borderRadius: Radius.md, paddingHorizontal: 16, justifyContent: 'center' },
  addBtnText: { color: '#fff', fontWeight: '700' },
  list: { paddingBottom: 100 },
  listItem: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
  },
  listMain: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  listIcon: { width: 44, height: 44, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginRight: 16 },
  listIconText: { fontSize: 18 },
  listInfo: { flex: 1 },
  listName: { fontSize: 16, fontWeight: '700', marginBottom: 4 },
  listMetaRow: { flexDirection: 'row', alignItems: 'center' },
  listMeta: { fontSize: 12, fontWeight: '500' },
  listDot: { width: 3, height: 3, borderRadius: 1.5, backgroundColor: '#cbd5e1', marginHorizontal: 8 },
  listRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  listPriceBox: { alignItems: 'flex-end' },
  listPrice: { fontSize: 16, fontWeight: '800' },
  listStock: { fontSize: 11, fontWeight: '700', marginTop: 2 },
  // Empty State
  emptyContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', marginTop: 100, paddingHorizontal: 40 },
  emptyIconCircle: { width: 80, height: 80, borderRadius: 40, justifyContent: 'center', alignItems: 'center', marginBottom: 20 },
  emptyIconText: { fontSize: 32 },
  emptyTitle: { fontSize: 18, fontWeight: '800', marginBottom: 8 },
  emptySub: { fontSize: 14, textAlign: 'center', lineHeight: 20 },
  // FAB
  fab: { position: 'absolute', right: 24, bottom: 24, width: 60, height: 60, borderRadius: 30, justifyContent: 'center', alignItems: 'center', elevation: 8, shadowOpacity: 0.3, shadowRadius: 10, shadowOffset: { width: 0, height: 5 } },
  fabText: { color: '#FFF', fontSize: 32, fontWeight: '300', marginTop: -4 },
  modalRoot: { flex: 1, justifyContent: 'flex-end' },
  modalCard: { borderTopLeftRadius: Radius.xl, borderTopRightRadius: Radius.xl, padding: 24, height: '90%' },
  modalTitle: { fontSize: FontSize.lg, fontWeight: '800', marginBottom: 20 },
  form: { flex: 1 },
  label: { fontSize: FontSize.xs, fontWeight: '700', marginBottom: 6, marginTop: 12 },
  input: { borderRadius: Radius.md, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 10, fontSize: FontSize.sm },
  formRow: { flexDirection: 'row' },
  barcodeRow: { flexDirection: 'row', gap: 10, alignItems: 'center' },
  scanBtnIconOnly: { padding: 8 },
  scanBtnText: { fontSize: 22 },
  modalFooter: { flexDirection: 'row', gap: 12, paddingTop: 16 },
  btn: { flex: 1, paddingVertical: 14, borderRadius: Radius.md, alignItems: 'center' },
  btnCancel: { borderWidth: 1, borderColor: '#ccc' },
  btnSave: { elevation: 4 },
  btnText: { fontWeight: '700', color: '#fff' },
});
