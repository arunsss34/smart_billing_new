import TenantRolePermissionsScreen from '../../../src/screens/TenantRolePermissionsScreen';
export default TenantRolePermissionsScreen;
