import BillingNewScreen from '../../../src/screens/BillingNewScreen';
export default BillingNewScreen;
