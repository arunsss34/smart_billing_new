import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Modal, ActivityIndicator, Alert, FlatList,
} from 'react-native';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { mastersApi, UOM, Category, HSN } from '../api/masters.api';
import { getColors, Radius, FontSize } from '../theme';
import { IconButton } from 'react-native-paper';

type Tab = 'uom' | 'category' | 'hsn';

const TABS: { key: Tab; label: string; icon: string }[] = [
  { key: 'uom',      label: 'Units',    icon: 'ruler' },
  { key: 'category', label: 'Categories', icon: 'tag-multiple' },
  { key: 'hsn',      label: 'HSN/GST',  icon: 'file-percent' },
];

// ─── UOM Tab ────────────────────────────────────────────────
function UOMTab({ Colors, mode }: { Colors: any; mode: string }) {
  const { role } = useAuthStore();
  const isSuperAdmin = role === 'super_admin';
  const [items, setItems] = useState<UOM[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editId, setEditId] = useState<number | undefined>();
  const [form, setForm] = useState({ name: '', abbreviation: '' });
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try { setItems(await mastersApi.listUOM()); } catch {}
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openNew = () => { setEditId(undefined); setForm({ name: '', abbreviation: '' }); setModal(true); };
  const openEdit = (u: UOM) => { setEditId(u.id); setForm({ name: u.name, abbreviation: u.abbreviation }); setModal(true); };

  const handleSave = async () => {
    if (!form.name.trim() || !form.abbreviation.trim())
      return Alert.alert('Validation', 'Name and abbreviation required');
    setSaving(true);
    try { await mastersApi.saveUOM(form, editId); setModal(false); load(); }
    catch (e: any) { Alert.alert('Error', e?.response?.data?.detail || 'Save failed'); }
    finally { setSaving(false); }
  };

  const del = (u: UOM & { is_global?: boolean }) => {
    if (u.is_global && !isSuperAdmin)
      return Alert.alert('Global UOM', 'You cannot delete system-level UOM.');
    Alert.alert('Remove', `Remove "${u.name}"?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: async () => { await mastersApi.deleteUOM(u.id); load(); } },
    ]);
  };

  const filtered = items.filter(u => 
    u.name.toLowerCase().includes(search.toLowerCase()) || 
    u.abbreviation.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <View style={s.tabContent}>
      <View style={s.actionHeader}>
        <View style={[s.searchBar, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
          <IconButton icon="magnify" size={18} iconColor={Colors.text.muted} style={{ margin: 0 }} />
          <TextInput 
            style={[s.searchInput, { color: Colors.text.primary }]} 
            value={search} 
            onChangeText={setSearch} 
            placeholder="Search Units..." 
            placeholderTextColor={Colors.text.muted} 
          />
        </View>
      </View>

      {loading ? <ActivityIndicator color={Colors.brand.primary} style={{ marginTop: 40 }} /> : (
        <FlatList
          data={filtered}
          keyExtractor={i => String(i.id)}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={s.emptyContainer}>
              <IconButton icon="ruler" size={60} iconColor={Colors.text.disabled} />
              <Text style={[s.emptyTitle, { color: Colors.text.primary }]}>No UOM Found</Text>
              <Text style={[s.emptySub, { color: Colors.text.muted }]}>Create Units (e.g., Kg, Pcs) for products.</Text>
            </View>
          }
          renderItem={({ item: u }) => (
            <View style={[s.listItem, { borderBottomColor: Colors.border.subtle }]}>
              <View style={[s.listIconBox, { backgroundColor: Colors.brand.primary + '10' }]}>
                <Text style={[s.listIconText, { color: Colors.brand.primary }]}>{u.abbreviation.substring(0,2)}</Text>
              </View>
              <View style={s.listInfo}>
                <Text style={[s.listName, { color: Colors.text.primary }]}>{u.name}</Text>
                <Text style={[s.listSub, { color: Colors.text.muted }]}>{u.abbreviation}</Text>
              </View>
              <View style={s.listActions}>
                <IconButton icon="pencil-outline" size={20} iconColor={Colors.text.muted} onPress={() => openEdit(u)} />
                <IconButton icon="delete-outline" size={20} iconColor={Colors.brand.danger} onPress={() => del(u)} />
              </View>
            </View>
          )}
        />
      )}
      <Modal visible={modal} transparent animationType="slide">
        <View style={[s.overlay, { backgroundColor: Colors.bg.overlay }]}>
          <View style={[s.sheet, { backgroundColor: Colors.bg.card }]}>
            <Text style={[s.sheetTitle, { color: Colors.text.primary }]}>{editId ? 'Edit UOM' : 'New UOM'}</Text>
            <Text style={[s.lbl, { color: Colors.text.secondary }]}>Name *</Text>
            <TextInput style={[s.input, { backgroundColor: Colors.bg.primary, color: Colors.text.primary, borderColor: Colors.border.default }]} value={form.name} onChangeText={v => setForm(f => ({ ...f, name: v }))} placeholder="e.g. Kilogram" placeholderTextColor={Colors.text.muted} />
            <Text style={[s.lbl, { color: Colors.text.secondary }]}>Abbreviation *</Text>
            <TextInput style={[s.input, { backgroundColor: Colors.bg.primary, color: Colors.text.primary, borderColor: Colors.border.default }]} value={form.abbreviation} onChangeText={v => setForm(f => ({ ...f, abbreviation: v.toUpperCase() }))} placeholder="e.g. KG" placeholderTextColor={Colors.text.muted} autoCapitalize="characters" maxLength={10} />
            <View style={s.btnRow}>
              <TouchableOpacity style={[s.cancelBtn, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default }]} onPress={() => setModal(false)}><Text style={[s.cancelTxt, { color: Colors.text.secondary }]}>Cancel</Text></TouchableOpacity>
              <TouchableOpacity style={[s.saveBtn, { backgroundColor: Colors.brand.primary }]} onPress={handleSave} disabled={saving}>
                {saving ? <ActivityIndicator color="#fff" /> : <Text style={s.saveTxt}>Save</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <TouchableOpacity 
        style={[s.fab, { backgroundColor: Colors.brand.primary, shadowColor: Colors.brand.primary }]} 
        onPress={openNew}
        activeOpacity={0.8}
      >
        <Text style={s.fabText}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

// ─── Category Tab ────────────────────────────────────────────
function CategoryTab({ Colors, mode }: { Colors: any; mode: string }) {
  const { role } = useAuthStore();
  const isSuperAdmin = role === 'super_admin';
  const [items, setItems] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editId, setEditId] = useState<number | undefined>();
  const [form, setForm] = useState({ name: '', parent_id: null as number | null });
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try { setItems(await mastersApi.listCategories()); } catch {}
    finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const parents = items.filter(i => !i.parent_id);
  const openNew = () => { setEditId(undefined); setForm({ name: '', parent_id: null }); setModal(true); };
  const openEdit = (c: Category) => { setEditId(c.id); setForm({ name: c.name, parent_id: c.parent_id }); setModal(true); };

  const handleSave = async () => {
    if (!form.name.trim()) return Alert.alert('Validation', 'Name required');
    setSaving(true);
    try { await mastersApi.saveCategory(form, editId); setModal(false); load(); }
    catch (e: any) { Alert.alert('Error', e?.response?.data?.detail || 'Save failed'); }
    finally { setSaving(false); }
  };

  const del = (c: Category & { is_global?: boolean }) => {
    if (c.is_global && !isSuperAdmin)
      return Alert.alert('Global Category', 'You cannot delete system categories.');
    Alert.alert('Remove', `Remove "${c.name}"?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: async () => { await mastersApi.deleteCategory(c.id); load(); } },
    ]);
  };

  const getParentName = (pid: number | null) => pid ? items.find(i => i.id === pid)?.name || '' : '';

  const filtered = items.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <View style={s.tabContent}>
      <View style={s.actionHeader}>
        <View style={[s.searchBar, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
          <IconButton icon="magnify" size={18} iconColor={Colors.text.muted} style={{ margin: 0 }} />
          <TextInput 
            style={[s.searchInput, { color: Colors.text.primary }]} 
            value={search} 
            onChangeText={setSearch} 
            placeholder="Search Categories..." 
            placeholderTextColor={Colors.text.muted} 
          />
        </View>
      </View>

      {loading ? <ActivityIndicator color={Colors.brand.primary} style={{ marginTop: 40 }} /> : (
        <FlatList
          data={filtered}
          keyExtractor={i => String(i.id)}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={s.emptyContainer}>
              <IconButton icon="tag-multiple" size={60} iconColor={Colors.text.disabled} />
              <Text style={[s.emptyTitle, { color: Colors.text.primary }]}>No Categories Found</Text>
              <Text style={[s.emptySub, { color: Colors.text.muted }]}>Organize your products with categories.</Text>
            </View>
          }
          renderItem={({ item: c }) => (
            <View style={[s.listItem, { borderBottomColor: Colors.border.subtle }, c.parent_id && { paddingLeft: 32 }]}>
              <View style={[s.listIconBox, { backgroundColor: (c.parent_id ? Colors.brand.secondary : Colors.brand.primary) + '10' }]}>
                <IconButton icon={c.parent_id ? "tag-outline" : "tag-multiple"} size={18} iconColor={c.parent_id ? Colors.brand.secondary : Colors.brand.primary} style={{ margin: 0 }} />
              </View>
              <View style={s.listInfo}>
                <Text style={[s.listName, { color: Colors.text.primary }]}>{c.name}</Text>
                {c.parent_id && <Text style={[s.listSub, { color: Colors.text.muted }]}>under {getParentName(c.parent_id)}</Text>}
              </View>
              <View style={s.listActions}>
                <IconButton icon="pencil-outline" size={20} iconColor={Colors.text.muted} onPress={() => openEdit(c)} />
                <IconButton icon="delete-outline" size={20} iconColor={Colors.brand.danger} onPress={() => del(c)} />
              </View>
            </View>
          )}
        />
      )}
      <Modal visible={modal} transparent animationType="slide">
        <View style={[s.overlay, { backgroundColor: Colors.bg.overlay }]}>
          <View style={[s.sheet, { backgroundColor: Colors.bg.card }]}>
            <Text style={[s.sheetTitle, { color: Colors.text.primary }]}>{editId ? 'Edit Category' : 'New Category'}</Text>
            <Text style={[s.lbl, { color: Colors.text.secondary }]}>Name *</Text>
            <TextInput style={[s.input, { backgroundColor: Colors.bg.primary, color: Colors.text.primary, borderColor: Colors.border.default }]} value={form.name} onChangeText={v => setForm(f => ({ ...f, name: v }))} placeholder="e.g. Beverages" placeholderTextColor={Colors.text.muted} />
            
            <Text style={[s.lbl, { color: Colors.text.secondary, marginTop: 16 }]}>Parent Category</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 8 }}>
              <TouchableOpacity style={[s.chip, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default }, form.parent_id === null && { borderColor: Colors.brand.primary, backgroundColor: Colors.brand.primary + '15' }]} onPress={() => setForm(f => ({ ...f, parent_id: null }))}>
                <Text style={[s.chipTxt, { color: Colors.text.secondary }, form.parent_id === null && { color: Colors.brand.primary, fontWeight: '700' }]}>None</Text>
              </TouchableOpacity>
              {parents.filter(p => p.id !== editId).map(p => (
                <TouchableOpacity key={p.id} style={[s.chip, { marginLeft: 8, backgroundColor: Colors.bg.primary, borderColor: Colors.border.default }, form.parent_id === p.id && { borderColor: Colors.brand.primary, backgroundColor: Colors.brand.primary + '15' }]} onPress={() => setForm(f => ({ ...f, parent_id: p.id }))}>
                  <Text style={[s.chipTxt, { color: Colors.text.secondary }, form.parent_id === p.id && { color: Colors.brand.primary, fontWeight: '700' }]}>{p.name}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            <View style={s.btnRow}>
              <TouchableOpacity style={[s.cancelBtn, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default }]} onPress={() => setModal(false)}><Text style={[s.cancelTxt, { color: Colors.text.secondary }]}>Cancel</Text></TouchableOpacity>
              <TouchableOpacity style={[s.saveBtn, { backgroundColor: Colors.brand.primary }]} onPress={handleSave} disabled={saving}>
                {saving ? <ActivityIndicator color="#fff" /> : <Text style={s.saveTxt}>Save</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <TouchableOpacity 
        style={[s.fab, { backgroundColor: Colors.brand.primary, shadowColor: Colors.brand.primary }]} 
        onPress={openNew}
        activeOpacity={0.8}
      >
        <Text style={s.fabText}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

// ─── HSN Tab ─────────────────────────────────────────────────
const EMPTY_HSN = { hsn_code: '', description: '', cgst_rate: 0, sgst_rate: 0, igst_rate: 0, cess_rate: 0 };

function HSNTab({ Colors, mode }: { Colors: any; mode: string }) {
  const [items, setItems] = useState<HSN[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editId, setEditId] = useState<number | undefined>();
  const [form, setForm] = useState({ ...EMPTY_HSN });
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try { setItems(await mastersApi.listHSN()); } catch {}
    finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const openNew = () => { setEditId(undefined); setForm({ ...EMPTY_HSN }); setModal(true); };
  const openEdit = (h: HSN) => {
    setEditId(h.id);
    setForm({ hsn_code: h.hsn_code, description: h.description, cgst_rate: h.cgst_rate, sgst_rate: h.sgst_rate, igst_rate: h.igst_rate, cess_rate: h.cess_rate });
    setModal(true);
  };

  const setRate = (field: string, v: string) => {
    const n = parseFloat(v) || 0;
    setForm(f => ({
      ...f,
      [field]: n,
      ...(field === 'cgst_rate' ? { igst_rate: n + f.sgst_rate } : {}),
      ...(field === 'sgst_rate' ? { igst_rate: f.cgst_rate + n } : {}),
    }));
  };

  const handleSave = async () => {
    if (!form.hsn_code.trim() || !form.description.trim())
      return Alert.alert('Validation', 'HSN Code and Description required');
    setSaving(true);
    try { await mastersApi.saveHSN(form, editId); setModal(false); load(); }
    catch (e: any) { Alert.alert('Error', e?.response?.data?.detail || 'Save failed'); }
    finally { setSaving(false); }
  };

  const del = (h: HSN) => Alert.alert('Remove', `Remove HSN ${h.hsn_code}?`, [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Remove', style: 'destructive', onPress: async () => { await mastersApi.deleteHSN(h.id); load(); } },
  ]);

  const filtered = items.filter(h =>
    h.hsn_code.includes(search) || h.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <View style={s.tabContent}>
      <View style={s.actionHeader}>
        <View style={[s.searchBar, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
          <IconButton icon="magnify" size={18} iconColor={Colors.text.muted} style={{ margin: 0 }} />
          <TextInput 
            style={[s.searchInput, { color: Colors.text.primary }]} 
            value={search} 
            onChangeText={setSearch} 
            placeholder="Search HSN/GST..." 
            placeholderTextColor={Colors.text.muted} 
          />
        </View>
      </View>

      {loading ? <ActivityIndicator color={Colors.brand.primary} style={{ marginTop: 40 }} /> : (
        <FlatList
          data={filtered}
          keyExtractor={i => String(i.id)}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={s.emptyContainer}>
              <IconButton icon="file-percent" size={60} iconColor={Colors.text.disabled} />
              <Text style={[s.emptyTitle, { color: Colors.text.primary }]}>No HSN Found</Text>
            </View>
          }
          renderItem={({ item: h }) => (
            <View style={[s.listItem, { borderBottomColor: Colors.border.subtle }]}>
              <View style={[s.listIconBox, { backgroundColor: Colors.brand.secondary + '10' }]}>
                <IconButton icon="file-percent" size={18} iconColor={Colors.brand.secondary} style={{ margin: 0 }} />
              </View>
              <View style={s.listInfo}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <Text style={[s.listName, { color: Colors.text.primary }]}>{h.hsn_code}</Text>
                  <View style={[s.gstPill, { backgroundColor: Colors.brand.primary + '15' }]}>
                    <Text style={[s.gstPillText, { color: Colors.brand.primary }]}>{h.igst_rate}% GST</Text>
                  </View>
                </View>
                <Text style={[s.listSub, { color: Colors.text.muted }]} numberOfLines={1}>{h.description}</Text>
              </View>
              <View style={s.listActions}>
                <IconButton icon="pencil-outline" size={20} iconColor={Colors.text.muted} onPress={() => openEdit(h)} />
                <IconButton icon="delete-outline" size={20} iconColor={Colors.brand.danger} onPress={() => del(h)} />
              </View>
            </View>
          )}
        />
      )}

      <Modal visible={modal} transparent animationType="slide">
        <View style={[s.overlay, { backgroundColor: Colors.bg.overlay }]}>
          <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'flex-end' }}>
            <View style={[s.sheet, { backgroundColor: Colors.bg.card }]}>
              <Text style={[s.sheetTitle, { color: Colors.text.primary }]}>{editId ? 'Edit HSN' : 'New HSN'}</Text>
              <Text style={[s.lbl, { color: Colors.text.secondary }]}>HSN Code *</Text>
              <TextInput style={[s.input, { backgroundColor: Colors.bg.primary, color: Colors.text.primary, borderColor: Colors.border.default }]} value={form.hsn_code} onChangeText={v => setForm(f => ({ ...f, hsn_code: v }))} placeholder="e.g. 8517" placeholderTextColor={Colors.text.muted} keyboardType="numeric" />
              <Text style={[s.lbl, { color: Colors.text.secondary, marginTop: 12 }]}>Description *</Text>
              <TextInput style={[s.input, { height: 60, textAlignVertical: 'top', backgroundColor: Colors.bg.primary, color: Colors.text.primary, borderColor: Colors.border.default }]} value={form.description} onChangeText={v => setForm(f => ({ ...f, description: v }))} placeholder="Description..." placeholderTextColor={Colors.text.muted} multiline />
              
              <View style={{ flexDirection: 'row', gap: 12, marginTop: 16 }}>
                <View style={{ flex: 1 }}>
                  <Text style={[s.lbl, { color: Colors.text.secondary }]}>CGST %</Text>
                  <TextInput style={[s.input, { textAlign: 'center', backgroundColor: Colors.bg.primary, color: Colors.text.primary, borderColor: Colors.border.default }]} value={String(form.cgst_rate)} onChangeText={v => setRate('cgst_rate', v)} keyboardType="numeric" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[s.lbl, { color: Colors.text.secondary }]}>SGST %</Text>
                  <TextInput style={[s.input, { textAlign: 'center', backgroundColor: Colors.bg.primary, color: Colors.text.primary, borderColor: Colors.border.default }]} value={String(form.sgst_rate)} onChangeText={v => setRate('sgst_rate', v)} keyboardType="numeric" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[s.lbl, { color: Colors.text.secondary }]}>IGST %</Text>
                  <TextInput style={[s.input, { textAlign: 'center', backgroundColor: Colors.bg.primary, color: Colors.text.primary, borderColor: Colors.border.default }]} value={String(form.igst_rate)} editable={false} />
                </View>
              </View>

              <View style={s.btnRow}>
                <TouchableOpacity style={[s.cancelBtn, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default }]} onPress={() => setModal(false)}><Text style={[s.cancelTxt, { color: Colors.text.secondary }]}>Cancel</Text></TouchableOpacity>
                <TouchableOpacity style={[s.saveBtn, { backgroundColor: Colors.brand.primary }]} onPress={handleSave} disabled={saving}>
                  {saving ? <ActivityIndicator color="#fff" /> : <Text style={s.saveTxt}>Save</Text>}
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </View>
      </Modal>

      <TouchableOpacity 
        style={[s.fab, { backgroundColor: Colors.brand.primary, shadowColor: Colors.brand.primary }]} 
        onPress={openNew}
        activeOpacity={0.8}
      >
        <Text style={s.fabText}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

// ─── Main Screen ─────────────────────────────────────────────
export default function MastersScreen() {
  const { themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);
  const [tab, setTab] = useState<Tab>('uom');

  return (
    <View style={[s.container, { backgroundColor: Colors.bg.primary }]}>
      <View style={[s.tabBar, { borderBottomWidth: 1, borderBottomColor: Colors.border.subtle }]}>
        {TABS.map(t => (
          <TouchableOpacity 
            key={t.key} 
            style={[s.tabBtn, tab === t.key && { borderBottomWidth: 3, borderBottomColor: Colors.brand.primary }]} 
            onPress={() => setTab(t.key)} 
            activeOpacity={0.8}
          >
            <IconButton icon={t.icon} size={20} iconColor={tab === t.key ? Colors.brand.primary : Colors.text.muted} style={{ margin: 0 }} />
            <Text style={[s.tabLabel, { color: tab === t.key ? Colors.brand.primary : Colors.text.muted }]}>{t.label}</Text>
          </TouchableOpacity>
        ))}
      </View>
      {tab === 'uom'      && <UOMTab Colors={Colors} mode={mode} />}
      {tab === 'category' && <CategoryTab Colors={Colors} mode={mode} />}
      {tab === 'hsn'      && <HSNTab Colors={Colors} mode={mode} />}
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1 },
  tabBar: { flexDirection: 'row', paddingHorizontal: 8 },
  tabBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', height: 52, gap: 2 },
  tabLabel: { fontSize: 13, fontWeight: '700' },
  tabContent: { flex: 1, paddingHorizontal: 12 },
  actionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 10, gap: 10 },
  sectionTitle: { fontSize: 20, fontWeight: '900', letterSpacing: 0.3 },
  searchBar: { flex: 1, flexDirection: 'row', alignItems: 'center', height: 44, borderRadius: 12, borderWidth: 1, paddingHorizontal: 4 },
  searchInput: { flex: 1, fontSize: 14, fontWeight: '500' },
  
  fab: { 
    position: 'absolute', 
    right: 24, 
    bottom: 24, 
    width: 60, 
    height: 60, 
    borderRadius: 30, 
    justifyContent: 'center', 
    alignItems: 'center', 
    elevation: 8, 
    shadowOpacity: 0.3, 
    shadowRadius: 10, 
    shadowOffset: { width: 0, height: 5 } 
  },
  fabText: { color: '#FFF', fontSize: 32, fontWeight: '300', marginTop: -4 },
  
  listItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, borderBottomWidth: 1 },
  listIconBox: { width: 44, height: 44, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  listIconText: { fontSize: 13, fontWeight: '900', textTransform: 'uppercase' },
  listInfo: { flex: 1, marginLeft: 16 },
  listName: { fontSize: 15, fontWeight: '700' },
  listSub: { fontSize: 11, fontWeight: '600', marginTop: 2 },
  listActions: { flexDirection: 'row', alignItems: 'center' },
  gstPill: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  gstPillText: { fontSize: 9, fontWeight: '800' },

  emptyContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', marginTop: 80, paddingHorizontal: 40 },
  emptyTitle: { fontSize: 18, fontWeight: '800', marginBottom: 8, marginTop: 10 },
  emptySub: { fontSize: 14, textAlign: 'center', lineHeight: 20 },
  
  overlay: { flex: 1, justifyContent: 'flex-end' },
  sheet: { borderTopLeftRadius: 32, borderTopRightRadius: 32, padding: 24, paddingBottom: 40 },
  sheetTitle: { fontSize: 22, fontWeight: '900', marginBottom: 12 },
  lbl: { fontSize: 10, fontWeight: '800', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 1 },
  input: { borderRadius: 14, paddingHorizontal: 16, paddingVertical: 12, fontSize: 15, borderWidth: 1 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 10, borderWidth: 1 },
  chipTxt: { fontSize: 13 },
  btnRow: { flexDirection: 'row', gap: 12, marginTop: 32 },
  cancelBtn: { flex: 1, height: 54, borderRadius: 16, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  cancelTxt: { fontWeight: '700' },
  saveBtn: { flex: 2, height: 54, borderRadius: 16, alignItems: 'center', justifyContent: 'center', elevation: 4 },
  saveTxt: { color: '#fff', fontWeight: '900', fontSize: 16 },
});
