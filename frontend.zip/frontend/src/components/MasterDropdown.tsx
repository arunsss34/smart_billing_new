import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, Modal, FlatList,
  TextInput, StyleSheet,
} from 'react-native';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors, Radius, FontSize, Spacing } from '../theme';

export interface PickerItem {
  id: number | string;
  label: string;
  sublabel?: string;
}

interface Props {
  label: string;
  value: string | number | null | undefined;
  placeholder?: string;
  items: PickerItem[];
  onSelect: (item: PickerItem) => void;
  searchable?: boolean;
  allowCustom?: boolean;
  style?: any;
}

export default function MasterDropdown({ label, value, placeholder = 'Select...', items, onSelect, searchable, allowCustom, style }: Props) {
  const { themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);
  
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');

  const selected = items.find(i => 
    (value !== undefined && value !== null) && 
    (String(i.id) === String(value) || i.label === value)
  );
  const filtered = search
    ? items.filter(i => i.label.toLowerCase().includes(search.toLowerCase()))
    : items;

  return (
    <>
      {label ? <Text style={[s.label, { color: Colors.text.secondary }]}>{label}</Text> : null}
      <TouchableOpacity 
        style={[s.picker, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }, style]} 
        onPress={() => { setSearch(''); setOpen(true); }} 
        activeOpacity={0.8}
      >
        <Text style={[selected ? s.pickerValue : s.pickerPlaceholder, { color: selected ? Colors.text.primary : Colors.text.muted }]} numberOfLines={1}>
          {selected ? selected.label : placeholder}
        </Text>
        <Text style={[s.chevron, { color: Colors.text.muted }]}>▾</Text>
      </TouchableOpacity>

      <Modal visible={open} transparent animationType="fade">
        <TouchableOpacity style={s.backdrop} activeOpacity={1} onPress={() => setOpen(false)}>
          <View style={[s.sheet, { backgroundColor: Colors.bg.elevated }]} onStartShouldSetResponder={() => true}>
            <View style={[s.sheetHeader, { borderBottomColor: Colors.border.default }]}>
              <Text style={[s.sheetTitle, { color: Colors.text.primary }]}>{label}</Text>
              <TouchableOpacity onPress={() => setOpen(false)}>
                <Text style={[s.closeBtn, { color: Colors.text.muted }]}>✕</Text>
              </TouchableOpacity>
            </View>

            {searchable && (
              <TextInput
                style={[s.search, { backgroundColor: Colors.bg.card, color: Colors.text.primary, borderColor: Colors.border.default }]}
                value={search}
                onChangeText={setSearch}
                placeholder="Search..."
                placeholderTextColor={Colors.text.muted}
                autoFocus
              />
            )}

            <FlatList
              data={filtered}
              keyExtractor={i => String(i.id)}
              showsVerticalScrollIndicator={false}
              ListEmptyComponent={<Text style={[s.empty, { color: Colors.text.muted }]}>No results</Text>}
              ListHeaderComponent={
                allowCustom && search.trim().length > 0 && !items.find(i => i.label.toLowerCase() === search.trim().toLowerCase()) ? (
                  <TouchableOpacity
                    style={[s.item, { backgroundColor: Colors.brand.primary + '18', borderBottomColor: Colors.border.subtle }]}
                    onPress={() => { onSelect({ id: search.trim(), label: search.trim() }); setOpen(false); }}
                    activeOpacity={0.7}
                  >
                    <View style={s.itemContent}>
                      <Text style={[s.itemLabel, { color: Colors.brand.primaryLight, fontWeight: '700' }]}>Use "{search.trim()}"</Text>
                      <Text style={[s.itemSub, { color: Colors.text.muted }]}>Create new entry</Text>
                    </View>
                    <Text style={[s.tick, { color: Colors.brand.primary }]}>+</Text>
                  </TouchableOpacity>
                ) : null
              }
              renderItem={({ item }) => {
                const active = (value !== undefined && value !== null) && 
                              (String(item.id) === String(value) || item.label === value);
                return (
                  <TouchableOpacity
                    style={[s.item, active && { backgroundColor: Colors.brand.primary + '18' }, { borderBottomColor: Colors.border.subtle }]}
                    onPress={() => { onSelect(item); setOpen(false); }}
                    activeOpacity={0.7}
                  >
                    <View style={s.itemContent}>
                      <Text style={[s.itemLabel, { color: active ? Colors.brand.primaryLight : Colors.text.secondary }, active && { fontWeight: '700' }]}>{item.label}</Text>
                      {item.sublabel ? <Text style={[s.itemSub, { color: Colors.text.muted }]}>{item.sublabel}</Text> : null}
                    </View>
                    {active && <Text style={[s.tick, { color: Colors.brand.primary }]}>✓</Text>}
                  </TouchableOpacity>
                );
              }}
            />
          </View>
        </TouchableOpacity>
      </Modal>
    </>
  );
}

const s = StyleSheet.create({
  label: { fontSize: FontSize.xs, fontWeight: '600', marginBottom: 5, marginTop: 12, textTransform: 'uppercase', letterSpacing: 0.5 },
  picker: { flexDirection: 'row', alignItems: 'center', borderRadius: Radius.md, paddingHorizontal: 14, paddingVertical: 10, borderWidth: 1, minHeight: 44 },
  pickerValue: { flex: 1, fontSize: FontSize.sm, fontWeight: '500' },
  pickerPlaceholder: { flex: 1, fontSize: FontSize.sm },
  chevron: { fontSize: 14 },
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingTop: 16, maxHeight: '75%' },
  sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: Spacing.lg, paddingBottom: 12, borderBottomWidth: 1 },
  sheetTitle: { fontSize: FontSize.md, fontWeight: '700' },
  closeBtn: { fontSize: 16, padding: 4 },
  search: { borderRadius: Radius.md, paddingHorizontal: 14, paddingVertical: 10, fontSize: FontSize.base, margin: Spacing.md, marginBottom: 4, borderWidth: 1 },
  item: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.lg, paddingVertical: 13, borderBottomWidth: 1 },
  itemContent: { flex: 1 },
  itemLabel: { fontSize: FontSize.base },
  itemSub: { fontSize: FontSize.xs, marginTop: 2 },
  tick: { fontWeight: '800', fontSize: FontSize.md },
  empty: { textAlign: 'center', padding: 24 },
});
