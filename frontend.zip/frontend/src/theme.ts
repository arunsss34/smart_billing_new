// ============================================================
// Smart Billing — Global Theme Configuration
// ============================================================

export type ThemeMode = 'dark' | 'light';

export const getColors = (mode: ThemeMode, brandPrimary: string = '#6366F1') => {
  const isDark = mode === 'dark';

  return {
    // ── Backgrounds ──
    bg: {
      primary:  isDark ? '#0F1115' : '#F8FAFC', // Sleek deep charcoal instead of true black
      card:     isDark ? '#1A1D23' : '#FFFFFF', // Slightly lighter for cards
      surface:  isDark ? '#22262E' : '#F1F5F9',
      elevated: isDark ? '#2D323C' : '#FFFFFF',
      overlay:  'rgba(0,0,0,0.75)',
    },

    // ── Brand / Accent ──
    brand: {
      primary:      brandPrimary,
      primaryDark:  '#4F46E5',
      primaryLight: '#818CF8',
      secondary:    '#06B6D4',
      success:      '#10B981',
      warning:      '#F59E0B',
      danger:       '#EF4444',
      pink:         '#EC4899',
    },

    // ── Text ──
    text: {
      primary:   isDark ? '#F9FAFB' : '#0F172A', // Crisp white for dark mode
      secondary: isDark ? '#A3A3A3' : '#475569',
      muted:     isDark ? '#525252' : '#64748B',
      disabled:  isDark ? '#262626' : '#94A3B8',
      accent:    brandPrimary,
    },

    // ── Borders ──
    border: {
      default: isDark ? '#2D323C' : '#E2E8F0',
      subtle:  isDark ? '#1A1D23' : '#F1F5F9',
      accent:  `${brandPrimary}55`,
    },

    // ── Header (GPay-style) ──
    header: {
      bg:           isDark ? '#0F1115' : '#F8FAFC',
      title:        isDark ? '#F9FAFB' : '#0F172A',
      subtitle:     isDark ? '#A3A3A3' : '#64748B',
      icon:         isDark ? '#A3A3A3' : '#475569',
      avatar:       brandPrimary,
      avatarText:   '#FFFFFF',
      border:       isDark ? '#1A1D23' : '#E2E8F0',
      notification: '#EF4444',
    },

    // ── Sidebar ──
    sidebar: {
      bg:          isDark ? '#0F1115' : '#FFFFFF',
      item:        'transparent',
      itemActive:  isDark ? '#22262E' : '#F1F5F9',
      label:       isDark ? '#A3A3A3' : '#64748B',
      labelActive: isDark ? '#F9FAFB' : brandPrimary,
      icon:        isDark ? '#525252' : '#94A3B8',
      iconActive:  brandPrimary,
      border:      isDark ? '#1A1D23' : '#E2E8F0',
      header:      isDark ? '#1A1D23' : '#F8FAFC',
    },

    // ── Status ──
    status: {
      activeBg:      isDark ? '#052e16' : '#DCFCE7',
      activeBorder:  isDark ? '#16a34a' : '#22C55E',
      activeText:    isDark ? '#4ade80' : '#15803D',
      inactiveBg:    isDark ? '#450A0A' : '#FEE2E2',
      inactiveText:  isDark ? '#F87171' : '#B91C1C',
    },
  };
};

export const Spacing = {
  xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 24, section: 32,
};

export const Radius = {
  sm: 8, md: 12, lg: 16, xl: 20, full: 999,
};

export const FontSize = {
  xs: 10, sm: 12, base: 14, md: 15, lg: 17, xl: 20, xxl: 24, hero: 28,
};

export const Shadow = {
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
};

// Legacy Export for backward compatibility
export const Colors = getColors('dark');

export default { Colors, Spacing, Radius, FontSize, Shadow, getColors };
