import React, { useRef, useState, useEffect } from 'react';
import {
  View, StyleSheet, TouchableOpacity, Text,
  DrawerLayoutAndroid, Platform, StatusBar,
  SafeAreaView, ActivityIndicator, Animated,
} from 'react-native';
import { Slot, usePathname, useRouter } from 'expo-router';
import { IconButton } from 'react-native-paper';
import DynamicSidebar from '../../src/components/DynamicSidebar';
import { useAuthStore } from '../../src/store/auth.store';
import { useThemeStore } from '../../src/store/theme.store';
import { getColors, Spacing, Radius, FontSize } from '../../src/theme';

const STATUS_BAR_HEIGHT = Platform.OS === 'android' ? (StatusBar.currentHeight ?? 24) : 0;

const PAGE_TITLES: Record<string, { title: string; icon: string }> = {
  dashboard:        { title: 'Dashboard',    icon: 'view-dashboard-outline' },
  billing:          { title: 'Billing',      icon: 'receipt' },
  'billing/new':    { title: 'New Invoice',  icon: 'plus-circle-outline' },
  'billing/list':   { title: 'Invoices',     icon: 'format-list-bulleted' },
  products:         { title: 'Products',     icon: 'package-variant-closed' },
  customers:        { title: 'Customers',    icon: 'account-group-outline' },
  reports:          { title: 'Reports',      icon: 'chart-bar' },
  'settings/tenants': { title: 'Tenants',   icon: 'office-building' },
  'settings/roles':   { title: 'Roles',     icon: 'shield-check-outline' },
  'settings/user-role-mapping': { title: 'User Role Mapping', icon: 'account-switch-outline' },
  'users-mgmt':     { title: 'Users',        icon: 'account-cog-outline' },
};

export default function AppLayout() {
  const drawerRef = useRef<DrawerLayoutAndroid>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const pathname = usePathname();
  const router = useRouter();
  const { isAuthenticated, isHydrated, role, themeColor, tenantName } = useAuthStore();
  const { mode, toggleTheme, hydrateTheme } = useThemeStore();

  useEffect(() => { hydrateTheme(); }, []);

  const Colors = getColors(mode, themeColor || undefined);

  useEffect(() => {
    if (isHydrated && !isAuthenticated) router.replace('/login');
  }, [isAuthenticated, isHydrated]);

  if (!isHydrated) {
    return (
      <View style={[styles.loadingScreen, { backgroundColor: Colors.bg.primary }]}>
        <ActivityIndicator size="large" color={Colors.brand.primary} />
      </View>
    );
  }

  if (!isAuthenticated) return null;

  const segments = pathname.split('/').filter(Boolean);
  const routeKey = segments.filter(s => !s.startsWith('(')).join('/');
  const pageInfo = PAGE_TITLES[routeKey] || {
    title: routeKey.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) || 'Dashboard',
    icon: '•',
  };

  const roleInitials = (role || 'SA').split('_').map(w => w[0]).join('').toUpperCase().slice(0, 2);

  const openDrawer = () => Platform.OS === 'android' ? drawerRef.current?.openDrawer() : setDrawerOpen(true);

  const Header = () => (
    <View style={[styles.header, { backgroundColor: Colors.header.bg, borderBottomColor: Colors.header.border }]}>
      <View style={styles.headerLeft}>
        <TouchableOpacity
          style={[styles.menuBtn, { backgroundColor: Colors.bg.card }]}
          onPress={openDrawer}
          activeOpacity={0.7}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <View style={styles.menuLines}>
            <View style={[styles.line, { backgroundColor: Colors.header.icon }]} />
            <View style={[styles.line, styles.lineMiddle, { backgroundColor: Colors.header.icon }]} />
            <View style={[styles.line, { backgroundColor: Colors.header.icon }]} />
          </View>
        </TouchableOpacity>

        <View style={styles.titleBlock}>
          <View>
            <Text style={[styles.pageTitle, { color: Colors.header.title }]} numberOfLines={1}>{tenantName || 'Smart Billing'}</Text>
            <Text style={[styles.roleLabel, { color: Colors.text.muted }]}>{pageInfo.title} • {role?.replace(/_/g, ' ')}</Text>
          </View>
        </View>
      </View>

      <View style={styles.headerRight}>
        <IconButton
          icon={mode === 'dark' ? 'weather-sunny' : 'weather-night'}
          size={20}
          iconColor={Colors.header.icon}
          style={[styles.iconBtn, { backgroundColor: Colors.bg.card, margin: 0 }]}
          onPress={toggleTheme}
        />
        <TouchableOpacity style={[styles.avatar, { backgroundColor: Colors.brand.primary }]} activeOpacity={0.8}>
          <Text style={styles.avatarText}>{roleInitials}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  if (Platform.OS === 'android') {
    return (
      <DrawerLayoutAndroid
        ref={drawerRef}
        drawerWidth={285}
        drawerPosition="left"
        renderNavigationView={() => <DynamicSidebar onClose={() => drawerRef.current?.closeDrawer()} />}
        onDrawerOpen={() => setDrawerOpen(true)}
        onDrawerClose={() => setDrawerOpen(false)}
      >
        <StatusBar barStyle={mode === 'dark' ? "light-content" : "dark-content"} backgroundColor={Colors.header.bg} translucent={false} />
        <View style={[styles.root, { backgroundColor: Colors.bg.primary }]}>
          <Header />
          <View style={styles.content}><Slot /></View>
        </View>
      </DrawerLayoutAndroid>
    );
  }

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: Colors.bg.primary }]}>
      <StatusBar barStyle={mode === 'dark' ? "light-content" : "dark-content"} />
      <Header />
      <View style={[styles.content, { backgroundColor: Colors.bg.primary }]}><Slot /></View>
      {drawerOpen && (
        <>
          <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setDrawerOpen(false)} />
          <Animated.View style={[styles.drawer, { backgroundColor: Colors.sidebar.bg }]}>
            <DynamicSidebar onClose={() => setDrawerOpen(false)} />
          </Animated.View>
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  loadingScreen: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
    paddingTop: STATUS_BAR_HEIGHT + 10,
    borderBottomWidth: 1,
  },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 14, flex: 1 },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  menuBtn: { width: 36, height: 36, borderRadius: Radius.sm, justifyContent: 'center', alignItems: 'center' },
  menuLines: { gap: 4, alignItems: 'center' },
  line: { width: 18, height: 2, borderRadius: 2 },
  lineMiddle: { width: 13 },
  titleBlock: { flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 },
  pageIcon: { fontSize: 18 },
  pageTitle: { fontSize: 13, fontWeight: '900', letterSpacing: 1.5, textTransform: 'uppercase' },
  roleLabel: { fontSize: 10, textTransform: 'capitalize', marginTop: 1, fontWeight: '500' },
  iconBtn: { width: 36, height: 36, borderRadius: Radius.sm, justifyContent: 'center', alignItems: 'center' },
  headerIcon: { fontSize: 16 },
  avatar: { width: 36, height: 36, borderRadius: 18, justifyContent: 'center', alignItems: 'center' },
  avatarText: { color: '#fff', fontWeight: '800', fontSize: 12, letterSpacing: 0.5 },
  content: { flex: 1 },
  overlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)' },
  drawer: {
    position: 'absolute', top: 0, left: 0, bottom: 0, width: 285,
    shadowColor: '#000', shadowOffset: { width: 6, height: 0 }, shadowOpacity: 0.5, shadowRadius: 16, elevation: 20,
  },
});
