import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, KeyboardAvoidingView, Platform,
  Alert, StatusBar, SafeAreaView
} from 'react-native';
import { useRouter } from 'expo-router';
import { IconButton } from 'react-native-paper';
import { useThemeStore } from '../store/theme.store';
import { getColors } from '../theme';
import { getApiBaseUrl, setApiBaseUrl } from '../api/client';

export default function DevSettingsScreen() {
  const [url, setUrl] = useState('');
  const { mode } = useThemeStore();
  const router = useRouter();
  const Colors = getColors(mode);
  const isDark = mode === 'dark';

  useEffect(() => {
    loadCurrentUrl();
  }, []);

  const loadCurrentUrl = async () => {
    const currentUrl = await getApiBaseUrl();
    setUrl(currentUrl);
  };

  const handleSave = async () => {
    if (!url.trim()) {
      Alert.alert('Error', 'API URL cannot be empty');
      return;
    }
    
    try {
      // Validate URL format
      new URL(url);
      await setApiBaseUrl(url.trim());
      Alert.alert('Success', 'API URL updated successfully. The app will use the new URL for subsequent requests.', [
        { text: 'OK', onPress: () => router.back() }
      ]);
    } catch (err) {
      Alert.alert('Invalid URL', 'Please enter a valid URL (e.g., http://192.168.1.34:8000)');
    }
  };

  return (
    <SafeAreaView style={[s.container, { backgroundColor: Colors.bg.primary }]}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} />
      
      <View style={s.header}>
        <TouchableOpacity onPress={() => router.back()} style={s.backBtn}>
          <IconButton icon="arrow-left" size={24} iconColor={Colors.text.primary} />
        </TouchableOpacity>
        <Text style={[s.title, { color: Colors.text.primary }]}>Developer Settings</Text>
        <View style={{ width: 48 }} /> 
      </View>

      <KeyboardAvoidingView 
        style={s.content} 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <View style={s.card}>
          <Text style={[s.label, { color: Colors.text.secondary }]}>API BASE URL</Text>
          <View style={[s.inputWrapper, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]}>
            <IconButton icon="api" size={20} iconColor={Colors.text.muted} />
            <TextInput
              style={[s.input, { color: Colors.text.primary }]}
              value={url}
              onChangeText={setUrl}
              placeholder="http://your-api-url:8000"
              placeholderTextColor={Colors.text.muted}
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>
          <Text style={[s.hint, { color: Colors.text.muted }]}>
            Example: http://192.168.1.34:8000 or https://api.yourdomain.com
          </Text>

          <TouchableOpacity 
            style={[s.saveBtn, { backgroundColor: Colors.brand.primary }]}
            onPress={handleSave}
            activeOpacity={0.8}
          >
            <Text style={s.saveBtnText}>Save Configuration</Text>
          </TouchableOpacity>
        </View>

        <View style={s.infoBox}>
          <IconButton icon="information-outline" size={20} iconColor={Colors.brand.primary} />
          <Text style={[s.infoText, { color: Colors.text.secondary }]}>
            Changing the API URL allows you to switch between development, staging, and production environments without rebuilding the app.
          </Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  backBtn: { marginLeft: 8 },
  title: { fontSize: 18, fontWeight: '700' },
  content: { flex: 1, padding: 24 },
  card: {
    padding: 20,
    borderRadius: 16,
    backgroundColor: 'transparent',
  },
  label: {
    fontSize: 12,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 8,
    marginLeft: 4,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 1,
    paddingRight: 12,
  },
  input: {
    flex: 1,
    height: 52,
    fontSize: 15,
    fontWeight: '500',
  },
  hint: {
    fontSize: 12,
    marginTop: 8,
    marginLeft: 4,
    fontStyle: 'italic',
  },
  saveBtn: {
    height: 54,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 32,
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 }
  },
  saveBtnText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.5
  },
  infoBox: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0,0,0,0.02)',
    padding: 16,
    borderRadius: 12,
    marginTop: 40,
    alignItems: 'flex-start',
  },
  infoText: {
    flex: 1,
    fontSize: 13,
    lineHeight: 18,
    marginLeft: 4,
  }
});
