import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { 
  View, Text, ScrollView, StyleSheet, ActivityIndicator, 
  TouchableOpacity, TextInput, Modal 
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { IconButton } from 'react-native-paper';
import { reportsApi } from '../api/business.api';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors } from '../theme';

type TimeFilter = 'Today' | 'Week' | 'Month' | 'Year' | 'Custom' | 'All';

export default function ReportsScreen() {
  const { themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);
  const isDark = mode === 'dark';

  const [summary, setSummary] = useState<any>(null);
  const [topProducts, setTopProducts] = useState<any[]>([]);
  const [paymentBreakdown, setPaymentBreakdown] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<TimeFilter>('Month');
  
  const [fromDate, setFromDate] = useState(new Date().toISOString().split('T')[0]);
  const [toDate, setToDate] = useState(new Date().toISOString().split('T')[0]);
  const [showDatePicker, setShowDatePicker] = useState(false);

  const formatLocalDate = (date: Date) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  };

  const dateParams = useMemo(() => {
    const end = new Date();
    let start = new Date();
    
    if (filter === 'Today') {
      start.setHours(0,0,0,0);
    } else if (filter === 'Week') {
      start.setDate(end.getDate() - 7);
    } else if (filter === 'Month') {
      start.setMonth(end.getMonth() - 1);
    } else if (filter === 'Year') {
      start.setFullYear(end.getFullYear() - 1);
    } else if (filter === 'Custom') {
      return { start_date: fromDate, end_date: toDate };
    } else if (filter === 'All') {
      return {};
    }

    return {
      start_date: formatLocalDate(start),
      end_date: formatLocalDate(end)
    };
  }, [filter, fromDate, toDate]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [s, tp, pm] = await Promise.all([
        reportsApi.salesSummary(dateParams),
        reportsApi.topProducts(dateParams),
        reportsApi.paymentMethods(dateParams)
      ]);
      setSummary(s?.[0]);
      setTopProducts(tp || []);
      setPaymentBreakdown(pm || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [dateParams]);

  useEffect(() => { load(); }, [load]);

  const cardConfig = [
    { 
      label: 'Revenue', 
      value: `₹${Number(summary?.total_revenue || 0).toLocaleString('en-IN')}`, 
      icon: 'bank',
      colors: isDark ? ['#1E3A8A', '#1E40AF'] : ['#E0F2FE', '#BAE6FD']
    },
    { 
      label: 'Orders', 
      value: String(summary?.total_invoices || 0), 
      icon: 'text-box-check',
      colors: isDark ? ['#064E3B', '#065F46'] : ['#DCFCE7', '#BBF7D0']
    },
    { 
      label: 'Taxation', 
      value: `₹${Number(summary?.total_tax || 0).toLocaleString('en-IN')}`, 
      icon: 'shield-check',
      colors: isDark ? ['#312E81', '#3730A3'] : ['#E0E7FF', '#C7D2FE']
    },
    { 
      label: 'Discount', 
      value: `₹${Number(summary?.total_discount || 0).toLocaleString('en-IN')}`, 
      icon: 'gift',
      colors: isDark ? ['#7F1D1D', '#991B1B'] : ['#FFE4E6', '#FECDD3']
    },
  ];

  const neutralGradient = isDark ? ['#1A1D23', '#0F1115'] : ['#FFFFFF', '#F1F5F9'];

  if (loading && !summary) return (
    <View style={[s.center, { backgroundColor: Colors.bg.primary }]}>
      <ActivityIndicator color={Colors.brand.primary} />
    </View>
  );

  return (
    <ScrollView style={[s.container, { backgroundColor: Colors.bg.primary }]} showsVerticalScrollIndicator={false}>
      {/* ── Filter Bar ── */}
      <View style={s.filterHeader}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.timeFilters}>
          {(['Today', 'Week', 'Month', 'Year', 'Custom', 'All'] as TimeFilter[]).map(f => (
            <TouchableOpacity 
              key={f} 
              style={[s.filterChip, { borderColor: Colors.border.default, backgroundColor: Colors.bg.card }, filter === f && { backgroundColor: Colors.brand.primary, borderColor: Colors.brand.primary }]} 
              onPress={() => {
                setFilter(f);
                if (f === 'Custom') setShowDatePicker(true);
              }}
            >
              <Text style={[s.filterChipTxt, { color: filter === f ? '#FFF' : Colors.text.secondary }]}>{f}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        <IconButton icon="refresh" size={20} iconColor={Colors.brand.primary} onPress={load} />
      </View>

      {/* ── Summary Grid (Vibrant Theme-Safe Gradients) ── */}
      <View style={s.summaryGrid}>
        {cardConfig.map(card => (
          <LinearGradient key={card.label} colors={card.colors as any} start={{x:0, y:0}} end={{x:1, y:1}} style={[s.summaryCard, { borderColor: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)' }]}>
            <View style={s.cardHead}>
              <IconButton icon={card.icon} size={16} iconColor={isDark ? 'rgba(255,255,255,0.7)' : Colors.brand.primary} style={{ margin: 0 }} />
              <Text style={[s.cardLabel, { color: isDark ? 'rgba(255,255,255,0.7)' : Colors.text.secondary }]}>{card.label}</Text>
            </View>
            <Text style={[s.cardValue, { color: isDark ? '#FFF' : Colors.text.primary }]}>{card.value}</Text>
          </LinearGradient>
        ))}
      </View>

      {/* ── Analysis Sections ── */}
      <LinearGradient colors={neutralGradient as any} style={[s.analysisCard, { borderColor: Colors.border.default }]}>
        <Text style={[s.analysisTitle, { color: Colors.text.primary }]}>Payment performance</Text>
        {paymentBreakdown.map((row, i) => (
          <View key={i} style={[s.analysisRow, { borderBottomColor: Colors.border.subtle, borderBottomWidth: i === paymentBreakdown.length - 1 ? 0 : 1 }]}>
            <View style={{ flex: 1 }}>
              <Text style={[s.rowLabel, { color: Colors.text.primary }]}>{row.payment_method}</Text>
              <Text style={[s.rowSub, { color: Colors.text.muted }]}>{row.total_invoices} txns</Text>
            </View>
            <Text style={[s.rowValue, { color: Colors.brand.primary }]}>₹{Number(row.total_revenue).toLocaleString('en-IN')}</Text>
          </View>
        ))}
      </LinearGradient>

      <LinearGradient colors={neutralGradient as any} style={[s.analysisCard, { borderColor: Colors.border.default, marginTop: 12 }]}>
        <Text style={[s.analysisTitle, { color: Colors.text.primary }]}>Top selling items</Text>
        {topProducts.map((row, i) => (
          <View key={i} style={[s.analysisRow, { borderBottomColor: Colors.border.subtle, borderBottomWidth: i === topProducts.length - 1 ? 0 : 1 }]}>
            <View style={[s.rankNum, { backgroundColor: Colors.bg.surface }]}>
              <Text style={{ color: Colors.brand.primary, fontWeight: '800', fontSize: 12 }}>{i+1}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[s.rowLabel, { color: Colors.text.primary }]} numberOfLines={1}>{row.product_name}</Text>
              <Text style={[s.rowSub, { color: Colors.text.muted }]}>{Number(row.total_qty).toFixed(0)} units sold</Text>
            </View>
            <Text style={[s.rowValue, { color: Colors.brand.success }]}>₹{Number(row.total_revenue).toLocaleString('en-IN')}</Text>
          </View>
        ))}
      </LinearGradient>

      <View style={{ height: 40 }} />

      <Modal visible={showDatePicker} transparent animationType="fade">
        <View style={s.modalOverlay}>
          <View style={[s.modalContent, { backgroundColor: Colors.bg.card }]}>
            <Text style={[s.modalTitle, { color: Colors.text.primary }]}>Custom date range</Text>
            <TextInput 
              style={[s.modalInput, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, color: Colors.text.primary }]}
              value={fromDate} onChangeText={setFromDate} placeholder="From: YYYY-MM-DD"
              placeholderTextColor={Colors.text.muted}
            />
            <TextInput 
              style={[s.modalInput, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, color: Colors.text.primary, marginTop: 12 }]}
              value={toDate} onChangeText={setToDate} placeholder="To: YYYY-MM-DD"
              placeholderTextColor={Colors.text.muted}
            />
            <View style={s.modalBtns}>
              <TouchableOpacity style={s.modalCancel} onPress={() => setShowDatePicker(false)}>
                <Text style={{ color: Colors.text.secondary, fontWeight: '700' }}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.modalApply, { backgroundColor: Colors.brand.primary }]} onPress={() => { setShowDatePicker(false); setFilter('Custom'); load(); }}>
                <Text style={{ color: '#FFF', fontWeight: '800' }}>Apply</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  
  filterHeader: { flexDirection: 'row', alignItems: 'center', marginTop: 16, marginBottom: 12 },
  timeFilters: { flex: 1 },
  filterChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10, marginRight: 8, borderWidth: 1 },
  filterChipTxt: { fontSize: 11, fontWeight: '700' },

  dateRangeCard: { flexDirection: 'row', alignItems: 'center', padding: 12, borderRadius: 10, borderWidth: 1, marginBottom: 12 },
  dateRangeTxt: { flex: 1, fontSize: 13, fontWeight: '700' },

  summaryGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginBottom: 4 },
  summaryCard: { width: '48.5%', borderRadius: 10, padding: 14, height: 100, justifyContent: 'space-between', borderWidth: 1, marginBottom: 10 },
  cardHead: { flexDirection: 'row', alignItems: 'center', gap: 2, marginLeft: -8, marginTop: -4 },
  cardLabel: { fontSize: 11, fontWeight: '700' },
  cardValue: { fontSize: 18, fontWeight: '900' },

  analysisCard: { borderRadius: 10, padding: 16, marginBottom: 0, borderWidth: 1 },
  analysisTitle: { fontSize: 13, fontWeight: '800', letterSpacing: 0.5, marginBottom: 16 },
  analysisRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1 },
  rowLabel: { fontSize: 13, fontWeight: '700' },
  rowSub: { fontSize: 10, marginTop: 2 },
  rowValue: { fontSize: 13, fontWeight: '800' },
  rankNum: { width: 24, height: 24, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginRight: 10 },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 24 },
  modalContent: { width: '100%', borderRadius: 10, padding: 24 },
  modalTitle: { fontSize: 18, fontWeight: '900', marginBottom: 20 },
  modalInput: { borderRadius: 10, borderWidth: 1, padding: 12, fontSize: 14 },
  modalBtns: { flexDirection: 'row', gap: 12, marginTop: 24 },
  modalCancel: { flex: 1, height: 48, justifyContent: 'center', alignItems: 'center' },
  modalApply: { flex: 1, height: 48, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
});
