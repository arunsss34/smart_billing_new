import React, { useMemo, useState, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, Platform, StatusBar, Image
} from 'react-native';
import { useRouter, usePathname } from 'expo-router';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors, Spacing, Radius, FontSize } from '../theme';

const iconMap: Record<string, string> = {
  'grid':      '⊞',
  'file-text': '🧾',
  'package':   '📦',
  'users':     '👥',
  'bar-chart': '📊',
  'settings':  '⚙️',
  'user':      '👤',
  'plus':      '➕',
  'list':      '📋',
  'building':  '🏢',
  'shield':    '🛡',
  'menu':      '☰',
};

interface SidebarProps {
  onClose?: () => void;
}

const STATUS_BAR_HEIGHT = Platform.OS === 'android' ? (StatusBar.currentHeight ?? 24) : 0;

export default function DynamicSidebar({ onClose }: SidebarProps) {
  const { menus, role, logout, menuError, loadMenus, themeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, themeColor || undefined);
  const router = useRouter();
  const pathname = usePathname();
  const topMenus = useMemo(() => menus.filter(m => !m.parent_id), [menus]);
  const childMenus = useMemo(
    () => (parentId: number) => menus.filter(m => m.parent_id === parentId),
    [menus]
  );

  const [expanded, setExpanded] = useState<Record<number, boolean>>({});
  useEffect(() => {
    if (menus.length === 0) return;
    const init: Record<number, boolean> = {};
    menus.filter(m => !m.parent_id).forEach(m => {
      if (menus.some(c => c.parent_id === m.id)) init[m.id] = true;
    });
    setExpanded(init);
  }, [menus]);

  const navigate = (route: string) => {
    router.push(`/(app)/${route}` as any);
    onClose?.();
  };

  const toggleExpand = (id: number) => {
    setExpanded(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const isActive = (route: string) => pathname.includes(route);

  const roleLabel = role?.replace(/_/g, ' ') || '';
  const roleInitials = (role || 'SA').split('_').map((w: string) => w[0]).join('').toUpperCase().slice(0, 2);

  return (
    <View style={[s.container, { backgroundColor: Colors.sidebar.bg }]}>
      {/* ── User Header ── */}
      <View style={s.header}>
        <Image 
          source={require('../../assets/logo.png')} 
          style={s.sidebarLogo} 
          resizeMode="contain" 
        />
        <View style={s.userInfo}>
          <Text style={[s.appName, { color: Colors.text.primary }]}>Smart Billing</Text>
          <View style={s.roleBadge}>
            <View style={[s.roleDot, { backgroundColor: Colors.brand.success }]} />
            <Text style={[s.roleText, { color: Colors.text.muted }]}>{roleLabel}</Text>
          </View>
        </View>
      </View>

      <View style={[s.divider, { backgroundColor: Colors.sidebar.border }]} />

      <ScrollView style={s.menuList} showsVerticalScrollIndicator={false}>
        <Text style={[s.sectionLabel, { color: Colors.text.disabled }]}>NAVIGATION</Text>

        {menuError && (
          <View style={[s.errorBox, { backgroundColor: mode === 'dark' ? '#1a0a0a' : '#FEF2F2', borderColor: mode === 'dark' ? '#3B0F0F' : '#FEE2E2' }]}>
            <Text style={[s.errorText, { color: Colors.brand.danger }]}>⚠️ {menuError}</Text>
            <TouchableOpacity style={[s.retryBtn, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]} onPress={loadMenus}>
              <Text style={[s.retryText, { color: Colors.text.secondary }]}>Retry</Text>
            </TouchableOpacity>
          </View>
        )}

        {!menuError && menus.length === 0 && (
          <View style={[s.errorBox, { backgroundColor: mode === 'dark' ? '#1a0a0a' : '#F8FAFC', borderColor: mode === 'dark' ? '#3B0F0F' : '#E2E8F0' }]}>
            <Text style={[s.errorText, { color: Colors.brand.danger }]}>No menus loaded</Text>
            <TouchableOpacity style={[s.retryBtn, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]} onPress={loadMenus}>
              <Text style={[s.retryText, { color: Colors.text.secondary }]}>Reload</Text>
            </TouchableOpacity>
          </View>
        )}

        {topMenus.map((menu) => {
          const children = childMenus(menu.id);
          const hasChildren = children.length > 0;
          const isOpen = expanded[menu.id];
          const active = isActive(menu.route);

          return (
            <View key={menu.id}>
              <TouchableOpacity
                style={[s.menuItem, active && { backgroundColor: Colors.sidebar.itemActive }]}
                onPress={() => hasChildren ? toggleExpand(menu.id) : navigate(menu.route)}
                activeOpacity={0.7}
              >
                {active && <View style={[s.activeBar, { backgroundColor: Colors.brand.primary }]} />}

                <View style={[s.iconBox, { backgroundColor: Colors.bg.card }, active && { backgroundColor: Colors.brand.primary + '33' }]}>
                  <Text style={[s.menuIcon, { color: active ? Colors.brand.primary : Colors.text.secondary }]}>{iconMap[menu.icon] || '◦'}</Text>
                </View>
                <Text style={[s.menuLabel, { color: active ? Colors.sidebar.labelActive : Colors.sidebar.label }, active && { fontWeight: '700' }]} numberOfLines={1}>
                  {menu.name}
                </Text>
                {hasChildren && (
                  <Text style={[s.chevron, { color: Colors.text.muted }]}>{isOpen ? '▾' : '›'}</Text>
                )}
              </TouchableOpacity>

              {hasChildren && isOpen && children.map((child) => {
                const childActive = isActive(child.route);
                return (
                  <TouchableOpacity
                    key={child.id}
                    style={[s.subItem, childActive && { backgroundColor: Colors.sidebar.itemActive }]}
                    onPress={() => navigate(child.route)}
                    activeOpacity={0.7}
                  >
                    <View style={[s.subItemLine, { backgroundColor: childActive ? Colors.brand.primary : Colors.border.default }]} />
                    <Text style={[s.subLabel, { color: childActive ? Colors.sidebar.labelActive : Colors.sidebar.label }, childActive && { fontWeight: '700' }]}>
                      {child.name}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          );
        })}
      </ScrollView>

      <View style={[s.divider, { backgroundColor: Colors.sidebar.border }]} />
      <TouchableOpacity style={s.logoutBtn} onPress={logout} activeOpacity={0.8}>
        <View style={[s.iconBox, { backgroundColor: mode === 'dark' ? '#3B0F0F' : '#FEE2E2' }]}>
          <Text style={{ fontSize: 15 }}>🚪</Text>
        </View>
        <Text style={[s.logoutText, { color: Colors.brand.danger }]}>Sign Out</Text>
      </TouchableOpacity>
    </View>
  );
}

const s = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: STATUS_BAR_HEIGHT + 16,
    paddingBottom: 24,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.lg,
    gap: 12,
  },
  sidebarLogo: {
    width: 42, height: 42,
  },
  userInfo: { flex: 1 },
  appName: { fontWeight: '700', fontSize: 16 },
  roleBadge: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 3 },
  roleDot: { width: 6, height: 6, borderRadius: 3 },
  roleText: {
    fontSize: 10,
    fontWeight: '600',
    textTransform: 'capitalize',
  },
  divider: { height: 1, marginVertical: 8 },
  sectionLabel: {
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 1.5,
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.sm,
    paddingTop: Spacing.xs,
  },
  menuList: { flex: 1, paddingHorizontal: Spacing.sm },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: Radius.md,
    marginVertical: 1,
    gap: 10,
    overflow: 'hidden',
  },
  activeBar: {
    position: 'absolute',
    left: 0, top: 6, bottom: 6,
    width: 3,
    borderRadius: 2,
  },
  iconBox: {
    width: 32, height: 32,
    borderRadius: Radius.sm,
    justifyContent: 'center', alignItems: 'center',
  },
  menuIcon: { fontSize: 15 },
  menuLabel: { flex: 1, fontSize: 14 },
  chevron: { fontSize: 14 },
  subItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 9,
    paddingLeft: 26,
    paddingRight: 10,
    borderRadius: Radius.md,
    marginVertical: 1,
    gap: 10,
  },
  subItemLine: {
    width: 16, height: 1.5,
    borderRadius: 1,
  },
  subLabel: { fontSize: 13 },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: Spacing.sm,
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: Radius.md,
    gap: 10,
    marginTop: 8,
  },
  logoutText: { fontWeight: '600', fontSize: 14 },
  errorBox: {
    marginHorizontal: Spacing.sm,
    marginBottom: Spacing.md,
    padding: Spacing.md,
    borderRadius: Radius.md,
    borderWidth: 1,
    alignItems: 'center',
    gap: 8,
  },
  errorText: { fontSize: 12, textAlign: 'center' },
  retryBtn: {
    paddingHorizontal: 16, paddingVertical: 6,
    borderRadius: Radius.sm,
    borderWidth: 1,
  },
  retryText: { fontSize: 12, fontWeight: '600' },
});
