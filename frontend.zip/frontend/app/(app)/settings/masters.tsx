import MastersScreen from '../../../src/screens/MastersScreen';
export default MastersScreen;
