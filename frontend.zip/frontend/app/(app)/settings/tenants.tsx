import TenantsScreen from '../../../src/screens/TenantsScreen';
export default TenantsScreen;
