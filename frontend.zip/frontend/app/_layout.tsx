import { useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { Slot, useRouter, useSegments } from 'expo-router';
import { useAuthStore } from '../src/store/auth.store';
import { useThemeStore } from '../src/store/theme.store';
import { getColors, Colors } from '../src/theme';

export default function RootLayout() {
  const { isAuthenticated, isHydrated, hydrateFromStorage, themeColor } = useAuthStore();
  const { mode, hydrateTheme } = useThemeStore();
  const router = useRouter();
  const segments = useSegments();

  // Step 1: Read storage on app launch
  useEffect(() => {
    hydrateFromStorage();
    hydrateTheme();
  }, []);

  const Colors = getColors(mode, themeColor || undefined);

  // Step 2: Only redirect AFTER hydration is complete
  useEffect(() => {
    if (!isHydrated) return; // Wait — storage not read yet

    const inApp = segments[0] === '(app)';
    if (!isAuthenticated && inApp) {
      router.replace('/login');
    } else if (isAuthenticated && !inApp) {
      router.replace('/(app)/dashboard');
    }
  }, [isAuthenticated, isHydrated, segments]);

  // Show a blank loader while reading storage
  if (!isHydrated) {
    return (
      <View style={{ flex: 1, backgroundColor: Colors.bg.primary, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color={Colors.brand.primary} />
      </View>
    );
  }

  return <Slot />;
}

