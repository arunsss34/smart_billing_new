import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Modal, ActivityIndicator, Alert, Switch,
} from 'react-native';
import { useRouter } from 'expo-router';
import { tenantApi, Tenant, TenantCreate } from '../api/tenant.api';
import { businessTypeApi, BusinessType } from '../api/businessType.api';
import { useAuthStore } from '../store/auth.store';
import { useThemeStore } from '../store/theme.store';
import { getColors, Radius, Spacing, FontSize } from '../theme';

const EMPTY_FORM: TenantCreate = {
  name: '',
  business_type: '',
  email: '',
  phone: '',
  subscription_expiry: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
    .toISOString().split('T')[0],
  is_active: true,
  theme_color: '#6366F1',
};

const PALETTE = ['#6366F1', '#EC4899', '#F59E0B', '#10B981', '#3B82F6', '#8B5CF6', '#F43F5E', '#06B6D4'];

export default function TenantsScreen() {
  const { themeColor: globalThemeColor } = useAuthStore();
  const { mode } = useThemeStore();
  const Colors = getColors(mode, globalThemeColor || undefined);
  const router = useRouter();

  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [bizTypes, setBizTypes] = useState<BusinessType[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<TenantCreate>(EMPTY_FORM);

  const load = async () => {
    setLoading(true);
    try {
      const [tenantData, btData] = await Promise.all([
        tenantApi.list(),
        businessTypeApi.list(),
      ]);
      setTenants(tenantData);
      setBizTypes(btData);
      if (!form.business_type && btData.length > 0) {
        setForm(f => ({ ...f, business_type: btData[0].name }));
      }
    } catch (e: any) {
      Alert.alert('Error', e?.response?.data?.detail || 'Failed to load tenants');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleEdit = (t: Tenant) => {
    setForm({
      name: t.name,
      business_type: t.business_type,
      email: t.email,
      phone: t.phone,
      subscription_expiry: String(t.subscription_expiry).split('T')[0],
      is_active: t.is_active,
      theme_color: t.theme_color || '#6366F1',
    });
    setEditingId(t.id);
    setModalVisible(true);
  };

  const handleSave = async () => {
    if (!form.name || !form.email || !form.business_type) {
      Alert.alert('Validation', 'Name, Email, and Business Type are required.');
      return;
    }
    setSaving(true);
    try {
      if (editingId) {
        await tenantApi.update(editingId, form);
      } else {
        await tenantApi.create(form);
      }
      load();
      setModalVisible(false);
    } catch (e: any) {
      Alert.alert('Error', e?.response?.data?.detail || 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return (
    <View style={[s.center, { backgroundColor: Colors.bg.primary }]}>
      <ActivityIndicator color={Colors.brand.primary} />
    </View>
  );

  return (
    <View style={[s.container, { backgroundColor: Colors.bg.primary }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={s.header}>
          <Text style={[s.title, { color: Colors.text.primary }]}>Tenant Directory</Text>
          <TouchableOpacity 
            style={[s.addBtn, { backgroundColor: Colors.brand.primary }]} 
            onPress={() => { setForm(EMPTY_FORM); setEditingId(null); setModalVisible(true); }}
          >
            <Text style={s.addBtnText}>+ New Tenant</Text>
          </TouchableOpacity>
        </View>

        {tenants.map(t => (
          <TouchableOpacity 
            key={t.id} 
            style={[s.card, { backgroundColor: Colors.bg.card, borderColor: Colors.border.default }]} 
            onPress={() => handleEdit(t)}
          >
            <View style={[s.brandBar, { backgroundColor: t.theme_color || Colors.brand.primary }]} />
            <View style={s.cardBody}>
              <View style={s.cardTop}>
                <Text style={[s.tName, { color: Colors.text.primary }]}>{t.name}</Text>
                <View style={[s.badge, { backgroundColor: t.is_active ? Colors.status.activeBg : Colors.status.inactiveBg }]}>
                  <Text style={[s.badgeText, { color: t.is_active ? Colors.status.activeText : Colors.status.inactiveText }]}>
                    {t.is_active ? 'ACTIVE' : 'INACTIVE'}
                  </Text>
                </View>
              </View>
              <Text style={[s.tType, { color: Colors.text.secondary }]}>{t.business_type} · {t.phone}</Text>
              <Text style={[s.tExpiry, { color: Colors.text.muted }]}>
                Expires: {String(t.subscription_expiry).split('T')[0]}
              </Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={[s.modalOverlay, { backgroundColor: Colors.bg.overlay }]}>
          <View style={[s.modalCard, { backgroundColor: Colors.bg.card }]}>
            <Text style={[s.modalTitle, { color: Colors.text.primary }]}>{editingId ? 'Edit Tenant' : 'New Tenant'}</Text>
            <ScrollView showsVerticalScrollIndicator={false}>
              <Text style={[s.label, { color: Colors.text.secondary }]}>Business Name *</Text>
              <TextInput
                style={[s.input, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, color: Colors.text.primary }]}
                value={form.name}
                onChangeText={v => setForm({ ...form, name: v })}
                placeholder="e.g. My Restaurant"
                placeholderTextColor={Colors.text.muted}
              />

              <Text style={[s.label, { color: Colors.text.secondary }]}>Business Type *</Text>
              <View style={s.typeGrid}>
                {bizTypes.map(bt => (
                  <TouchableOpacity
                    key={bt.id}
                    style={[
                      s.typeBtn,
                      { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default },
                      form.business_type === bt.name && { borderColor: Colors.brand.primary, backgroundColor: Colors.brand.primary + '11' }
                    ]}
                    onPress={() => setForm({ ...form, business_type: bt.name })}
                  >
                    <Text style={[
                      s.typeBtnText,
                      { color: Colors.text.secondary },
                      form.business_type === bt.name && { color: Colors.brand.primary, fontWeight: '700' }
                    ]}>{bt.name}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={[s.label, { color: Colors.text.secondary }]}>Brand Theme Color</Text>
              <View style={s.colorPalette}>
                {PALETTE.map(c => (
                  <TouchableOpacity
                    key={c}
                    style={[s.colorCircle, { backgroundColor: c }, form.theme_color === c && { borderWidth: 3, borderColor: Colors.text.primary }]}
                    onPress={() => setForm({ ...form, theme_color: c })}
                  />
                ))}
              </View>

              <Text style={[s.label, { color: Colors.text.secondary }]}>Email *</Text>
              <TextInput
                style={[s.input, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, color: Colors.text.primary }]}
                value={form.email}
                onChangeText={v => setForm({ ...form, email: v })}
                keyboardType="email-address"
                autoCapitalize="none"
              />

              <Text style={[s.label, { color: Colors.text.secondary }]}>Phone</Text>
              <TextInput
                style={[s.input, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, color: Colors.text.primary }]}
                value={form.phone}
                onChangeText={v => setForm({ ...form, phone: v })}
                keyboardType="phone-pad"
              />

              <Text style={[s.label, { color: Colors.text.secondary }]}>Subscription Expiry (YYYY-MM-DD)</Text>
              <TextInput
                style={[s.input, { backgroundColor: Colors.bg.primary, borderColor: Colors.border.default, color: Colors.text.primary }]}
                value={form.subscription_expiry}
                onChangeText={v => setForm({ ...form, subscription_expiry: v })}
              />

              <View style={s.switchRow}>
                <Text style={[s.label, { color: Colors.text.secondary, marginTop: 0 }]}>Is Active</Text>
                <Switch
                  value={form.is_active}
                  onValueChange={v => setForm({ ...form, is_active: v })}
                  trackColor={{ false: '#334155', true: Colors.brand.primary }}
                />
              </View>

              <View style={{ height: 20 }} />
            </ScrollView>

            <View style={s.modalFooter}>
              <TouchableOpacity style={[s.btn, s.btnCancel, { backgroundColor: Colors.bg.primary }]} onPress={() => setModalVisible(false)}>
                <Text style={[s.btnText, { color: Colors.text.secondary }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.btn, s.btnSave, { backgroundColor: Colors.brand.primary }]} onPress={handleSave}>
                {saving ? <ActivityIndicator color="#fff" /> : <Text style={s.btnText}>Save Tenant</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 20 },
  title: { fontSize: 20, fontWeight: '800' },
  addBtn: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: Radius.md },
  addBtnText: { color: '#fff', fontWeight: '700' },
  card: { borderRadius: Radius.lg, marginBottom: 16, overflow: 'hidden', borderWidth: 1, flexDirection: 'row' },
  brandBar: { width: 6 },
  cardBody: { flex: 1, padding: 16 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  tName: { fontSize: 16, fontWeight: '700' },
  badge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: Radius.sm },
  badgeText: { fontSize: 9, fontWeight: '800' },
  tType: { fontSize: 13, marginBottom: 4 },
  tExpiry: { fontSize: 11 },
  modalOverlay: { flex: 1, justifyContent: 'flex-end' },
  modalCard: { borderTopLeftRadius: Radius.xl, borderTopRightRadius: Radius.xl, padding: 24, height: '90%' },
  modalTitle: { fontSize: 18, fontWeight: '800', marginBottom: 20 },
  label: { fontSize: 12, fontWeight: '700', marginTop: 16, marginBottom: 6 },
  input: { borderRadius: Radius.md, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14 },
  typeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  typeBtn: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: Radius.md, borderWidth: 1 },
  typeBtnText: { fontSize: 12 },
  colorPalette: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginVertical: 8 },
  colorCircle: { width: 34, height: 34, borderRadius: 17 },
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 20 },
  modalFooter: { flexDirection: 'row', gap: 12, marginTop: 24 },
  btn: { flex: 1, paddingVertical: 14, borderRadius: Radius.md, alignItems: 'center' },
  btnCancel: { borderWidth: 1, borderColor: '#ccc' },
  btnSave: { elevation: 4 },
  btnText: { color: '#fff', fontWeight: '700' },
});
